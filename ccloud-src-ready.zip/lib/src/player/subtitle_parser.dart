import 'package:flutter/foundation.dart';

/// A single timed subtitle block.
@immutable
class SubtitleCue {
  const SubtitleCue({
    required this.start,
    required this.end,
    required this.text,
  });

  final Duration start;
  final Duration end;
  final String text;

  bool contains(Duration t) => t >= start && t <= end;
}

/// A parsed subtitle document (embedded track, uploaded file, or fetched).
@immutable
class SubtitleDocument {
  const SubtitleDocument({
    required this.name,
    required this.cues,
    this.filePath,
  });

  final String name;
  final List<SubtitleCue> cues;
  final String? filePath;

  bool get isEmpty => cues.isEmpty;

  SubtitleCue? cueAt(Duration position, {double offsetSeconds = 0}) {
    if (cues.isEmpty) {
      return null;
    }
    final Duration target =
        position + Duration(milliseconds: (offsetSeconds * 1000).round());
    int low = 0;
    int high = cues.length - 1;
    int found = -1;
    while (low <= high) {
      final int mid = (low + high) >> 1;
      final SubtitleCue c = cues[mid];
      if (c.end < target) {
        low = mid + 1;
      } else if (c.start > target) {
        high = mid - 1;
      } else {
        found = mid;
        break;
      }
    }
    return found == -1 ? null : cues[found];
  }
}

/// Parses the three formats accepted by the upload box: `.srt`, `.vtt`, `.ass`.
class SubtitleParser {
  SubtitleParser._();

  static SubtitleDocument parse(
    String name,
    String content, {
    String? filePath,
  }) {
    final String trimmed = content.trimLeft();
    if (trimmed.startsWith('WEBVTT')) {
      return _parseVtt(name, content, filePath);
    }
    if (trimmed.contains('[Script Info]') || trimmed.contains('[Events]')) {
      return _parseAss(name, content, filePath);
    }
    return _parseSrt(name, content, filePath);
  }

  // ------------------------------------------------------------------- SRT

  static SubtitleDocument _parseSrt(
    String name,
    String content,
    String? filePath,
  ) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    final List<String> blocks = content.replaceAll('\r\n', '\n').split('\n\n');
    for (final String block in blocks) {
      final List<String> lines = block
          .split('\n')
          .where((String l) => l.trim().isNotEmpty)
          .toList();
      if (lines.isEmpty) {
        continue;
      }
      int timeLineIndex = -1;
      for (int i = 0; i < lines.length; i++) {
        if (lines[i].contains('-->')) {
          timeLineIndex = i;
          break;
        }
      }
      if (timeLineIndex == -1 || lines.length < 2) {
        continue;
      }
      final RegExpMatch? match = RegExp(
        r'(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})',
      ).firstMatch(lines[timeLineIndex]);
      if (match == null) {
        continue;
      }
      final Duration? start = _parseTimestamp(match.group(1)!);
      final Duration? end = _parseTimestamp(match.group(2)!);
      if (start == null || end == null) {
        continue;
      }
      final String text = lines.skip(timeLineIndex + 1).join('\n').trim();
      if (text.isEmpty) {
        continue;
      }
      cues.add(SubtitleCue(start: start, end: end, text: _stripTags(text)));
    }
    cues.sort((SubtitleCue a, SubtitleCue b) => a.start.compareTo(b.start));
    return SubtitleDocument(name: name, cues: cues, filePath: filePath);
  }

  // ------------------------------------------------------------------- VTT

  static SubtitleDocument _parseVtt(
    String name,
    String content,
    String? filePath,
  ) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    final List<String> blocks = content.replaceAll('\r\n', '\n').split('\n\n');
    for (final String block in blocks) {
      final String head = block.trimLeft();
      if (head.startsWith('WEBVTT') ||
          head.startsWith('NOTE') ||
          head.startsWith('STYLE') ||
          head.startsWith('REGION')) {
        continue;
      }
      final List<String> lines = block
          .split('\n')
          .where((String l) => l.trim().isNotEmpty)
          .toList();
      if (lines.isEmpty) {
        continue;
      }
      int timeLineIndex = -1;
      for (int i = 0; i < lines.length; i++) {
        if (lines[i].contains('-->')) {
          timeLineIndex = i;
          break;
        }
      }
      if (timeLineIndex == -1) {
        continue;
      }
      final RegExpMatch? match = RegExp(
        r'(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{1,2}:\d{2}[.,]\d{1,3})\s*-->\s*'
        r'(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{1,2}:\d{2}[.,]\d{1,3})',
      ).firstMatch(lines[timeLineIndex]);
      if (match == null) {
        continue;
      }
      final Duration? start = _parseTimestamp(match.group(1)!);
      final Duration? end = _parseTimestamp(match.group(2)!);
      if (start == null || end == null) {
        continue;
      }
      final String text = lines.skip(timeLineIndex + 1).join('\n').trim();
      if (text.isEmpty) {
        continue;
      }
      cues.add(SubtitleCue(start: start, end: end, text: _stripTags(text)));
    }
    cues.sort((SubtitleCue a, SubtitleCue b) => a.start.compareTo(b.start));
    return SubtitleDocument(name: name, cues: cues, filePath: filePath);
  }

  // ------------------------------------------------------------------- ASS

  static SubtitleDocument _parseAss(
    String name,
    String content,
    String? filePath,
  ) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    final List<String> lines = content.replaceAll('\r\n', '\n').split('\n');
    List<String> formatFields = <String>[
      'layer',
      'start',
      'end',
      'style',
      'name',
      'marginl',
      'marginr',
      'marginv',
      'effect',
      'text',
    ];
    bool inEvents = false;
    for (final String raw in lines) {
      final String line = raw.trim();
      if (line.startsWith('[')) {
        inEvents = line.toLowerCase() == '[events]';
        continue;
      }
      if (!inEvents) {
        continue;
      }
      if (line.toLowerCase().startsWith('format:')) {
        formatFields = line
            .substring(7)
            .split(',')
            .map((String e) => e.trim().toLowerCase())
            .toList();
        continue;
      }
      if (!line.toLowerCase().startsWith('dialogue:')) {
        continue;
      }
      final String payload = line.substring('dialogue:'.length);
      final int splitAt = formatFields.length - 1;
      final List<String> parts = _splitWithLimit(payload, ',', splitAt);
      if (parts.length < formatFields.length) {
        continue;
      }
      final int? startIdx = _indexOfField(formatFields, 'start');
      final int? endIdx = _indexOfField(formatFields, 'end');
      final int? textIdx = _indexOfField(formatFields, 'text');
      if (startIdx == null || endIdx == null || textIdx == null) {
        continue;
      }
      final Duration? start = _parseTimestamp(parts[startIdx].trim());
      final Duration? end = _parseTimestamp(parts[endIdx].trim());
      if (start == null || end == null) {
        continue;
      }
      String text = parts[textIdx];
      text = text
          .replaceAll(RegExp(r'\{[^}]*\}'), '')
          .replaceAll(r'\N', '\n')
          .replaceAll(r'\n', '\n')
          .replaceAll(r'\h', ' ')
          .trim();
      if (text.isEmpty) {
        continue;
      }
      cues.add(SubtitleCue(start: start, end: end, text: text));
    }
    cues.sort((SubtitleCue a, SubtitleCue b) => a.start.compareTo(b.start));
    return SubtitleDocument(name: name, cues: cues, filePath: filePath);
  }

  static int? _indexOfField(List<String> fields, String field) {
    for (int i = 0; i < fields.length; i++) {
      if (fields[i] == field) {
        return i;
      }
    }
    return null;
  }

  static List<String> _splitWithLimit(
    String input,
    String separator,
    int limit,
  ) {
    final List<String> parts = <String>[];
    int cursor = 0;
    for (int i = 0; i < limit; i++) {
      final int idx = input.indexOf(separator, cursor);
      if (idx == -1) {
        parts.add(input.substring(cursor));
        cursor = input.length;
        break;
      }
      parts.add(input.substring(cursor, idx));
      cursor = idx + separator.length;
    }
    if (cursor <= input.length && parts.length <= limit) {
      parts.add(input.substring(cursor));
    }
    return parts;
  }

  // ---------------------------------------------------------------- common

  static Duration? _parseTimestamp(String raw) {
    final String s = raw.trim().replaceAll(',', '.');
    final List<String> parts = s.split(':');
    try {
      if (parts.length == 3) {
        final int h = int.parse(parts[0]);
        final int m = int.parse(parts[1]);
        final double sec = double.parse(parts[2]);
        return Duration(
          hours: h,
          minutes: m,
          milliseconds: (sec * 1000).round(),
        );
      }
      if (parts.length == 2) {
        final int m = int.parse(parts[0]);
        final double sec = double.parse(parts[1]);
        return Duration(minutes: m, milliseconds: (sec * 1000).round());
      }
      final double sec = double.parse(parts.last);
      return Duration(milliseconds: (sec * 1000).round());
    } catch (_) {
      return null;
    }
  }

  static String _stripTags(String text) {
    return text
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll(RegExp(r'\{[^}]*\}'), '')
        .replaceAll(RegExp(r'\s+\n'), '\n')
        .trim();
  }
}
