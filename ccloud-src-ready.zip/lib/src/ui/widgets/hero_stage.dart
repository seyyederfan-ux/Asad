import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../services/favorites_service.dart';
import 'glass_button.dart';
import 'glass_panel.dart';

/// Large hero banner at the top of Home: cover image, dark scrim, meta tags,
/// synopsis and the `Stream Now / Download Links / Bookmark` action row.
/// Auto-rotates through the provided items with a soft cross-fade.
class HeroStage extends StatefulWidget {
  const HeroStage({
    super.key,
    required this.items,
    required this.onPlay,
    required this.onOpenLinks,
    required this.onOpen,
  });

  final List<MediaItem> items;
  final void Function(MediaItem) onPlay;
  final void Function(MediaItem) onOpenLinks;
  final void Function(MediaItem) onOpen;

  @override
  State<HeroStage> createState() => _HeroStageState();
}

class _HeroStageState extends State<HeroStage> {
  int _index = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    if (widget.items.length > 1) {
      _timer = Timer.periodic(const Duration(seconds: 9), (_) {
        if (!mounted) {
          return;
        }
        setState(() {
          _index = (_index + 1) % widget.items.length;
        });
      });
    }
  }

  @override
  void didUpdateWidget(covariant HeroStage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.items.length != widget.items.length) {
      _index = 0;
      _startTimer();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _quality {
    final MediaItem item = widget.items[_index];
    for (final Source s in item.sources) {
      final String q = s.quality.toLowerCase();
      if (q.contains('4k') || q.contains('2160')) {
        return s.quality;
      }
    }
    return item.sources.isNotEmpty ? item.sources.first.quality : '';
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final FavoritesService favorites = context.watch<FavoritesService>();
    if (widget.items.isEmpty) {
      return GlassPanel(
        radius: AppPalette.radiusCard,
        height: 360,
        child: Center(
          child: SizedBox(
            width: 220,
            child: const LinearProgressIndicator(minHeight: 3),
          ),
        ),
      );
    }

    final MediaItem item = widget.items[_index];
    final bool saved = favorites.containsSync(item);

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints c) {
        final double h = c.maxWidth < 900 ? 330 : 380;
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 650),
          switchInCurve: Curves.easeOut,
          switchOutCurve: Curves.easeIn,
          transitionBuilder: (Widget child, Animation<double> a) =>
              FadeTransition(opacity: a, child: child),
          child: GestureDetector(
            key: ValueKey<String>('hero-${item.type}-${item.id}'),
            onTap: () => widget.onOpen(item),
            child: Container(
              key: const ValueKey<String>('hero-content'),
              height: h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppPalette.radiusCard),
                border: Border.all(color: palette.border, width: 1),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x40000000),
                    blurRadius: 36,
                    offset: Offset(0, 16),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppPalette.radiusCard - 1),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      item.cover.isNotEmpty ? item.cover : item.image,
                      fit: BoxFit.cover,
                      filterQuality: FilterQuality.medium,
                      errorBuilder: (_, __, ___) =>
                          Container(color: palette.surfaceTint),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: const [0, 0.45, 1],
                          colors: [
                            (palette.dark
                                    ? const Color(0xFF08090D)
                                    : const Color(0xFFEEF2F6))
                                .withValues(alpha: 0.94),
                            (palette.dark
                                    ? const Color(0xFF08090D)
                                    : const Color(0xFFEEF2F6))
                                .withValues(alpha: 0.65),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          stops: const [0, 0.4, 1],
                          colors: [
                            (palette.dark
                                    ? const Color(0xFF08090D)
                                    : const Color(0xFFEEF2F6))
                                .withValues(alpha: 0.85),
                            Colors.transparent,
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),

                    // Content column (left side, bottom-aligned per spec)
                    Positioned.fill(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 600),
                          child: Padding(
                            padding: const EdgeInsets.all(38),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Row(
                                  children: [
                                    _HeroTag(
                                      label: item.type == 'serie'
                                          ? 'SERIES'
                                          : 'FEATURED',
                                      gradient: true,
                                    ),
                                    if (_quality.isNotEmpty) ...[
                                      const SizedBox(width: 8),
                                      _HeroTag(label: _quality.toUpperCase()),
                                    ],
                                    const SizedBox(width: 8),
                                    // .pill-tag.rating — amber IMDb chip
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 9,
                                        vertical: 3,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0x26EAB308),
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                          color: const Color(0x4DEAB308),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(
                                            Icons.star_rounded,
                                            size: 12,
                                            color: Color(0xFFFACC15),
                                          ),
                                          const SizedBox(width: 4),
                                          Text(
                                            item.imdb <= 0
                                                ? 'N/A IMDb'
                                                : '${item.imdb.toStringAsFixed(1)} IMDb',
                                            style: const TextStyle(
                                              color: Color(0xFFFACC15),
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                              letterSpacing: 0.3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  item.title,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: palette.textPrimary,
                                    fontSize: c.maxWidth < 900 ? 26 : 36,
                                    fontWeight: FontWeight.w800,
                                    height: 1.15,
                                    letterSpacing: -0.8,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  item.description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: palette.textSecondary,
                                    fontSize: 13,
                                    height: 1.55,
                                  ),
                                ),
                                const SizedBox(height: 22),
                                Row(
                                  children: [
                                    PrimaryGradientButton(
                                      label: 'Stream Now',
                                      icon: Icons.play_arrow_rounded,
                                      onPressed: () => widget.onPlay(item),
                                    ),
                                    const SizedBox(width: 10),
                                    GlassButton(
                                      label: 'Download Links',
                                      icon: Icons.download_rounded,
                                      onPressed: () => widget.onOpenLinks(item),
                                    ),
                                    const SizedBox(width: 10),
                                    _HeroBookmark(
                                      saved: saved,
                                      onTap: () async {
                                        final bool now = await favorites.toggle(
                                          item,
                                        );
                                        debugPrint('hero bookmark $now');
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Rotation dots
                    if (widget.items.length > 1)
                      Positioned(
                        right: 20,
                        bottom: 18,
                        child: Row(
                          children: List<Widget>.generate(widget.items.length, (
                            int i,
                          ) {
                            final bool active = i == _index;
                            return GestureDetector(
                              onTap: () => setState(() {
                                _index = i;
                                _startTimer();
                              }),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                width: active ? 22 : 8,
                                height: 8,
                                margin: const EdgeInsets.only(left: 6),
                                decoration: BoxDecoration(
                                  gradient: active
                                      ? AppPalette.accentGradient
                                      : null,
                                  color: active
                                      ? null
                                      : Colors.white.withValues(alpha: 0.35),
                                  borderRadius: BorderRadius.circular(99),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _HeroTag extends StatelessWidget {
  const _HeroTag({required this.label, this.gradient = false});

  final String label;
  final bool gradient;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        gradient: gradient ? palette.modeAccentGradient : null,
        color: gradient
            ? null
            : palette.cardHover.withValues(alpha: palette.dark ? 0.9 : 0.8),
        borderRadius: BorderRadius.circular(5),
        border: gradient
            ? null
            : Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}

class _HeroBookmark extends StatefulWidget {
  const _HeroBookmark({required this.saved, required this.onTap});

  final bool saved;
  final Future<void> Function() onTap;

  @override
  State<_HeroBookmark> createState() => _HeroBookmarkState();
}

class _HeroBookmarkState extends State<_HeroBookmark> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: _busy
            ? null
            : () async {
                setState(() => _busy = true);
                await widget.onTap();
                if (mounted) {
                  setState(() => _busy = false);
                }
              },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: widget.saved
                ? AppPalette.bookmark.withValues(alpha: 0.12)
                : palette.dark
                ? const Color(0x59161A24)
                : Colors.white.withValues(alpha: 0.6),
            borderRadius: BorderRadius.circular(9),
            border: Border.all(
              color: widget.saved ? palette.favActive : palette.borderStrong,
              width: 1,
            ),
          ),
          child: Icon(
            widget.saved ? Icons.bookmark : Icons.bookmark_border_rounded,
            size: 18,
            color: widget.saved ? palette.favActive : palette.textSecondary,
          ),
        ),
      ),
    );
  }
}
