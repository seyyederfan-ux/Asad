import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import 'glass_panel.dart';

/// A generic anchored frosted dropdown menu. Used for the sort menu in the
/// filter dock, quality pickers and any small choice list.
class GlassDropdown<T> extends StatefulWidget {
  const GlassDropdown({
    super.key,
    required this.items,
    required this.value,
    required this.onChanged,
    required this.labelBuilder,
    this.leadingIcon,
    this.width = 170,
    this.height = 38,
    this.iconSize = 16,
  });

  final List<DropdownItem<T>> items;
  final T value;
  final ValueChanged<T> onChanged;
  final String Function(DropdownItem<T>) labelBuilder;
  final IconData? leadingIcon;
  final double width;
  final double height;
  final double iconSize;

  @override
  State<GlassDropdown<T>> createState() => _GlassDropdownState<T>();
}

class _GlassDropdownState<T> extends State<GlassDropdown<T>> {
  final LayerLink _link = LayerLink();
  OverlayEntry? _entry;
  bool _open = false;

  bool get _isOpen => _entry != null;

  void _toggle() {
    if (_isOpen) {
      _close();
    } else {
      _open = true;
      _entry = OverlayEntry(builder: _buildOverlay);
      Overlay.of(context).insert(_entry!);
      setState(() {});
    }
  }

  void _close() {
    _entry?.remove();
    _entry = null;
    _open = false;
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _entry?.remove();
    _entry = null;
    super.dispose();
  }

  Widget _buildOverlay(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Stack(
      children: [
        // Transparent barrier closes the menu on outside taps.
        Positioned.fill(
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: _close,
            child: const SizedBox.expand(),
          ),
        ),
        CompositedTransformFollower(
          link: _link,
          targetAnchor: Alignment.bottomLeft,
          followerAnchor: Alignment.topLeft,
          offset: const Offset(0, 6),
          showWhenUnlinked: false,
          child: GlassPanel(
            radius: 14,
            strong: true,
            blur: 28,
            width: widget.width,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.45),
                blurRadius: 30,
                offset: const Offset(0, 12),
              ),
            ],
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final DropdownItem<T> item in widget.items)
                  _MenuItemTile<T>(
                    item: item,
                    label: widget.labelBuilder(item),
                    selected: item.value == widget.value,
                    palette: palette,
                    onTap: () {
                      widget.onChanged(item.value);
                      _close();
                    },
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final DropdownItem<T> current = widget.items.firstWhere(
      (DropdownItem<T> i) => i.value == widget.value,
      orElse: () => widget.items.first,
    );
    return CompositedTransformTarget(
      link: _link,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: _toggle,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: widget.height,
            width: widget.width,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: _open ? palette.surfaceTint : palette.panel,
              borderRadius: BorderRadius.circular(AppPalette.radiusButton),
              border: Border.all(
                color: _open
                    ? AppPalette.accentStart.withValues(alpha: 0.6)
                    : palette.border,
                width: 1,
              ),
            ),
            child: Row(
              children: [
                if (widget.leadingIcon != null) ...[
                  Icon(
                    widget.leadingIcon,
                    size: widget.iconSize,
                    color: palette.textSecondary,
                  ),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: Text(
                    widget.labelBuilder(current),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: palette.textPrimary,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                AnimatedRotation(
                  turns: _isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 160),
                  child: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    size: 17,
                    color: palette.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DropdownItem<T> {
  const DropdownItem({required this.value, required this.label, this.icon});

  final T value;
  final String label;
  final IconData? icon;
}

class _MenuItemTile<T> extends StatefulWidget {
  const _MenuItemTile({
    required this.item,
    required this.label,
    required this.selected,
    required this.onTap,
    required this.palette,
  });

  final DropdownItem<T> item;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final AppPalette palette;

  @override
  State<_MenuItemTile<T>> createState() => _MenuItemTileState<T>();
}

class _MenuItemTileState<T> extends State<_MenuItemTile<T>> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: _hover
                ? AppPalette.accentStart.withValues(alpha: 0.16)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Row(
            children: [
              if (widget.item.icon != null) ...[
                Icon(
                  widget.item.icon,
                  size: 15,
                  color: widget.selected
                      ? AppPalette.accentStart
                      : palette.textSecondary,
                ),
                const SizedBox(width: 9),
              ],
              Expanded(
                child: Text(
                  widget.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: widget.selected
                        ? (palette.dark
                              ? AppPalette.darkTextPrimary
                              : palette.textPrimary)
                        : palette.textPrimary,
                    fontSize: 12.5,
                    fontWeight: widget.selected
                        ? FontWeight.w700
                        : FontWeight.w500,
                  ),
                ),
              ),
              if (widget.selected)
                const Icon(
                  Icons.check_rounded,
                  size: 15,
                  color: AppPalette.accentStart,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
