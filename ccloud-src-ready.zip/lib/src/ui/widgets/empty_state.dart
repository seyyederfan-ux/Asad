import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import 'glass_button.dart';

/// Empty state — 1:1 with `.fav-empty-state`: 64px circular glass icon,
/// 16px w700 headline, 12px faint caption (max 320px) and an optional
/// primary CTA.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.ctaLabel,
    this.onCta,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String? ctaLabel;
  final VoidCallback? onCta;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 60),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // .fav-empty-icon — 64px glass circle
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: palette.card,
                border: Border.all(color: palette.border),
              ),
              child: Icon(icon, size: 28, color: palette.textFaint),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: palette.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 320),
              child: Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: palette.textFaint,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ),
            if (ctaLabel != null && onCta != null) ...[
              const SizedBox(height: 16),
              PrimaryGradientButton(
                label: ctaLabel!,
                icon: Icons.compass_calibration_rounded,
                onPressed: onCta,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
