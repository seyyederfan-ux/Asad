import 'dart:io';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../platform/vlc_launcher.dart';
import '../../services/download_manager.dart';
import '../../services/download_task.dart';
import '../../services/toast_service.dart';
import 'glass_panel.dart';

/// Frosted full-screen modal — 1:1 with `.modal-veil` + `.modal-card`
/// (560px, r16, 22px padding): quality rows with grade + format pill +
/// meta line, `Copy URL` / `In-App DL` compact actions and the footer note.
class DownloadMirrorsModal extends StatefulWidget {
  const DownloadMirrorsModal({
    super.key,
    required this.title,
    required this.sources,
    required this.onCopy,
  });

  final String title;
  final List<Source> sources;
  final void Function(String url) onCopy;

  /// Blurred glass veil + centered modal card.
  static Future<void> show(
    BuildContext context, {
    required String title,
    required List<Source> sources,
    required void Function(String url) onCopy,
  }) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Download mirrors',
      barrierColor: palette.modalScrim,
      transitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (_, __, ___) =>
          DownloadMirrorsModal(title: title, sources: sources, onCopy: onCopy),
      transitionBuilder:
          (BuildContext ctx, Animation<double> a, __, Widget? child) {
            if (child == null) {
              return const SizedBox.shrink();
            }
            return FadeTransition(
              opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: Tween<double>(
                  begin: 0.96,
                  end: 1,
                ).animate(CurvedAnimation(parent: a, curve: Curves.easeOut)),
                child: child,
              ),
            );
          },
    );
  }

  @override
  State<DownloadMirrorsModal> createState() => _DownloadMirrorsModalState();
}

class _DownloadMirrorsModalState extends State<DownloadMirrorsModal> {
  final Map<int, String?> _sizes = <int, String?>{};

  @override
  void initState() {
    super.initState();
    _probeSizes();
  }

  Future<void> _probeSizes() async {
    for (int i = 0; i < widget.sources.length; i++) {
      final Source s = widget.sources[i];
      if (_sizes.containsKey(i)) {
        continue;
      }
      final String? size = await _probeSize(s.url);
      if (!mounted) {
        return;
      }
      setState(() => _sizes[i] = size);
    }
  }

  Future<String?> _probeSize(String url) async {
    try {
      final HttpClient client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 12);
      try {
        final HttpClientRequest req = await client.headUrl(Uri.parse(url));
        final HttpClientResponse res = await req.close().timeout(
          const Duration(seconds: 12),
        );
        final String? len = res.headers.value(HttpHeaders.contentLengthHeader);
        if (res.statusCode >= 200 && res.statusCode < 400 && len != null) {
          final int bytes = int.tryParse(len) ?? 0;
          if (bytes > 0) {
            return formatBytes(bytes);
          }
        }
        return null;
      } finally {
        client.close(force: true);
      }
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    // `.modal-veil` — full-screen backdrop blur(16px) behind the card.
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 620),
            child: GlassPanel(
              radius: AppPalette.radiusCard,
              color: palette.glassElevated,
              blur: 35,
              width: 560,
              padding: const EdgeInsets.all(22),
              boxShadow: [
                BoxShadow(
                  color: palette.dark
                      ? const Color(0x80000000)
                      : const Color(0x590F172A),
                  blurRadius: 60,
                  offset: const Offset(0, 25),
                ),
              ],
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ---- .modal-top ----
                  Row(
                    children: [
                      Icon(
                        Icons.download_rounded,
                        size: 18,
                        color: palette.textPrimary,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Download: ${widget.title}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: palette.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      MouseRegion(
                        cursor: SystemMouseCursors.click,
                        child: GestureDetector(
                          onTap: () => Navigator.of(context).pop(),
                          child: Icon(
                            Icons.close_rounded,
                            size: 17,
                            color: palette.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ---- .modal-links-flow ----
                  Flexible(
                    child: widget.sources.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 28),
                            child: Text(
                              'No mirrors available for this title yet.',
                              style: TextStyle(
                                color: palette.textSecondary,
                                fontSize: 13,
                              ),
                            ),
                          )
                        : ListView.separated(
                            shrinkWrap: true,
                            padding: EdgeInsets.zero,
                            itemCount: widget.sources.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 9),
                            itemBuilder: (BuildContext context, int index) {
                              final Source s = widget.sources[index];
                              return _MirrorRow(
                                source: s,
                                size: _sizes[index],
                                palette: palette,
                                onCopy: () {
                                  widget.onCopy(s.url);
                                  context.read<ToastService>().success(
                                    'Direct download mirror copied to clipboard!',
                                  );
                                },
                                onDownload: () async {
                                  final DownloadTask? t = await DownloadManager
                                      .instance
                                      .enqueue(
                                        url: s.url,
                                        title: widget.title,
                                        quality: s.quality,
                                      );
                                  if (!context.mounted) {
                                    return;
                                  }
                                  Navigator.of(context).pop();
                                  if (t == null) {
                                    context.read<ToastService>().info(
                                      'Already in the download queue',
                                    );
                                  } else {
                                    context.read<ToastService>().success(
                                      'Added ${s.quality} download to task queue',
                                    );
                                  }
                                },
                                onVlc: () async {
                                  Navigator.of(context).pop();
                                  context.read<ToastService>().info(
                                    'Opening in VLC…',
                                  );
                                  await VLCLauncher.launchInVLC(s.url);
                                },
                              );
                            },
                          ),
                  ),
                  if (widget.sources.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    // Footer note
                    Text(
                      'Direct CDN mirrors support Resume and high-speed '
                      'multi-threaded accelerators.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: palette.textFaint, fontSize: 11),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// `.dl-row` — r10 glass row: grade + format pill + meta, compact actions.
class _MirrorRow extends StatefulWidget {
  const _MirrorRow({
    required this.source,
    required this.size,
    required this.palette,
    required this.onCopy,
    required this.onDownload,
    required this.onVlc,
  });

  final Source source;
  final String? size;
  final AppPalette palette;
  final VoidCallback onCopy;
  final VoidCallback onDownload;
  final VoidCallback onVlc;

  @override
  State<_MirrorRow> createState() => _MirrorRowState();
}

class _MirrorRowState extends State<_MirrorRow> {
  bool _hover = false;

  bool get _isUhd {
    final String q = widget.source.quality.toLowerCase();
    return q.contains('4k') || q.contains('2160');
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: _hover ? palette.cardHover : palette.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: _hover ? palette.borderHover : palette.border,
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          widget.source.quality.isEmpty
                              ? 'Unknown quality'
                              : widget.source.quality,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: palette.textPrimary,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      if ((widget.source.type).isNotEmpty) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            gradient: _isUhd ? AppPalette.accentGradient : null,
                            color: _isUhd ? null : palette.cardHover,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            widget.source.type.toUpperCase(),
                            style: TextStyle(
                              color: _isUhd
                                  ? Colors.white
                                  : palette.textSecondary,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${widget.size ?? 'size probing…'} • CDN direct link',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: palette.textFaint, fontSize: 10.5),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            _CompactAction(
              label: 'Copy URL',
              primary: true,
              palette: palette,
              onTap: widget.onCopy,
            ),
            const SizedBox(width: 6),
            _CompactAction(
              label: 'In-App DL',
              palette: palette,
              onTap: widget.onDownload,
            ),
            const SizedBox(width: 6),
            _CompactAction(label: 'VLC', palette: palette, onTap: widget.onVlc),
          ],
        ),
      ),
    );
  }
}

/// `.btn-compact` — 11.5px compact action; primary = accent gradient.
class _CompactAction extends StatefulWidget {
  const _CompactAction({
    required this.label,
    required this.palette,
    required this.onTap,
    this.primary = false,
  });

  final String label;
  final AppPalette palette;
  final VoidCallback onTap;
  final bool primary;

  @override
  State<_CompactAction> createState() => _CompactActionState();
}

class _CompactActionState extends State<_CompactAction> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 130),
          height: 28,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: widget.primary ? AppPalette.accentGradient : null,
            color: widget.primary
                ? null
                : _hover
                ? palette.cardHover
                : palette.card,
            borderRadius: BorderRadius.circular(6),
            border: widget.primary
                ? null
                : Border.all(
                    color: _hover ? palette.borderHover : palette.border,
                  ),
          ),
          child: Text(
            widget.label,
            style: TextStyle(
              color: widget.primary ? Colors.white : palette.textPrimary,
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
