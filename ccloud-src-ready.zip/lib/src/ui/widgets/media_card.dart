import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../services/favorites_service.dart';

/// Vertical poster card — 1:1 with `.media-card` (r12, 2/3 thumb, details
/// strip below): hover lifts the card 4px, the cover zooms 1.05 behind a
/// frosted overlay with a 44px play FAB + Download pill, a sky quality badge
/// sits top-left and a quick bookmark circle top-right.
class MediaCard extends StatefulWidget {
  const MediaCard({
    super.key,
    required this.item,
    required this.onOpen,
    required this.onPlay,
    this.onLinks,
    this.width = 180,
  });

  final MediaItem item;
  final VoidCallback onOpen;
  final VoidCallback onPlay;
  final VoidCallback? onLinks;
  final double width;

  @override
  State<MediaCard> createState() => _MediaCardState();
}

class _MediaCardState extends State<MediaCard> {
  bool _hover = false;

  String get _bestQuality {
    for (final Source s in widget.item.sources) {
      final String q = s.quality.toLowerCase();
      if (q.contains('4k') || q.contains('2160')) {
        return s.quality;
      }
    }
    if (widget.item.sources.isNotEmpty) {
      return widget.item.sources.first.quality;
    }
    return '';
  }

  String get _metaLine {
    final List<String> parts = <String>[
      if (widget.item.year > 0) '${widget.item.year}',
      ...widget.item.genres.take(1).map((Genre g) => g.title),
    ];
    return parts.join(' • ');
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final FavoritesService favorites = context.watch<FavoritesService>();
    final bool saved = favorites.containsSync(widget.item);
    final String quality = _bestQuality;
    final double thumbH = widget.width * 1.5; // aspect 2/3

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onOpen,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          width: widget.width,
          transform: Matrix4.translationValues(0, _hover ? -4 : 0, 0),
          decoration: BoxDecoration(
            color: _hover ? palette.cardHover : palette.card,
            borderRadius: BorderRadius.circular(AppPalette.radiusCardSmall),
            border: Border.all(
              color: _hover ? palette.borderHover : palette.border,
              width: 1,
            ),
            boxShadow: _hover
                ? palette.cardHoverShadow
                : const <BoxShadow>[
                    BoxShadow(
                      color: Color(0x14000000),
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ---- Thumb (.card-thumb-wrap, aspect 2/3) ----
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(AppPalette.radiusCardSmall - 1),
                ),
                child: SizedBox(
                  height: thumbH,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      // .card-thumb — scale 1.05 on hover
                      AnimatedScale(
                        scale: _hover ? 1.05 : 1.0,
                        duration: const Duration(milliseconds: 350),
                        curve: Curves.easeOut,
                        child: Image.network(
                          widget.item.cover.isNotEmpty
                              ? widget.item.cover
                              : widget.item.image,
                          fit: BoxFit.cover,
                          filterQuality: FilterQuality.medium,
                          errorBuilder: (_, __, ___) => Container(
                            color: palette.inputBg,
                            child: Icon(
                              Icons.movie_creation_outlined,
                              size: 36,
                              color: palette.textFaint,
                            ),
                          ),
                        ),
                      ),

                      // .card-overlay — frosted, fades in on hover
                      AnimatedOpacity(
                        opacity: _hover ? 1 : 0,
                        duration: const Duration(milliseconds: 200),
                        child: ClipRect(
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                            child: Container(
                              color: const Color(
                                0xA60A0C12,
                              ), // rgba(10,12,18,.65)
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // .overlay-play-btn — 44px gradient FAB
                                  _OverlayPlayButton(onTap: widget.onPlay),
                                  if (widget.onLinks != null) ...[
                                    const SizedBox(height: 8),
                                    _OverlayDownloadButton(
                                      onTap: widget.onLinks!,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      // .card-corner-badge — sky blue, top-left
                      if (quality.isNotEmpty)
                        Positioned(
                          top: 8,
                          left: 8,
                          child: _CornerBadge(label: quality),
                        ),

                      // .card-fav-action — top-right 28px circle
                      Positioned(
                        top: 8,
                        right: 8,
                        child: _QuickBookmark(
                          saved: saved,
                          onToggle: () async {
                            final bool nowSaved = await favorites.toggle(
                              widget.item,
                            );
                            debugPrint(
                              'bookmark ${widget.item.title}: $nowSaved',
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ---- Details (.card-details, 10px 12px) ----
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.item.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _metaLine,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: palette.textFaint,
                              fontSize: 11,
                            ),
                          ),
                        ),
                        const Icon(
                          Icons.star_rounded,
                          size: 11,
                          color: AppPalette.warning,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          widget.item.imdb <= 0
                              ? 'N/A'
                              : widget.item.imdb.toStringAsFixed(1),
                          style: TextStyle(
                            color: palette.textFaint,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// `.overlay-play-btn` — 44px gradient circle with glow.
class _OverlayPlayButton extends StatefulWidget {
  const _OverlayPlayButton({required this.onTap});

  final VoidCallback onTap;

  @override
  State<_OverlayPlayButton> createState() => _OverlayPlayButtonState();
}

class _OverlayPlayButtonState extends State<_OverlayPlayButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _hover ? 1.1 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: palette.modeAccentGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: palette.glowColor,
                  blurRadius: 18,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.play_arrow_rounded,
              size: 22,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

/// `.overlay-dl-btn` — frosted white pill (`Download`).
class _OverlayDownloadButton extends StatefulWidget {
  const _OverlayDownloadButton({required this.onTap});

  final VoidCallback onTap;

  @override
  State<_OverlayDownloadButton> createState() => _OverlayDownloadButtonState();
}

class _OverlayDownloadButtonState extends State<_OverlayDownloadButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 26,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: _hover ? Colors.white : Colors.white.withValues(alpha: 0.16),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _hover
                  ? Colors.white
                  : Colors.white.withValues(alpha: 0.25),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.download_rounded,
                size: 12,
                color: _hover ? const Color(0xFF0F172A) : Colors.white,
              ),
              const SizedBox(width: 5),
              Text(
                'Download',
                style: TextStyle(
                  color: _hover ? const Color(0xFF0F172A) : Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// `.card-corner-badge` — 9.5px sky-blue chip on dark scrim.
class _CornerBadge extends StatelessWidget {
  const _CornerBadge({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: const Color(0xB30F172A), // rgba(15,23,42,0.7)
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: const Color(0x4D38BDF8)), // sky @ 0.3
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: AppPalette.infoSky,
          fontSize: 9.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}

/// `.card-fav-action` — 28px glass circle; active = red fill + red ring.
class _QuickBookmark extends StatefulWidget {
  const _QuickBookmark({required this.saved, required this.onToggle});

  final bool saved;
  final Future<void> Function() onToggle;

  @override
  State<_QuickBookmark> createState() => _QuickBookmarkState();
}

class _QuickBookmarkState extends State<_QuickBookmark> {
  bool _busy = false;
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: _busy
            ? null
            : () async {
                setState(() => _busy = true);
                await widget.onToggle();
                if (mounted) {
                  setState(() => _busy = false);
                }
              },
        child: ClipRect(
          child: AnimatedScale(
            scale: _hover ? 1.15 : 1.0,
            duration: const Duration(milliseconds: 150),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: widget.saved
                    ? AppPalette.bookmark.withValues(alpha: 0.25)
                    : const Color(0xA60F172A), // rgba(15,23,42,0.65)
                shape: BoxShape.circle,
                border: Border.all(
                  color: widget.saved
                      ? AppPalette.bookmark
                      : Colors.white.withValues(alpha: 0.2),
                ),
              ),
              child: Icon(
                widget.saved ? Icons.bookmark : Icons.bookmark_border_rounded,
                size: 14,
                color: widget.saved
                    ? palette.favActive
                    : _hover
                    ? palette.favActive
                    : Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
