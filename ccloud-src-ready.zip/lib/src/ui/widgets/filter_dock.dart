import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import 'glass_dropdown.dart';

/// The catalog filter bar: horizontally scrolling genre pills plus a frosted
/// sort dropdown (Default / Year / IMDb).
class FilterDock extends StatelessWidget {
  const FilterDock({
    super.key,
    required this.genres,
    required this.selectedGenreId,
    required this.selectedFilter,
    required this.onGenreSelected,
    required this.onFilterSelected,
    required this.sortItems,
  });

  final List<Genre> genres;
  final int selectedGenreId;
  final FilterType selectedFilter;
  final ValueChanged<int> onGenreSelected;
  final ValueChanged<FilterType> onFilterSelected;
  final List<DropdownItem<FilterType>> sortItems;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 30,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(vertical: 1),
              itemCount: genres.length,
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (BuildContext context, int index) {
                final Genre g = genres[index];
                final bool selected = g.id == selectedGenreId;
                return _GenrePill(
                  label: g.title,
                  selected: selected,
                  palette: palette,
                  onTap: () => onGenreSelected(g.id),
                );
              },
            ),
          ),
        ),
        const SizedBox(width: 12),
        GlassDropdown<FilterType>(
          items: sortItems,
          value: selectedFilter,
          onChanged: onFilterSelected,
          labelBuilder: (DropdownItem<FilterType> i) => i.label,
          leadingIcon: Icons.sort_rounded,
          width: 160,
          height: 30,
        ),
      ],
    );
  }
}

class _GenrePill extends StatefulWidget {
  const _GenrePill({
    required this.label,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  State<_GenrePill> createState() => _GenrePillState();
}

class _GenrePillState extends State<_GenrePill> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 13),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: widget.selected ? AppPalette.accentGradient : null,
            color: widget.selected ? null : palette.card,
            borderRadius: BorderRadius.circular(AppPalette.radiusPill),
            border: Border.all(
              color: widget.selected
                  ? Colors.transparent
                  : _hover
                  ? palette.borderHover
                  : palette.border,
              width: 1,
            ),
            boxShadow: widget.selected
                ? [
                    BoxShadow(
                      color: AppPalette.glow.withValues(alpha: 0.7),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Text(
            widget.label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: widget.selected
                  ? Colors.white
                  : _hover
                  ? palette.textPrimary
                  : palette.textSecondary,
              fontSize: 12,
              fontWeight: widget.selected ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
