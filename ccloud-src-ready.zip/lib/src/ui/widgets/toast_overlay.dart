import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../services/toast_service.dart';
import 'glass_panel.dart';

/// Bottom-right neon-bordered toast stack fed by [ToastService].
class ToastOverlay extends StatelessWidget {
  const ToastOverlay({super.key});

  Color _color(ToastType t) {
    switch (t) {
      case ToastType.success:
        return AppPalette.success;
      case ToastType.warning:
        return AppPalette.warning;
      case ToastType.error:
        return AppPalette.danger;
      case ToastType.info:
        return AppPalette.infoSky;
    }
  }

  IconData _icon(ToastType t) {
    switch (t) {
      case ToastType.success:
        return Icons.check_circle_rounded;
      case ToastType.warning:
        return Icons.warning_amber_rounded;
      case ToastType.error:
        return Icons.error_rounded;
      case ToastType.info:
        return Icons.info_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final ToastService toasts = context.watch<ToastService>();
    if (toasts.items.isEmpty) {
      return const SizedBox.shrink();
    }
    return Positioned(
      right: 24,
      bottom: 24,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final ToastMessage t in toasts.items)
            _ToastCard(
              key: ValueKey<String>(t.id),
              message: t.message,
              type: t.type,
              accent: _color(t.type),
              icon: _icon(t.type),
              onDismiss: () => toasts.dismiss(t.id),
            ),
        ],
      ),
    );
  }
}

class _ToastCard extends StatefulWidget {
  const _ToastCard({
    super.key,
    required this.message,
    required this.type,
    required this.accent,
    required this.icon,
    required this.onDismiss,
  });

  final String message;
  final ToastType type;
  final Color accent;
  final IconData icon;
  final VoidCallback onDismiss;

  @override
  State<_ToastCard> createState() => _ToastCardState();
}

class _ToastCardState extends State<_ToastCard> {
  bool _visible = false;

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 20), () {
      if (mounted) {
        setState(() => _visible = true);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: AnimatedSlide(
        offset: _visible ? Offset.zero : const Offset(0.2, 0),
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
        child: AnimatedOpacity(
          opacity: _visible ? 1 : 0,
          duration: const Duration(milliseconds: 240),
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: widget.onDismiss,
              child: GlassPanel(
                radius: 9,
                color: palette.glassElevated,
                blur: 20,
                borderColor: widget.accent,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.4),
                    blurRadius: 30,
                    offset: const Offset(0, 10),
                  ),
                ],
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 10,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(widget.icon, size: 15, color: widget.accent),
                    const SizedBox(width: 8),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 320),
                      child: Text(
                        widget.message,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
