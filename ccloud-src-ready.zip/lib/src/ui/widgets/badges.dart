import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Quality pill (`4K HDR`, `1080p x265`, `720p`) — 4K renders with the neon
/// accent gradient, lower tiers render as neutral glass chips.
class QualityBadge extends StatelessWidget {
  const QualityBadge({super.key, required this.quality, this.compact = false});

  final String quality;
  final bool compact;

  bool get _isUhd {
    final String q = quality.toLowerCase();
    return q.contains('4k') || q.contains('2160');
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final String label = quality.trim().isEmpty ? 'HD' : quality.trim();
    final Widget chip = Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 7 : 9,
        vertical: compact ? 3 : 4,
      ),
      decoration: BoxDecoration(
        gradient: _isUhd ? AppPalette.accentGradient : null,
        color: _isUhd ? null : palette.panelStrong,
        borderRadius: BorderRadius.circular(7),
        border: Border.all(
          color: _isUhd ? Colors.white.withValues(alpha: 0.22) : palette.border,
          width: 1,
        ),
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: compact ? 9.5 : 10.5,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
          color: _isUhd ? Colors.white : palette.textPrimary,
        ),
      ),
    );
    if (_isUhd) {
      return DecoratedBox(
        decoration: BoxDecoration(
          boxShadow: [BoxShadow(color: AppPalette.glow, blurRadius: 10)],
        ),
        child: chip,
      );
    }
    return chip;
  }
}

/// Small informational pill used across hero and detail headers
/// (year, IMDb, duration, genres, audio tags...).
class MetaChip extends StatelessWidget {
  const MetaChip({
    super.key,
    required this.label,
    this.icon,
    this.color,
    this.background,
  });

  final String label;
  final IconData? icon;
  final Color? color;
  final Color? background;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: background ?? palette.panelSoft,
        borderRadius: BorderRadius.circular(AppPalette.radiusPill),
        border: Border.all(color: palette.border, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color ?? AppPalette.warning),
            const SizedBox(width: 5),
          ],
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: color ?? palette.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// IMDb score chip — amber star + bold score.
class ImdbChip extends StatelessWidget {
  const ImdbChip({super.key, required this.score});

  final double score;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: palette.panelSoft,
        borderRadius: BorderRadius.circular(AppPalette.radiusPill),
        border: Border.all(color: palette.border, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, size: 13, color: AppPalette.warning),
          const SizedBox(width: 4),
          Text(
            score <= 0 ? 'N/A' : score.toStringAsFixed(1),
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
              color: palette.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
