import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../services/continue_watching_service.dart';

/// Horizontal "Continue Watching" card — 1:1 with `.continue-card`:
/// 16/9 thumb with a 3px gradient progress bar pinned to its bottom edge,
/// then a details strip (title + episode/remaining caption).
class ContinueCard extends StatefulWidget {
  const ContinueCard({
    super.key,
    required this.progress,
    required this.onPlay,
    required this.onRemove,
    this.width = 280,
  });

  final WatchProgress progress;
  final VoidCallback onPlay;
  final VoidCallback onRemove;
  final double width;

  @override
  State<ContinueCard> createState() => _ContinueCardState();
}

class _ContinueCardState extends State<ContinueCard> {
  bool _hover = false;

  String _remainingLabel() {
    final Duration r = widget.progress.remaining;
    if (r.inHours >= 1) {
      return '${r.inHours}h ${r.inMinutes % 60}m left';
    }
    return '${r.inMinutes}m left';
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final double thumbH = widget.width * 9 / 16; // aspect 16/9

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onPlay,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          width: widget.width,
          transform: Matrix4.translationValues(0, _hover ? -3 : 0, 0),
          decoration: BoxDecoration(
            color: _hover ? palette.cardHover : palette.card,
            borderRadius: BorderRadius.circular(AppPalette.radiusCardSmall),
            border: Border.all(
              color: _hover ? palette.borderHover : palette.border,
              width: 1,
            ),
            boxShadow: _hover
                ? palette.cardHoverShadow
                : const <BoxShadow>[
                    BoxShadow(
                      color: Color(0x14000000),
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ---- Thumb (.continue-thumb-box 16/9) ----
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(AppPalette.radiusCardSmall - 1),
                ),
                child: SizedBox(
                  height: thumbH,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        widget.progress.cover.isNotEmpty
                            ? widget.progress.cover
                            : widget.progress.image,
                        fit: BoxFit.cover,
                        filterQuality: FilterQuality.medium,
                        errorBuilder: (_, __, ___) =>
                            Container(color: palette.inputBg),
                      ),

                      // Hover play chip
                      AnimatedOpacity(
                        opacity: _hover ? 1 : 0,
                        duration: const Duration(milliseconds: 160),
                        child: Center(
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              gradient: palette.modeAccentGradient,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: palette.glowColor,
                                  blurRadius: 18,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.play_arrow_rounded,
                              size: 24,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),

                      // Remove chip
                      Positioned(
                        top: 8,
                        right: 8,
                        child: AnimatedOpacity(
                          opacity: _hover ? 1 : 0,
                          duration: const Duration(milliseconds: 140),
                          child: GestureDetector(
                            onTap: widget.onRemove,
                            child: Container(
                              width: 26,
                              height: 26,
                              decoration: BoxDecoration(
                                color: const Color(0xA60F172A),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.2),
                                ),
                              ),
                              child: const Icon(
                                Icons.close_rounded,
                                size: 14,
                                color: Color(0xFFFCA5A5),
                              ),
                            ),
                          ),
                        ),
                      ),

                      // .continue-bar-wrap — 3px bar pinned at thumb bottom
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          height: 3,
                          color: Colors.black.withValues(alpha: 0.35),
                          alignment: Alignment.centerLeft,
                          child: FractionallySizedBox(
                            widthFactor: widget.progress.progress.clamp(
                              0.01,
                              1.0,
                            ),
                            child: Container(
                              height: 3,
                              decoration: BoxDecoration(
                                gradient: palette.modeAccentGradient,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ---- Details (.card-details) ----
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.progress.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Text(
                          widget.progress.mediaType == 'serie'
                              ? 'Series'
                              : 'Movie',
                          style: TextStyle(
                            color: palette.textFaint,
                            fontSize: 11,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          _remainingLabel(),
                          style: TextStyle(
                            color: palette.textFaint,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
