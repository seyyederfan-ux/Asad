import 'dart:ui';

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Frosted-glass surface with backdrop blur, translucent fill, thin hairline
/// border and soft ambient shadow — the core Fluent-2 acrylic primitive.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.radius = AppPalette.radiusCard,
    this.padding,
    this.strong = false,
    this.soft = false,
    this.blur = 24,
    this.color,
    this.borderColor,
    this.boxShadow,
    this.gradient,
    this.borderRadius,
    this.width,
    this.height,
    this.alignment,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry? padding;
  final bool strong;
  final bool soft;
  final double blur;
  final Color? color;
  final Color? borderColor;
  final List<BoxShadow>? boxShadow;
  final Gradient? gradient;
  final BorderRadius? borderRadius;
  final double? width;
  final double? height;
  final AlignmentGeometry? alignment;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final Color fill =
        color ??
        (strong
            ? palette.panelStrong
            : soft
            ? palette.panelSoft
            : palette.panel);
    final BorderRadius br = borderRadius ?? BorderRadius.circular(radius);

    return Container(
      width: width,
      height: height,
      alignment: alignment,
      decoration: BoxDecoration(
        borderRadius: br,
        boxShadow: boxShadow ?? palette.panelShadow,
      ),
      child: ClipRRect(
        borderRadius: br,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Container(
            padding: padding,
            alignment: alignment,
            decoration: BoxDecoration(
              color: fill,
              gradient: gradient,
              borderRadius: br,
              border: Border.all(
                color: borderColor ?? palette.border,
                width: 1,
              ),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

/// Non-blurred translucent panel — used inside dense grids where stacking
/// many BackdropFilters would cost GPU time.
class GlassSurface extends StatelessWidget {
  const GlassSurface({
    super.key,
    required this.child,
    this.radius = AppPalette.radiusCard,
    this.padding,
    this.strong = false,
    this.color,
    this.borderColor,
    this.gradient,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry? padding;
  final bool strong;
  final Color? color;
  final Color? borderColor;
  final Gradient? gradient;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final Color fill = color ?? (strong ? palette.panelStrong : palette.panel);
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: fill,
        gradient: gradient,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor ?? palette.border, width: 1),
      ),
      child: child,
    );
  }
}

/// Full-bleed ambient background: base color + purple/blue radial nebula
/// glows painted behind the entire window.
class AppBackground extends StatelessWidget {
  const AppBackground({super.key});

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: [
          ColoredBox(color: palette.background),
          for (final RadialGradient g in palette.ambientGradients)
            DecoratedBox(decoration: BoxDecoration(gradient: g)),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [0.0, 0.35, 1.0],
                colors: [
                  Colors.white.withValues(alpha: palette.dark ? 0.02 : 0.10),
                  Colors.transparent,
                  (palette.dark ? Colors.black : const Color(0xFF0B1220))
                      .withValues(alpha: 0.18),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
