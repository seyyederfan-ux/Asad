import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Gradient accent button (`Stream Now`, `In-App DL`...) with hover lift and
/// neon glow — radius 9 per the design system.
class PrimaryGradientButton extends StatefulWidget {
  const PrimaryGradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.height = 40,
    this.minWidth = 0,
    this.fontSize = 13,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final double height;
  final double minWidth;
  final double fontSize;

  @override
  State<PrimaryGradientButton> createState() => _PrimaryGradientButtonState();
}

class _PrimaryGradientButtonState extends State<PrimaryGradientButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final bool disabled = widget.onPressed == null;
    return MouseRegion(
      cursor: disabled ? SystemMouseCursors.basic : SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
        height: widget.height,
        constraints: BoxConstraints(minWidth: widget.minWidth),
        transform: Matrix4.translationValues(
          0,
          _hover && !disabled ? -1.5 : 0,
          0,
        ),
        decoration: BoxDecoration(
          gradient: AppPalette.accentGradient,
          borderRadius: BorderRadius.circular(AppPalette.radiusButton),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.18),
            width: 1,
          ),
          boxShadow: [
            if (!disabled)
              BoxShadow(
                color: AppPalette.glow.withValues(alpha: _hover ? 0.85 : 0.45),
                blurRadius: _hover ? 22 : 16,
                offset: const Offset(0, 4),
              ),
          ],
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            onTap: disabled ? null : widget.onPressed,
            borderRadius: BorderRadius.circular(AppPalette.radiusButton),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, size: 15, color: Colors.white),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: Text(
                      widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: widget.fontSize,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Frosted ghost button used for secondary actions (`Download Links`, ...).
class GlassButton extends StatefulWidget {
  const GlassButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.height = 40,
    this.accent = false,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final double height;
  final bool accent;

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final bool disabled = widget.onPressed == null;
    return MouseRegion(
      cursor: disabled ? SystemMouseCursors.basic : SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
        height: widget.height,
        transform: Matrix4.translationValues(
          0,
          _hover && !disabled ? -1.5 : 0,
          0,
        ),
        decoration: BoxDecoration(
          color: _hover ? palette.cardHover : palette.card,
          borderRadius: BorderRadius.circular(AppPalette.radiusButton),
          border: Border.all(
            color: _hover ? palette.borderHover : palette.borderStrong,
            width: 1,
          ),
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            onTap: disabled ? null : widget.onPressed,
            borderRadius: BorderRadius.circular(AppPalette.radiusButton),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (widget.icon != null) ...[
                    Icon(
                      widget.icon,
                      size: 15,
                      color: _hover
                          ? palette.textPrimary
                          : palette.textSecondary,
                    ),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: Text(
                      widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Circular frosted icon button (window controls, card overlays, HUD...).
/// `flat: true` renders the borderless `.ctrl-icon-btn` player style —
/// transparent, opacity .85, hover = accent tint + 1.1 scale.
class GlassIconButton extends StatefulWidget {
  const GlassIconButton({
    super.key,
    required this.icon,
    this.onPressed,
    this.tooltip,
    this.size = 38,
    this.iconSize = 18,
    this.danger = false,
    this.active = false,
    this.activeColor,
    this.flat = false,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;
  final double size;
  final double iconSize;
  final bool danger;
  final bool active;
  final Color? activeColor;
  final bool flat;

  @override
  State<GlassIconButton> createState() => _GlassIconButtonState();
}

class _GlassIconButtonState extends State<GlassIconButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final Color hoverFill = widget.danger
        ? const Color(0xFFEF4444)
        : palette.surfaceTint;

    if (widget.flat) {
      final Widget flatBtn = MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hover = true),
        onExit: (_) => setState(() => _hover = false),
        child: AnimatedScale(
          scale: _hover ? 1.1 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: AnimatedOpacity(
            opacity: _hover ? 1 : 0.85,
            duration: const Duration(milliseconds: 150),
            child: SizedBox(
              width: widget.size,
              height: widget.size,
              child: Material(
                type: MaterialType.transparency,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: widget.onPressed,
                  child: Icon(
                    widget.icon,
                    size: widget.iconSize,
                    color: _hover
                        ? palette.accent
                        : widget.active
                        ? (widget.activeColor ?? palette.accent)
                        : Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      if (widget.tooltip != null) {
        return Tooltip(message: widget.tooltip!, child: flatBtn);
      }
      return flatBtn;
    }

    final Widget btn = MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          color: _hover ? hoverFill : palette.panel,
          shape: BoxShape.circle,
          border: Border.all(
            color: widget.active
                ? (widget.activeColor ?? AppPalette.accentStart).withValues(
                    alpha: 0.8,
                  )
                : palette.border,
            width: 1,
          ),
          boxShadow: _hover && widget.danger
              ? const [BoxShadow(color: Color(0x66EF4444), blurRadius: 14)]
              : null,
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: widget.onPressed,
            child: Icon(
              widget.icon,
              size: widget.iconSize,
              color: _hover && widget.danger
                  ? Colors.white
                  : widget.active
                  ? (widget.activeColor ?? AppPalette.accentStart)
                  : palette.textPrimary,
            ),
          ),
        ),
      ),
    );
    if (widget.tooltip != null) {
      return Tooltip(message: widget.tooltip!, child: btn);
    }
    return btn;
  }
}
