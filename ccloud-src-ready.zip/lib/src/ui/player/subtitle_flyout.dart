import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../services/settings_service.dart';
import '../widgets/glass_panel.dart';

/// Model for the flyout's track list entries (embedded or external).
class SubtitleTrackOption {
  const SubtitleTrackOption({
    required this.id,
    required this.label,
    this.external = false,
  });

  final String id;
  final String label;
  final bool external;
}

/// Floating frosted drawer anchored to the player's right edge:
/// master subtitle switch, track picker, local-file upload box,
/// ±0.5s sync calibration and S/M/L font sizing.
class SubtitleFlyout extends StatelessWidget {
  const SubtitleFlyout({
    super.key,
    required this.enabled,
    required this.onToggleEnabled,
    required this.trackOptions,
    required this.selectedTrackId,
    required this.onSelectTrack,
    required this.onUpload,
    required this.offset,
    required this.onOffsetStep,
    required this.onResetOffset,
    required this.size,
    required this.onSizeChange,
    required this.onClose,
    this.busy,
  });

  final bool enabled;
  final ValueChanged<bool> onToggleEnabled;
  final List<SubtitleTrackOption> trackOptions;
  final String selectedTrackId;
  final ValueChanged<String> onSelectTrack;
  final VoidCallback onUpload;
  final double offset;
  final void Function(double delta) onOffsetStep;
  final VoidCallback onResetOffset;
  final SubtitleSize size;
  final ValueChanged<SubtitleSize> onSizeChange;
  final VoidCallback onClose;
  final bool? busy;

  String _offsetLabel() {
    if (offset == 0) {
      return 'In sync';
    }
    final String sign = offset > 0 ? '+' : '';
    return '$sign${offset.toStringAsFixed(1)}s';
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return GlassPanel(
      radius: AppPalette.radiusCardSmall,
      color: palette.glassElevated,
      blur: 28,
      padding: EdgeInsets.zero,
      width: 320,
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.6),
          blurRadius: 40,
          offset: const Offset(0, 16),
        ),
      ],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header (.flyout-header)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 10, 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Subtitles & Audio',
                    style: TextStyle(
                      color: palette.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (busy == true)
                  const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                else
                  MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: GestureDetector(
                      onTap: onClose,
                      child: Icon(
                        Icons.close_rounded,
                        size: 16,
                        color: palette.textSecondary,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Divider(height: 1, color: palette.hairline),

          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Master toggle
                  _SectionLabel(palette: palette, text: 'MASTER'),
                  const SizedBox(height: 8),
                  _ToggleRow(
                    palette: palette,
                    label: 'Enable subtitles',
                    value: enabled,
                    onChanged: onToggleEnabled,
                  ),
                  const SizedBox(height: 16),

                  // Tracks
                  _SectionLabel(palette: palette, text: 'TRACKS'),
                  const SizedBox(height: 8),
                  if (!enabled)
                    Text(
                      'Subtitles are turned off. Enable the master switch first.',
                      style: TextStyle(
                        color: palette.textSecondary,
                        fontSize: 11.5,
                      ),
                    )
                  else if (trackOptions.isEmpty)
                    Text(
                      'No tracks detected for this stream yet. Upload one below.',
                      style: TextStyle(
                        color: palette.textSecondary,
                        fontSize: 11.5,
                      ),
                    )
                  else
                    ...trackOptions.map(
                      (SubtitleTrackOption o) => _TrackTile(
                        palette: palette,
                        label: o.label,
                        external: o.external,
                        selected: o.id == selectedTrackId,
                        onTap: () => onSelectTrack(o.id),
                      ),
                    ),
                  const SizedBox(height: 16),

                  // Upload box
                  _SectionLabel(palette: palette, text: 'LOCAL FILE'),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: onUpload,
                    child: MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: palette.inputBg,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: palette.borderHover,
                            width: 1.5,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              Icons.upload_file_rounded,
                              size: 18,
                              color: palette.accent,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              'Load .SRT, .VTT or .ASS File',
                              style: TextStyle(
                                color: palette.textPrimary,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              'Click or drag & drop subtitle file here',
                              style: TextStyle(
                                color: palette.textFaint,
                                fontSize: 9.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Sync calibration
                  _SectionLabel(palette: palette, text: 'SYNC CALIBRATION'),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: palette.panelSoft,
                      borderRadius: BorderRadius.circular(
                        AppPalette.radiusCardSmall,
                      ),
                      border: Border.all(color: palette.border),
                    ),
                    child: Row(
                      children: [
                        _CalibButton(
                          palette: palette,
                          icon: Icons.remove_rounded,
                          tooltip: '-0.5s',
                          onTap: enabled ? () => onOffsetStep(-0.5) : null,
                        ),
                        Expanded(
                          child: Column(
                            children: [
                              Text(
                                _offsetLabel(),
                                style: TextStyle(
                                  color: offset == 0
                                      ? palette.textSecondary
                                      : AppPalette.accentStart,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'subtitle delay',
                                style: TextStyle(
                                  color: palette.textSecondary,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _CalibButton(
                          palette: palette,
                          icon: Icons.add_rounded,
                          tooltip: '+0.5s',
                          onTap: enabled ? () => onOffsetStep(0.5) : null,
                        ),
                        const SizedBox(width: 6),
                        _CalibButton(
                          palette: palette,
                          icon: Icons.restart_alt_rounded,
                          tooltip: 'Reset',
                          onTap: offset != 0 ? onResetOffset : null,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Text size
                  _SectionLabel(palette: palette, text: 'TEXT SIZE'),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      for (final (SubtitleSize s, String label)
                          in const <(SubtitleSize, String)>[
                            (SubtitleSize.small, 'S'),
                            (SubtitleSize.medium, 'M'),
                            (SubtitleSize.large, 'L'),
                          ])
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(
                              right: s == SubtitleSize.large ? 0 : 8,
                            ),
                            child: _SizeButton(
                              palette: palette,
                              label: label,
                              selected: size == s,
                              onTap: () => onSizeChange(s),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.palette, required this.text});

  final AppPalette palette;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        color: palette.textSecondary.withValues(alpha: 0.8),
        fontSize: 9.5,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.4,
      ),
    );
  }
}

class _ToggleRow extends StatelessWidget {
  const _ToggleRow({
    required this.palette,
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final AppPalette palette;
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: palette.panelSoft,
        borderRadius: BorderRadius.circular(AppPalette.radiusCardSmall),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: palette.textPrimary,
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: () => onChanged(!value),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 40,
                height: 20,
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  gradient: value ? AppPalette.accentGradient : null,
                  color: value ? null : palette.inputBg,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: AnimatedAlign(
                  duration: const Duration(milliseconds: 180),
                  alignment: value
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    width: 14,
                    height: 14,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackTile extends StatelessWidget {
  const _TrackTile({
    required this.palette,
    required this.label,
    required this.external,
    required this.selected,
    required this.onTap,
  });

  final AppPalette palette;
  final String label;
  final bool external;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: selected
                  ? AppPalette.accentStart.withValues(alpha: 0.14)
                  : palette.panelSoft,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(
                color: selected
                    ? AppPalette.accentStart.withValues(alpha: 0.6)
                    : palette.border,
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  external ? Icons.description_rounded : Icons.language_rounded,
                  size: 14,
                  color: selected
                      ? AppPalette.accentStart
                      : palette.textSecondary,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: selected
                          ? palette.textPrimary
                          : palette.textSecondary,
                      fontSize: 12,
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ),
                if (selected)
                  const Icon(
                    Icons.check_circle_rounded,
                    size: 14,
                    color: AppPalette.accentStart,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CalibButton extends StatelessWidget {
  const _CalibButton({
    required this.palette,
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final AppPalette palette;
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final bool disabled = onTap == null;
    return Tooltip(
      message: tooltip,
      child: MouseRegion(
        cursor: disabled ? SystemMouseCursors.basic : SystemMouseCursors.click,
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: disabled ? Colors.transparent : palette.panelStrong,
              shape: BoxShape.circle,
              border: Border.all(
                color: disabled ? palette.hairline : palette.border,
              ),
            ),
            child: Icon(
              icon,
              size: 15,
              color: disabled
                  ? palette.textSecondary.withValues(alpha: 0.4)
                  : palette.textPrimary,
            ),
          ),
        ),
      ),
    );
  }
}

class _SizeButton extends StatelessWidget {
  const _SizeButton({
    required this.palette,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final AppPalette palette;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          height: 34,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: selected ? AppPalette.accentGradient : null,
            color: selected ? null : palette.panelSoft,
            borderRadius: BorderRadius.circular(AppPalette.radiusButton),
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.2)
                  : palette.border,
              width: 1,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: AppPalette.glow.withValues(alpha: 0.55),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : palette.textSecondary,
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}
