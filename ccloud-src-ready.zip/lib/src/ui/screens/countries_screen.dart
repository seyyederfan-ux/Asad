import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/country.dart';
import '../../models/poster.dart';
import '../../providers/countries_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/media_card.dart';
import '../widgets/section_header.dart';

/// Browse-by-country: flag grid fed by the preserved [CountriesProvider],
/// then a poster grid via [CountryMediaProvider].
class CountriesScreen extends StatefulWidget {
  const CountriesScreen({super.key});

  @override
  State<CountriesScreen> createState() => _CountriesScreenState();
}

class _CountriesScreenState extends State<CountriesScreen> {
  int? _selectedCountryId;
  String _selectedCountryName = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        final CountriesProvider p = context.read<CountriesProvider>();
        if (p.countries.isEmpty && !p.isLoading) {
          p.loadCountries();
        }
      }
    });
  }

  void _select(int id, String name) {
    setState(() {
      _selectedCountryId = id;
      _selectedCountryName = name;
    });
    context.read<CountryMediaProvider>().loadMediaByCountry(id);
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final CountriesProvider cp = context.watch<CountriesProvider>();
    final CountryMediaProvider mp = context.watch<CountryMediaProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(title: 'Browse by Country'),
          const SizedBox(height: 6),
          Text(
            _selectedCountryId == null
                ? 'Pick a production country to explore its catalog.'
                : 'Catalog of $_selectedCountryName',
            style: TextStyle(color: palette.textSecondary, fontSize: 12.5),
          ),
          const SizedBox(height: 16),

          // Flags grid
          if (cp.isLoading && cp.countries.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(strokeWidth: 2.4),
              ),
            )
          else if (cp.countries.isEmpty)
            EmptyState(
              icon: Icons.public_off_rounded,
              title: 'Countries unavailable',
              subtitle:
                  'The country list could not be loaded. Check your connection and retry.',
              ctaLabel: 'Retry',
              onCta: () => context.read<CountriesProvider>().loadCountries(),
            )
          else
            SizedBox(
              height: 96,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: cp.countries.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (BuildContext context, int index) {
                  final CountryModel c = cp.countries[index];
                  final bool selected = c.id == _selectedCountryId;
                  return _FlagCard(
                    id: c.id,
                    title: c.title,
                    image: c.image,
                    selected: selected,
                    palette: palette,
                    onTap: () => _select(c.id, c.title),
                  );
                },
              ),
            ),
          const SizedBox(height: 20),

          // Country media
          Expanded(
            child: _selectedCountryId == null
                ? const EmptyState(
                    icon: Icons.travel_explore_rounded,
                    title: 'Explore by country',
                    subtitle:
                        'Every flag above opens a curated poster wall for that country\'s productions.',
                  )
                : mp.isLoading
                ? const Center(
                    child: CircularProgressIndicator(strokeWidth: 2.4),
                  )
                : mp.mediaItems.isEmpty
                ? EmptyState(
                    icon: Icons.movie_filter_outlined,
                    title: 'No titles found',
                    subtitle:
                        'This country has no entries in the catalog at the moment.',
                  )
                : GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 196,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 14,
                          childAspectRatio: 0.53,
                        ),
                    itemCount: mp.mediaItems.length,
                    itemBuilder: (BuildContext context, int index) {
                      final Poster p = mp.mediaItems[index];
                      return LayoutBuilder(
                        builder: (BuildContext c, BoxConstraints bc) {
                          return MediaCard(
                            item: p.toMediaItem(),
                            width: bc.maxWidth,
                            onOpen: () =>
                                context.push('/detail', extra: p.toMediaItem()),
                            onPlay: () => context.push(
                              '/player',
                              extra: PlaybackRequest(media: p.toMediaItem()),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _FlagCard extends StatefulWidget {
  const _FlagCard({
    required this.id,
    required this.title,
    required this.image,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final int id;
  final String title;
  final String image;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  State<_FlagCard> createState() => _FlagCardState();
}

class _FlagCardState extends State<_FlagCard> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 132,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _hover || widget.selected
                ? palette.surfaceTint
                : palette.panel,
            borderRadius: BorderRadius.circular(AppPalette.radiusCardSmall),
            border: Border.all(
              color: widget.selected
                  ? AppPalette.accentStart.withValues(alpha: 0.7)
                  : palette.border,
              width: 1,
            ),
            boxShadow: widget.selected
                ? [
                    BoxShadow(
                      color: AppPalette.glow.withValues(alpha: 0.5),
                      blurRadius: 12,
                    ),
                  ]
                : null,
          ),
          child: Column(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(7),
                  child: Image.network(
                    widget.image,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: palette.panelStrong,
                      child: Icon(
                        Icons.flag_rounded,
                        size: 18,
                        color: palette.textSecondary,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 7),
              Text(
                widget.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: palette.textPrimary,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
