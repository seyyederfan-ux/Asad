import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../models/tv_channel.dart';
import '../../providers/tv_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/glass_panel.dart';
import '../widgets/section_header.dart';

/// Live TV browser: country rail + channel grid, streamed in-app through the
/// same glass player (or YouTube fallback in the external browser).
class LiveTvScreen extends StatefulWidget {
  const LiveTvScreen({super.key});

  @override
  State<LiveTvScreen> createState() => _LiveTvScreenState();
}

class _LiveTvScreenState extends State<LiveTvScreen> {
  String? _selectedCode;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<TvProvider>().loadCountriesMetadata();
      }
    });
  }

  void _selectCountry(String code) {
    setState(() => _selectedCode = code);
    context.read<TvProvider>().loadChannelsByCountry(code);
  }

  void _playChannel(BuildContext context, TvChannel ch) {
    final List<Source> sources = <Source>[
      for (final String u in ch.iptvUrls)
        Source(id: 0, quality: 'LIVE', type: 'IPTV', url: u),
    ];
    if (sources.isEmpty) {
      if (ch.youtubeUrls.isNotEmpty) {
        launchUrl(
          Uri.parse(ch.youtubeUrls.first),
          mode: LaunchMode.externalApplication,
        );
      }
      return;
    }
    final MediaItem shell = MediaItem(
      id: 0,
      type: 'movie',
      title: ch.name,
      description: 'Live TV channel — ${ch.language}',
      year: 0,
      imdb: 0,
      rating: 0,
      image: '',
      cover: '',
      genres: const <Genre>[],
      sources: sources,
      countries: const <Country>[],
    );
    context.push(
      '/player',
      extra: PlaybackRequest(media: shell, source: sources.first),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final TvProvider tv = context.watch<TvProvider>();

    final List<(String, String)> countries = <(String, String)>[];
    tv.countriesMetadata.forEach((String code, dynamic data) {
      if (data is Map<String, dynamic>) {
        final String name = data['country'] as String? ?? code.toUpperCase();
        countries.add((code, name));
      }
    });
    countries.sort((a, b) => a.$2.compareTo(b.$2));

    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(title: 'Live TV'),
          const SizedBox(height: 6),
          Text(
            'Free-to-air channels streamed straight into the glass player.',
            style: TextStyle(color: palette.textSecondary, fontSize: 12.5),
          ),
          const SizedBox(height: 16),

          // Country rail
          SizedBox(
            height: 44,
            child: tv.isLoadingCountries && countries.isEmpty
                ? const Center(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2.2),
                    ),
                  )
                : ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: countries.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (BuildContext context, int index) {
                      final (String code, String name) = countries[index];
                      final bool selected = code == _selectedCode;
                      return _CountryChip(
                        code: code,
                        name: name,
                        selected: selected,
                        palette: palette,
                        onTap: () => _selectCountry(code),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 16),

          // Channels
          Expanded(
            child: _selectedCode == null
                ? EmptyState(
                    icon: Icons.satellite_alt_rounded,
                    title: 'Pick a country',
                    subtitle:
                        'Choose a country above to browse its live channels.',
                  )
                : tv.isLoadingChannels
                ? const Center(
                    child: CircularProgressIndicator(strokeWidth: 2.4),
                  )
                : tv.channelsErrorMessage != null && tv.channels.isEmpty
                ? EmptyState(
                    icon: Icons.wifi_off_rounded,
                    title: 'Could not load channels',
                    subtitle:
                        'The channel list service did not respond. Try another country or retry.',
                    ctaLabel: 'Retry',
                    onCta: () => _selectCountry(_selectedCode!),
                  )
                : tv.channels.isEmpty
                ? const EmptyState(
                    icon: Icons.tv_off_rounded,
                    title: 'No channels',
                    subtitle:
                        'This country has no channels in the index right now.',
                  )
                : GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 250,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          childAspectRatio: 2.5,
                        ),
                    itemCount: tv.channels.length,
                    itemBuilder: (BuildContext context, int index) {
                      final TvChannel ch = tv.channels[index];
                      return _ChannelCard(
                        channel: ch,
                        palette: palette,
                        onTap: () => _playChannel(context, ch),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _CountryChip extends StatelessWidget {
  const _CountryChip({
    required this.code,
    required this.name,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final String code;
  final String name;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            gradient: selected ? AppPalette.accentGradient : null,
            color: selected ? null : palette.panel,
            borderRadius: BorderRadius.circular(AppPalette.radiusButton + 1),
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.16)
                  : palette.border,
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: Image.asset(
                  'assets/CountryFlags/$code.png',
                  width: 21,
                  height: 15,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Icon(
                    Icons.flag_rounded,
                    size: 14,
                    color: palette.textSecondary,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: selected ? Colors.white : palette.textPrimary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChannelCard extends StatefulWidget {
  const _ChannelCard({
    required this.channel,
    required this.palette,
    required this.onTap,
  });

  final TvChannel channel;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  State<_ChannelCard> createState() => _ChannelCardState();
}

class _ChannelCardState extends State<_ChannelCard> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: GlassSurface(
          radius: AppPalette.radiusCardSmall,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: _hover ? AppPalette.accentGradient : null,
                  color: _hover ? null : palette.panelStrong,
                  shape: BoxShape.circle,
                  border: Border.all(color: palette.border),
                ),
                child: Icon(
                  Icons.play_arrow_rounded,
                  size: 19,
                  color: _hover ? Colors.white : AppPalette.accentStart,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      widget.channel.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.channel.isGeoBlocked
                          ? 'Geo-blocked in your region'
                          : '${widget.channel.language}  •  LIVE',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: widget.channel.isGeoBlocked
                            ? AppPalette.warning
                            : palette.textSecondary,
                        fontSize: 10.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
