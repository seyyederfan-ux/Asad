import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/poster.dart';
import '../../providers/search_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/media_card.dart';
import '../widgets/section_header.dart';

/// Global search results — fed from the titlebar field via `/search?q=...`
/// and backed by the preserved [SearchProvider].
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.query});

  final String query;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run(widget.query));
  }

  @override
  void didUpdateWidget(covariant SearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.query != widget.query) {
      _run(widget.query);
    }
  }

  Future<void> _run(String q) async {
    if (q.trim().isEmpty) {
      return;
    }
    final SearchProvider sp = context.read<SearchProvider>();
    sp.updateSearchQuery(q);
    await sp.search(q);
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final SearchProvider sp = context.watch<SearchProvider>();
    final List<Poster> results = sp.searchResults;

    if (widget.query.trim().isEmpty) {
      return EmptyState(
        icon: Icons.search_off_rounded,
        title: 'Search CCloud',
        subtitle:
            'Use the search field in the title bar to look up any movie or series by its English title.',
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(
            title: sp.isLoading && results.isEmpty
                ? 'Searching “${widget.query}”…'
                : 'Results for “${widget.query}”',
          ),
          const SizedBox(height: 6),
          Text(
            sp.errorMessage != null
                ? 'The search service could not be reached. Please retry.'
                : '${results.length} title${results.length == 1 ? '' : 's'} found',
            style: TextStyle(color: palette.textSecondary, fontSize: 12.5),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: sp.isLoading && results.isEmpty
                ? const Center(
                    child: CircularProgressIndicator(strokeWidth: 2.4),
                  )
                : sp.errorMessage != null && results.isEmpty
                ? EmptyState(
                    icon: Icons.cloud_off_rounded,
                    title: 'Search failed',
                    subtitle:
                        'We could not reach the catalog service. Check the connection (or your proxy settings) and try again.',
                    ctaLabel: 'Retry',
                    onCta: () => _run(widget.query),
                  )
                : results.isEmpty
                ? EmptyState(
                    icon: Icons.sentiment_dissatisfied_rounded,
                    title: 'No matches',
                    subtitle:
                        'Nothing matched “${widget.query}”. Try the original English title of the content.',
                  )
                : GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 196,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 14,
                          childAspectRatio: 0.53,
                        ),
                    itemCount: results.length,
                    itemBuilder: (BuildContext context, int index) {
                      final Poster p = results[index];
                      return LayoutBuilder(
                        builder: (BuildContext c, BoxConstraints bc) {
                          return MediaCard(
                            item: p.toMediaItem(),
                            width: bc.maxWidth,
                            onOpen: () =>
                                context.push('/detail', extra: p.toMediaItem()),
                            onPlay: () => context.push(
                              '/player',
                              extra: PlaybackRequest(media: p.toMediaItem()),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
