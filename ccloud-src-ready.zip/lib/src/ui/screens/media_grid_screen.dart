import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../providers/genre_provider.dart';
import '../../providers/movie_provider.dart';
import '../../providers/series_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/filter_dock.dart';
import '../widgets/glass_dropdown.dart';
import '../widgets/glass_panel.dart';
import '../widgets/media_card.dart';
import '../widgets/section_header.dart';

enum MediaKind { movies, series }

/// Movies / Series catalog: genre pill dock, sort dropdown and a responsive
/// infinite-scroll poster grid. Backed by the preserved Movie/Series
/// providers (pagination + Farsi-title filter intact).
class MediaGridScreen extends StatefulWidget {
  const MediaGridScreen({super.key, required this.kind});

  final MediaKind kind;

  @override
  State<MediaGridScreen> createState() => _MediaGridScreenState();
}

class _MediaGridScreenState extends State<MediaGridScreen> {
  final ScrollController _scroll = ScrollController();

  bool get _isMovies => widget.kind == MediaKind.movies;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      final GenreProvider genres = context.read<GenreProvider>();
      if (genres.genres.isEmpty && !genres.isLoading) {
        genres.loadGenres();
      }
      if (_isMovies) {
        final MovieProvider p = context.read<MovieProvider>();
        if (p.movies.isEmpty && !p.isLoading) {
          p.loadMovies();
        }
      } else {
        final SeriesProvider p = context.read<SeriesProvider>();
        if (p.series.isEmpty && !p.isLoading) {
          p.loadSeries();
        }
      }
    });
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.extentAfter < 480) {
      if (_isMovies) {
        final MovieProvider p = context.read<MovieProvider>();
        if (!p.isLoading && p.hasMore && p.errorMessage.isEmpty) {
          p.loadMovies();
        }
      } else {
        final SeriesProvider p = context.read<SeriesProvider>();
        if (!p.isLoading && p.hasMore && p.errorMessage.isEmpty) {
          p.loadSeries();
        }
      }
    }
  }

  void _openDetail(BuildContext context, MediaItem item) {
    context.push('/detail', extra: item);
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final GenreProvider genreState = context.watch<GenreProvider>();

    final List<MediaItem> items;
    final bool loading;
    final String error;
    if (_isMovies) {
      final MovieProvider p = context.watch<MovieProvider>();
      items = p.movies;
      loading = p.isLoading;
      error = p.errorMessage;
    } else {
      final SeriesProvider p = context.watch<SeriesProvider>();
      items = p.series;
      loading = p.isLoading;
      error = p.errorMessage;
    }

    final List<Genre> genrePills = <Genre>[
      Genre(id: 0, title: 'All Genres'),
      ...genreState.genres,
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(title: _isMovies ? 'Movies' : 'Series'),
          const SizedBox(height: 16),

          // Filter dock
          FilterDock(
            genres: genrePills,
            selectedGenreId: _isMovies
                ? context.watch<MovieProvider>().selectedGenreId
                : context.watch<SeriesProvider>().selectedGenreId,
            selectedFilter: _isMovies
                ? context.watch<MovieProvider>().selectedFilter
                : context.watch<SeriesProvider>().selectedFilter,
            sortItems: const <DropdownItem<FilterType>>[
              DropdownItem<FilterType>(
                value: FilterType.defaultFilter,
                label: 'Newest',
                icon: Icons.fiber_new_rounded,
              ),
              DropdownItem<FilterType>(
                value: FilterType.byYear,
                label: 'By Year',
                icon: Icons.calendar_month_rounded,
              ),
              DropdownItem<FilterType>(
                value: FilterType.byImdb,
                label: 'By IMDb',
                icon: Icons.star_rounded,
              ),
            ],
            onGenreSelected: (int id) {
              if (_isMovies) {
                context.read<MovieProvider>().selectGenre(id);
              } else {
                context.read<SeriesProvider>().selectGenre(id);
              }
            },
            onFilterSelected: (FilterType f) {
              if (_isMovies) {
                context.read<MovieProvider>().selectFilter(f);
              } else {
                context.read<SeriesProvider>().selectFilter(f);
              }
            },
          ),
          const SizedBox(height: 18),

          // Error banner
          if (error.isNotEmpty)
            GlassSurface(
              radius: AppPalette.radiusButton + 1,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  const Icon(
                    Icons.wifi_off_rounded,
                    size: 16,
                    color: AppPalette.warning,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      'Network error while loading the catalog. Check your connection and retry.',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textSecondary,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      if (_isMovies) {
                        context.read<MovieProvider>().refreshMovies();
                      } else {
                        context.read<SeriesProvider>().refreshSeries();
                      }
                    },
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          if (error.isNotEmpty) const SizedBox(height: 14),

          // Grid
          Expanded(
            child: items.isEmpty && loading
                ? _SkeletonGrid()
                : items.isEmpty
                ? EmptyState(
                    icon: Icons.explore_off_rounded,
                    title: 'Nothing here yet',
                    subtitle: error.isNotEmpty
                        ? 'The catalog could not be loaded. Try again in a moment.'
                        : 'No titles match this filter combination yet — try another genre.',
                    ctaLabel: error.isNotEmpty ? 'Reload' : null,
                    onCta: error.isNotEmpty
                        ? () {
                            if (_isMovies) {
                              context.read<MovieProvider>().refreshMovies();
                            } else {
                              context.read<SeriesProvider>().refreshSeries();
                            }
                          }
                        : null,
                  )
                : GridView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.only(bottom: 8),
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 196,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 14,
                          childAspectRatio: 0.53,
                        ),
                    itemCount: items.length + (loading ? 4 : 0),
                    itemBuilder: (BuildContext context, int index) {
                      if (index >= items.length) {
                        return _SkeletonCard(palette: palette);
                      }
                      final MediaItem m = items[index];
                      return LayoutBuilder(
                        builder: (BuildContext c, BoxConstraints bc) {
                          return MediaCard(
                            item: m,
                            width: bc.maxWidth,
                            onOpen: () => _openDetail(context, m),
                            onPlay: () => context.push(
                              '/player',
                              extra: PlaybackRequest(media: m),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _SkeletonGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 196,
        mainAxisSpacing: 16,
        crossAxisSpacing: 14,
        childAspectRatio: 0.53,
      ),
      itemCount: 16,
      itemBuilder: (_, __) => _SkeletonCard(palette: palette),
    );
  }
}

class _SkeletonCard extends StatefulWidget {
  const _SkeletonCard({required this.palette});

  final AppPalette palette;

  @override
  State<_SkeletonCard> createState() => _SkeletonCardState();
}

class _SkeletonCardState extends State<_SkeletonCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (BuildContext context, _) {
        final double t = 0.5 + 0.5 * _c.value;
        return Container(
          decoration: BoxDecoration(
            color: widget.palette.panelSoft,
            borderRadius: BorderRadius.circular(AppPalette.radiusCard),
            border: Border.all(color: widget.palette.border),
          ),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: widget.palette.textSecondary.withValues(
                      alpha: 0.06 + 0.05 * t,
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(AppPalette.radiusCard - 1),
                      topRight: Radius.circular(AppPalette.radiusCard - 1),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Container(
                      height: 9,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: widget.palette.textSecondary.withValues(
                          alpha: 0.10 + 0.05 * t,
                        ),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      height: 7,
                      width: 70,
                      decoration: BoxDecoration(
                        color: widget.palette.textSecondary.withValues(
                          alpha: 0.08 + 0.05 * t,
                        ),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
