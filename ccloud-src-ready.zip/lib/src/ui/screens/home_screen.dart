import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../models/media_item.dart';
import '../../providers/movie_provider.dart';
import '../../providers/series_provider.dart';
import '../../services/continue_watching_service.dart';
import '../../services/download_manager.dart';
import '../widgets/continue_card.dart';
import '../widgets/download_mirrors_modal.dart';
import '../widgets/hero_stage.dart';
import '../widgets/media_card.dart';
import '../widgets/section_header.dart';

/// Home view: hero stage, continue-watching shelf and trending shelves.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      final MovieProvider movies = context.read<MovieProvider>();
      final SeriesProvider series = context.read<SeriesProvider>();
      if (movies.movies.isEmpty && !movies.isLoading) {
        movies.loadMovies();
      }
      if (series.series.isEmpty && !series.isLoading) {
        series.loadSeries();
      }
      context.read<ContinueWatchingService>().load();
      context.read<DownloadManager>().restore();
    });
  }

  List<MediaItem> _heroItems(List<MediaItem> all) {
    final List<MediaItem> withCover = all
        .where((MediaItem m) => m.cover.isNotEmpty || m.image.isNotEmpty)
        .toList();
    return withCover.take(5).toList();
  }

  void _openDetail(BuildContext context, MediaItem item) {
    context.push('/detail', extra: item);
  }

  void _play(BuildContext context, MediaItem item, {Source? source}) {
    context.push(
      '/player',
      extra: PlaybackRequest(media: item, source: source),
    );
  }

  void _openLinks(BuildContext context, MediaItem item) {
    DownloadMirrorsModal.show(
      context,
      title: item.title,
      sources: item.sources,
      onCopy: (String url) {},
    );
  }

  @override
  Widget build(BuildContext context) {
    final MovieProvider movieState = context.watch<MovieProvider>();
    final SeriesProvider seriesState = context.watch<SeriesProvider>();
    final ContinueWatchingService watchState = context
        .watch<ContinueWatchingService>();

    final List<MediaItem> trending = movieState.movies;
    final List<MediaItem> freshSeries = seriesState.series;
    final List<WatchProgress> resume = watchState.entries
        .where((WatchProgress e) => !e.isFinished)
        .toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HeroStage(
            items: _heroItems(trending),
            onPlay: (MediaItem m) => _play(context, m),
            onOpenLinks: (MediaItem m) => _openLinks(context, m),
            onOpen: (MediaItem m) => _openDetail(context, m),
          ),
          if (resume.isNotEmpty) ...[
            const SizedBox(height: 30),
            SectionHeader(
              title: 'Continue Watching',
              trailing: resume.length > 6 ? 'Clear History' : null,
              onTrailingTap: () => watchState.clear(),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: resume.length,
                separatorBuilder: (_, __) => const SizedBox(width: 18),
                itemBuilder: (BuildContext context, int index) {
                  final WatchProgress p = resume[index];
                  return ContinueCard(
                    progress: p,
                    onPlay: () {
                      // Reconstruct a light media shell so the player can resume.
                      final MediaItem item = MediaItem(
                        id: p.mediaId,
                        type: p.mediaType,
                        title: p.title,
                        description: '',
                        year: 0,
                        imdb: 0,
                        rating: 0,
                        image: p.image,
                        cover: p.cover,
                        genres: const <Genre>[],
                        sources: const <Source>[],
                        countries: const <Country>[],
                      );
                      _play(context, item);
                    },
                    onRemove: () => watchState.remove(p.key),
                  );
                },
              ),
            ),
          ],
          if (trending.isNotEmpty) ...[
            const SizedBox(height: 30),
            SectionHeader(
              title: 'Trending Worldwide',
              trailing: 'Explore All Movies',
              onTrailingTap: () => context.go('/movies'),
            ),
            const SizedBox(height: 16),
            _MediaShelf(
              items: trending,
              onOpen: (MediaItem m) => _openDetail(context, m),
              onPlay: (MediaItem m) => _play(context, m),
              onLinks: (MediaItem m) => _openLinks(context, m),
            ),
          ],
          if (freshSeries.isNotEmpty) ...[
            const SizedBox(height: 30),
            SectionHeader(
              title: 'Fresh Series',
              trailing: 'Explore All Series',
              onTrailingTap: () => context.go('/series'),
            ),
            const SizedBox(height: 16),
            _MediaShelf(
              items: freshSeries,
              onOpen: (MediaItem m) => _openDetail(context, m),
              onPlay: (MediaItem m) => _play(context, m),
              onLinks: (MediaItem m) => _openLinks(context, m),
            ),
          ],
        ],
      ),
    );
  }
}

class _MediaShelf extends StatelessWidget {
  const _MediaShelf({
    required this.items,
    required this.onOpen,
    required this.onPlay,
    required this.onLinks,
  });

  final List<MediaItem> items;
  final void Function(MediaItem) onOpen;
  final void Function(MediaItem) onPlay;
  final void Function(MediaItem) onLinks;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 332,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(bottom: 2),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 18),
        itemBuilder: (BuildContext context, int index) {
          final MediaItem m = items[index];
          return MediaCard(
            item: m,
            onOpen: () => onOpen(m),
            onPlay: () => onPlay(m),
            onLinks: () => onLinks(m),
          );
        },
      ),
    );
  }
}
