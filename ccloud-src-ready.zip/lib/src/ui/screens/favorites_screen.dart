import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../services/favorites_service.dart';
import '../../utils/storage_utils.dart';
import '../widgets/empty_state.dart';
import '../widgets/media_card.dart';
import '../widgets/section_header.dart';

enum _FavTab { all, movies, series }

/// Favorites / watchlist: filter chips (All / Movies / Series), poster grid
/// with quick remove, and the standard empty state.
class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  _FavTab _tab = _FavTab.all;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<FavoritesService>().load();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final FavoritesService favorites = context.watch<FavoritesService>();
    final List<MediaItem> items = favorites
        .filtered(
          _tab == _FavTab.all
              ? FavoritesFilter.all
              : (_tab == _FavTab.movies
                    ? FavoritesFilter.movies
                    : FavoritesFilter.series),
        )
        .map((MediaItemWithTimestamp e) => e.mediaItem)
        .toList();

    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(title: 'Favorites'),
          const SizedBox(height: 16),
          Row(
            children: [
              _FavChip(
                label: 'All',
                count: favorites.count,
                selected: _tab == _FavTab.all,
                palette: palette,
                onTap: () => setState(() => _tab = _FavTab.all),
              ),
              const SizedBox(width: 8),
              _FavChip(
                label: 'Movies',
                count: favorites.filtered(FavoritesFilter.movies).length,
                selected: _tab == _FavTab.movies,
                palette: palette,
                onTap: () => setState(() => _tab = _FavTab.movies),
              ),
              const SizedBox(width: 8),
              _FavChip(
                label: 'Series',
                count: favorites.filtered(FavoritesFilter.series).length,
                selected: _tab == _FavTab.series,
                palette: palette,
                onTap: () => setState(() => _tab = _FavTab.series),
              ),
              const Spacer(),
              if (favorites.count > 0)
                MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: () async {
                      await favorites.clearAll();
                    },
                    child: Row(
                      children: [
                        const Icon(
                          Icons.delete_sweep_rounded,
                          size: 15,
                          color: AppPalette.bookmark,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Clear watchlist',
                          style: TextStyle(
                            color: palette.textSecondary,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Expanded(
            child: items.isEmpty
                ? EmptyState(
                    icon: Icons.bookmark_border_rounded,
                    title: 'Your watchlist is empty',
                    subtitle:
                        'Tap the bookmark button on any poster to keep it here for a fast Friday-night pick.',
                    ctaLabel: 'Browse Catalog',
                    onCta: () => context.go('/movies'),
                  )
                : GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 196,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 14,
                          childAspectRatio: 0.53,
                        ),
                    itemCount: items.length,
                    itemBuilder: (BuildContext context, int index) {
                      final MediaItem m = items[index];
                      return LayoutBuilder(
                        builder: (BuildContext c, BoxConstraints bc) {
                          return MediaCard(
                            item: m,
                            width: bc.maxWidth,
                            onOpen: () => context.push('/detail', extra: m),
                            onPlay: () => context.push(
                              '/player',
                              extra: PlaybackRequest(media: m),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _FavChip extends StatelessWidget {
  const _FavChip({
    required this.label,
    required this.count,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final String label;
  final int count;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
          decoration: BoxDecoration(
            gradient: selected ? AppPalette.accentGradient : null,
            color: selected ? null : palette.panel,
            borderRadius: BorderRadius.circular(AppPalette.radiusPill),
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.18)
                  : palette.border,
              width: 1,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: AppPalette.glow.withValues(alpha: 0.6),
                      blurRadius: 12,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: selected ? Colors.white : palette.textPrimary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 7),
              Text(
                '$count',
                style: TextStyle(
                  color: selected
                      ? Colors.white.withValues(alpha: 0.85)
                      : palette.textSecondary,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
