import 'dart:io' as io;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/theme_manager.dart';
import '../../services/download_manager.dart';
import '../../services/download_task.dart';
import '../../services/settings_service.dart';
import '../../services/toast_service.dart';
import '../widgets/glass_button.dart';
import '../widgets/glass_dropdown.dart';
import '../widgets/glass_panel.dart';

/// Settings view with the five Fluent-style glass tabs:
/// General & Theme · Playback & Subtitles · Download Manager ·
/// Network & Proxy · About.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, this.initialTab = 'general'});

  final String initialTab;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late int _tab = switch (widget.initialTab) {
    'playback' => 1,
    'downloads' => 2,
    'network' => 3,
    'about' => 4,
    _ => 0,
  };

  static const List<String> _tabLabels = <String>[
    'General & Theme',
    'Playback & Subtitles',
    'Download Manager',
    'Network & Proxy',
    'About',
  ];

  static const List<String> _tabTitles = <String>[
    'General Appearance & Engine',
    'Playback & Subtitles',
    'Download Manager',
    'Network & Tunneling Mode',
    'About & Updates',
  ];

  static const List<String> _tabDescriptions = <String>[
    'Configure theme, accent and the playback engine defaults',
    'Subtitle behavior, sync calibration and font sizing',
    'Parallel segmented downloading, queue and storage',
    'Direct connection, system tunnel or local SOCKS5 proxy',
    'Version info, project links and update channel',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      final SettingsService s = context.read<SettingsService>();
      if (!s.loaded) {
        s.load();
      }
      final DownloadManager dm = context.read<DownloadManager>();
      dm.configure(maxConcurrent: s.maxConnections);
      dm.restore();
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // .section-titlebar — Application Preferences
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Application Preferences',
                style: TextStyle(
                  color: palette.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.3,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Configure theme, storage directories, hardware acceleration '
                'and proxy tunneling',
                style: TextStyle(color: palette.textFaint, fontSize: 11.5),
              ),
            ],
          ),
          const SizedBox(height: 18),

          // .settings-layout — 210px nav pane + content pane
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // .settings-nav-pane
                GlassSurface(
                  radius: AppPalette.radiusCardSmall,
                  color: palette.card,
                  child: SizedBox(
                    width: 210,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        for (int i = 0; i < _tabLabels.length; i++)
                          _SettingsNavBtn(
                            label: _tabLabels[i],
                            selected: _tab == i,
                            palette: palette,
                            onTap: () => setState(() => _tab = i),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 24),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // .settings-header-row
                      Container(
                        padding: const EdgeInsets.only(bottom: 14),
                        margin: const EdgeInsets.only(bottom: 18),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(color: palette.border),
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _tabTitles[_tab],
                                    style: TextStyle(
                                      color: palette.textPrimary,
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    _tabDescriptions[_tab],
                                    style: TextStyle(
                                      color: palette.textFaint,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            PrimaryGradientButton(
                              label: 'Save Preferences',
                              icon: Icons.check_rounded,
                              onPressed: () => context
                                  .read<ToastService>()
                                  .success('Preferences saved successfully'),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 180),
                          child: KeyedSubtree(
                            key: ValueKey<int>(_tab),
                            child: switch (_tab) {
                              0 => const _GeneralTab(),
                              1 => const _PlaybackTab(),
                              2 => const _DownloadsTab(),
                              3 => const _NetworkTab(),
                              _ => const _AboutTab(),
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ widgets

/// `.settings-nav-btn` — 9/12 padding, r7, active = accent gradient.
class _SettingsNavBtn extends StatefulWidget {
  const _SettingsNavBtn({
    required this.label,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  State<_SettingsNavBtn> createState() => _SettingsNavBtnState();
}

class _SettingsNavBtnState extends State<_SettingsNavBtn> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.5),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hover = true),
        onExit: (_) => setState(() => _hover = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            height: 36,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            alignment: Alignment.centerLeft,
            decoration: BoxDecoration(
              gradient: widget.selected ? AppPalette.accentGradient : null,
              color: widget.selected
                  ? null
                  : _hover
                  ? palette.cardHover
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(7),
            ),
            child: Text(
              widget.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: widget.selected
                    ? Colors.white
                    : _hover
                    ? palette.textPrimary
                    : palette.textSecondary,
                fontSize: 12.5,
                fontWeight: widget.selected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.children, this.subtitle});

  final String title;
  final String? subtitle;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return GlassPanel(
      radius: AppPalette.radiusCard,
      blur: 20,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: palette.textPrimary,
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(
              subtitle!,
              style: TextStyle(
                color: palette.textSecondary,
                fontSize: 11.5,
                height: 1.45,
              ),
            ),
          ],
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({
    required this.label,
    required this.child,
    this.description,
  });

  final String label;
  final String? description;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    // .setting-row — 13px vertical padding + hairline below
    return Container(
      margin: const EdgeInsets.only(bottom: 2),
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: palette.border)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: palette.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (description != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    description!,
                    style: TextStyle(
                      color: palette.textFaint,
                      fontSize: 11,
                      height: 1.4,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 16),
          child,
        ],
      ),
    );
  }
}

class _GlassToggle extends StatelessWidget {
  const _GlassToggle({required this.value, required this.onChanged});

  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: () => onChanged(!value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          // .switch-toggle — 40×20, 14px thumb
          width: 40,
          height: 20,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            gradient: value ? AppPalette.accentGradient : null,
            color: value
                ? null
                : AppPalette(
                    dark: Theme.of(context).brightness == Brightness.dark,
                  ).inputBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: value
                  ? Colors.transparent
                  : AppPalette(
                      dark: Theme.of(context).brightness == Brightness.dark,
                    ).borderStrong,
            ),
          ),
          child: AnimatedAlign(
            duration: const Duration(milliseconds: 180),
            alignment: value ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              width: 14,
              height: 14,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Segmented<T> extends StatelessWidget {
  const _Segmented({
    required this.options,
    required this.value,
    required this.onChanged,
  });

  final List<(T, String)> options;
  final T value;
  final ValueChanged<T>? onChanged;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: palette.panelSoft,
        borderRadius: BorderRadius.circular(AppPalette.radiusButton + 2),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final (T v, String label) in options)
            MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                onTap: onChanged == null ? null : () => onChanged!(v),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    gradient: value == v ? AppPalette.accentGradient : null,
                    borderRadius: BorderRadius.circular(
                      AppPalette.radiusButton - 1,
                    ),
                  ),
                  child: Text(
                    label,
                    style: TextStyle(
                      color: value == v ? Colors.white : palette.textSecondary,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// -------------------------------------------------------------------- tabs

class _GeneralTab extends StatelessWidget {
  const _GeneralTab();

  @override
  Widget build(BuildContext context) {
    final ThemeManager theme = context.watch<ThemeManager>();
    return SingleChildScrollView(
      child: Column(
        children: [
          _Group(
            title: 'Appearance',
            subtitle:
                'Switch between the Dark Acrylic and Light Frosted faces of the app.',
            children: [
              _SettingRow(
                label: 'Theme mode',
                description:
                    'System follows your Windows personalization setting.',
                child: _Segmented<AppThemeMode>(
                  options: const <(AppThemeMode, String)>[
                    (AppThemeMode.system, 'System'),
                    (AppThemeMode.light, 'Light'),
                    (AppThemeMode.dark, 'Dark'),
                  ],
                  value: theme.mode,
                  onChanged: (AppThemeMode m) => theme.setMode(m),
                ),
              ),
              _SettingRow(
                label: 'Accent',
                description:
                    'Neon violet gradient — applied across buttons, badges and glows.',
                child: Container(
                  width: 74,
                  height: 26,
                  decoration: BoxDecoration(
                    gradient: AppPalette.accentGradient,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(color: AppPalette.glow, blurRadius: 12),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Group(
            title: 'Application',
            children: [
              const _SettingRow(
                label: 'Interface language',
                description:
                    'English UI with automatic Persian fallback rendering for titles.',
                child: _Segmented<String>(
                  options: <(String, String)>[('en', 'English')],
                  value: 'en',
                  onChanged: null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PlaybackTab extends StatelessWidget {
  const _PlaybackTab();

  @override
  Widget build(BuildContext context) {
    final SettingsService s = context.watch<SettingsService>();
    return SingleChildScrollView(
      child: Column(
        children: [
          _Group(
            title: 'Playback',
            children: [
              _SettingRow(
                label: 'GPU hardware acceleration',
                description:
                    'Passes `hwdec=auto-safe` to libmpv (media_kit) for smooth 4K playback.',
                child: _GlassToggle(
                  value: s.gpuHardwareAcceleration,
                  onChanged: (bool v) => s.setGpuHardwareAcceleration(v),
                ),
              ),
              _SettingRow(
                label: 'Preferred quality',
                description:
                    'Auto picks the best match from the available mirrors.',
                child: GlassDropdown<String>(
                  items: const <DropdownItem<String>>[
                    DropdownItem<String>(
                      value: 'auto',
                      label: 'Auto',
                      icon: Icons.auto_awesome_rounded,
                    ),
                    DropdownItem<String>(
                      value: '2160',
                      label: '4K / 2160p',
                      icon: Icons.high_quality_rounded,
                    ),
                    DropdownItem<String>(
                      value: '1080',
                      label: 'Full HD / 1080p',
                      icon: Icons.hd_rounded,
                    ),
                    DropdownItem<String>(
                      value: '720',
                      label: 'HD / 720p',
                      icon: Icons.sd_storage_rounded,
                    ),
                  ],
                  value: s.preferredQuality,
                  onChanged: (String v) => s.setPreferredQuality(v),
                  labelBuilder: (DropdownItem<String> i) => i.label,
                  leadingIcon: Icons.high_quality_rounded,
                  width: 168,
                ),
              ),
              _SettingRow(
                label: 'Default player',
                description:
                    'Hybrid mode: play in-app, or hand the stream to VLC when preferred.',
                child: _Segmented<PreferredPlayer>(
                  options: const <(PreferredPlayer, String)>[
                    (PreferredPlayer.internal, 'In-App'),
                    (PreferredPlayer.vlc, 'VLC'),
                  ],
                  value: s.defaultPlayer,
                  onChanged: (PreferredPlayer v) => s.setDefaultPlayer(v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Group(
            title: 'Subtitles',
            children: [
              _SettingRow(
                label: 'Subtitles enabled by default',
                description:
                    'Master switch — can also be toggled live inside the player flyout.',
                child: _GlassToggle(
                  value: s.subtitlesEnabled,
                  onChanged: (bool v) => s.setSubtitlesEnabled(v),
                ),
              ),
              _SettingRow(
                label: 'Default text size',
                child: _Segmented<SubtitleSize>(
                  options: const <(SubtitleSize, String)>[
                    (SubtitleSize.small, 'S'),
                    (SubtitleSize.medium, 'M'),
                    (SubtitleSize.large, 'L'),
                  ],
                  value: s.subtitleSize,
                  onChanged: (SubtitleSize v) => s.setSubtitleSize(v),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DownloadsTab extends StatelessWidget {
  const _DownloadsTab();

  @override
  Widget build(BuildContext context) {
    final SettingsService s = context.watch<SettingsService>();
    final DownloadManager dm = context.watch<DownloadManager>();
    final ToastService toasts = context.read<ToastService>();
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );

    return SingleChildScrollView(
      child: Column(
        children: [
          _Group(
            title: 'Storage',
            children: [
              _SettingRow(
                label: 'Download directory',
                description:
                    s.downloadDir ?? 'Default: Documents\\CCloud Downloads',
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: () async {
                          final String? dir = await FilePicker.platform
                              .getDirectoryPath(
                                dialogTitle: 'Choose download folder',
                              );
                          if (dir != null) {
                            await s.setDownloadDir(dir);
                            DownloadManager.instance.configure(
                              downloadDir: dir,
                            );
                            toasts.success('Download folder updated');
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: AppPalette(
                              dark:
                                  Theme.of(context).brightness ==
                                  Brightness.dark,
                            ).panelStrong,
                            borderRadius: BorderRadius.circular(
                              AppPalette.radiusButton,
                            ),
                            border: Border.all(
                              color: AppPalette(
                                dark:
                                    Theme.of(context).brightness ==
                                    Brightness.dark,
                              ).border,
                            ),
                          ),
                          child: Text(
                            'Browse…',
                            style: TextStyle(
                              color: AppPalette(
                                dark:
                                    Theme.of(context).brightness ==
                                    Brightness.dark,
                              ).textPrimary,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              _SettingRow(
                label: 'Parallel connections per file',
                description:
                    'Byte-range chunks — higher values use more bandwidth.',
                child: SizedBox(
                  width: 190,
                  child: Row(
                    children: [
                      Expanded(
                        child: SliderTheme(
                          data: SliderTheme.of(
                            context,
                          ).copyWith(trackHeight: 3),
                          child: Slider(
                            value: s.maxConnections.toDouble(),
                            min: 1,
                            max: 8,
                            divisions: 7,
                            onChanged: (double v) {
                              s.setMaxConnections(v.round());
                              DownloadManager.instance.configure(
                                maxConcurrent: v.round(),
                              );
                            },
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 22,
                        child: Text(
                          '${s.maxConnections}',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppPalette.accentStart,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _SettingRow(
                label: 'Auto-start queued downloads',
                child: _GlassToggle(
                  value: s.autoStartDownloads,
                  onChanged: (bool v) => s.setAutoStartDownloads(v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Group(
            title: 'Queue',
            subtitle: 'Live view of the in-app download queue.',
            children: [
              if (dm.tasks.isEmpty)
                Text(
                  'No downloads yet. Use the In-App DL button on any mirror to fill the queue.',
                  style: TextStyle(color: palette.textSecondary, fontSize: 12),
                )
              else ...[
                for (final DownloadTask t in dm.tasks) _TaskRow(task: t),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: GestureDetector(
                      onTap: () => dm.clearCompleted(),
                      child: Text(
                        'Clear completed',
                        style: TextStyle(
                          color: AppPalette.accentStart,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _TaskRow extends StatelessWidget {
  const _TaskRow({required this.task});

  final DownloadTask task;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final DownloadManager dm = context.read<DownloadManager>();
    final ToastService toasts = context.read<ToastService>();

    final IconData icon;
    switch (task.status) {
      case DownloadStatus.downloading:
        icon = Icons.downloading_rounded;
      case DownloadStatus.queued:
        icon = Icons.schedule_rounded;
      case DownloadStatus.paused:
        icon = Icons.pause_circle_outline_rounded;
      case DownloadStatus.completed:
        icon = Icons.check_circle_rounded;
      case DownloadStatus.failed:
        icon = Icons.error_rounded;
    }
    final Color statusColor = switch (task.status) {
      DownloadStatus.downloading => AppPalette.accentStart,
      DownloadStatus.queued => palette.textSecondary,
      DownloadStatus.paused => AppPalette.warning,
      DownloadStatus.completed => AppPalette.success,
      DownloadStatus.failed => AppPalette.danger,
    };

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: palette.panelSoft,
          borderRadius: BorderRadius.circular(AppPalette.radiusCardSmall),
          border: Border.all(color: palette.border),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Icon(icon, size: 17, color: statusColor),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task.filename,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textPrimary,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${task.quality}  •  '
                        '${task.totalBytes > 0 ? '${formatBytes(task.receivedBytes)} / ${formatBytes(task.totalBytes)}' : formatBytes(task.receivedBytes)}'
                        '${task.status == DownloadStatus.downloading ? '  •  ${task.speedLabel}' : ''}'
                        '${task.error != null ? '  •  ${task.error}' : ''}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                if (task.status == DownloadStatus.downloading)
                  _IconBtn(
                    icon: Icons.pause_rounded,
                    palette: palette,
                    onTap: () => dm.pause(task.id),
                  )
                else if (task.status != DownloadStatus.completed)
                  _IconBtn(
                    icon: Icons.play_arrow_rounded,
                    palette: palette,
                    onTap: () => dm.resume(task.id),
                  ),
                const SizedBox(width: 6),
                _IconBtn(
                  icon: Icons.close_rounded,
                  palette: palette,
                  danger: true,
                  onTap: () async {
                    await dm.cancel(task.id);
                    toasts.info('Download removed');
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: Stack(
                children: [
                  Container(height: 4, color: palette.border),
                  FractionallySizedBox(
                    widthFactor: task.progress.clamp(0.0, 1.0),
                    child: Container(
                      height: 4,
                      decoration: BoxDecoration(
                        gradient: AppPalette.accentGradient,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  const _IconBtn({
    required this.icon,
    required this.palette,
    required this.onTap,
    this.danger = false,
  });

  final IconData icon;
  final AppPalette palette;
  final VoidCallback onTap;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: palette.panelStrong,
            shape: BoxShape.circle,
            border: Border.all(color: palette.border),
          ),
          child: Icon(
            icon,
            size: 14,
            color: danger ? AppPalette.danger : palette.textPrimary,
          ),
        ),
      ),
    );
  }
}

class _NetworkTab extends StatelessWidget {
  const _NetworkTab();

  @override
  Widget build(BuildContext context) {
    final SettingsService s = context.watch<SettingsService>();
    final ToastService toasts = context.read<ToastService>();
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );

    return SingleChildScrollView(
      child: Column(
        children: [
          _Group(
            title: 'Connection',
            subtitle:
                'Direct uses the plain HTTP client. System proxy is resolved per-request; '
                'SOCKS5 profiles are persisted here and applied to the download engine.',
            children: [
              _SettingRow(
                label: 'Proxy mode',
                child: _Segmented<ProxyMode>(
                  options: const <(ProxyMode, String)>[
                    (ProxyMode.direct, 'Direct'),
                    (ProxyMode.system, 'System'),
                    (ProxyMode.socks5, 'SOCKS5'),
                  ],
                  value: s.proxyMode,
                  onChanged: (ProxyMode v) => s.setProxyMode(v),
                ),
              ),
              if (s.proxyMode == ProxyMode.socks5) ...[
                _SettingRow(
                  label: 'SOCKS5 host',
                  description:
                      'Local V2Ray / Xray inbound, e.g. 127.0.0.1 with port 10808.',
                  child: _GlassTextField(
                    width: 180,
                    value: s.socksHost,
                    onSubmit: (String v) => s.setSocksHost(v),
                  ),
                ),
                _SettingRow(
                  label: 'SOCKS5 port',
                  child: _GlassTextField(
                    width: 110,
                    value: '${s.socksPort}',
                    numeric: true,
                    onSubmit: (String v) =>
                        s.setSocksPort(int.tryParse(v) ?? 10808),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 16),
          _Group(
            title: 'Diagnostics',
            children: [
              _SettingRow(
                label: 'API reachability',
                description:
                    'Sends a HEAD request to the catalog API base and reports latency.',
                child: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: () async {
                      final Stopwatch sw = Stopwatch()..start();
                      try {
                        await _ping();
                        sw.stop();
                        if (context.mounted) {
                          toasts.success(
                            'API reachable in ${sw.elapsedMilliseconds} ms',
                          );
                        }
                      } catch (e) {
                        if (context.mounted) {
                          toasts.error('API unreachable: $e');
                        }
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        gradient: AppPalette.accentGradient,
                        borderRadius: BorderRadius.circular(
                          AppPalette.radiusButton,
                        ),
                        boxShadow: [
                          BoxShadow(color: AppPalette.glow, blurRadius: 12),
                        ],
                      ),
                      child: const Text(
                        'Test connection',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Tip: for the SOCKS5 mode make sure your local proxy client '
                '(V2Ray / Nekoray / …) is listening before starting downloads.',
                style: TextStyle(
                  color: palette.textSecondary,
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static Future<dynamic> _ping() async {
    final io.HttpClient client = io.HttpClient()
      ..connectionTimeout = const Duration(seconds: 8);
    try {
      final io.HttpClientRequest req = await client.headUrl(
        Uri.parse('https://server-hi-speed-iran.info'),
      );
      final io.HttpClientResponse res = await req.close();
      if (res.statusCode >= 500) {
        throw Exception('HTTP ${res.statusCode}');
      }
      return res.statusCode;
    } finally {
      client.close(force: true);
    }
  }
}

class _GlassTextField extends StatefulWidget {
  const _GlassTextField({
    required this.width,
    required this.value,
    required this.onSubmit,
    this.numeric = false,
  });

  final double width;
  final String value;
  final ValueChanged<String> onSubmit;
  final bool numeric;

  @override
  State<_GlassTextField> createState() => _GlassTextFieldState();
}

class _GlassTextFieldState extends State<_GlassTextField> {
  late final TextEditingController _c = TextEditingController(
    text: widget.value,
  );

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return SizedBox(
      width: widget.width,
      height: 34,
      child: TextField(
        controller: _c,
        keyboardType: widget.numeric
            ? TextInputType.number
            : TextInputType.text,
        onSubmitted: widget.onSubmit,
        style: TextStyle(color: palette.textPrimary, fontSize: 12.5),
        cursorColor: AppPalette.accentStart,
        decoration: InputDecoration(
          isDense: true,
          filled: true,
          fillColor: palette.panelSoft,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 9,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppPalette.radiusButton),
            borderSide: BorderSide(color: palette.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppPalette.radiusButton),
            borderSide: const BorderSide(color: AppPalette.accentStart),
          ),
        ),
      ),
    );
  }
}

class _AboutTab extends StatelessWidget {
  const _AboutTab();

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return SingleChildScrollView(
      child: Column(
        children: [
          _Group(
            title: 'CCloud PRO',
            children: [
              Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      gradient: AppPalette.accentGradient,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(color: AppPalette.glow, blurRadius: 22),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        'assets/logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: const Color(0xFF0B0E16),
                          child: const Icon(
                            Icons.play_arrow_rounded,
                            size: 30,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'CCloud PRO 2.0.0',
                          style: TextStyle(
                            color: palette.textPrimary,
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'Fluent 2 / Acrylic Glass rebuild — streaming, live TV, in-app downloads and a full subtitle engine.',
                          style: TextStyle(
                            color: palette.textSecondary,
                            fontSize: 12,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: GestureDetector(
                      onTap: () => launchUrl(
                        Uri.parse('https://github.com/code3-dev/CCloud-GUI'),
                        mode: LaunchMode.externalApplication,
                      ),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 9,
                        ),
                        decoration: BoxDecoration(
                          color: palette.panelStrong,
                          borderRadius: BorderRadius.circular(
                            AppPalette.radiusButton,
                          ),
                          border: Border.all(color: palette.border),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.code_rounded,
                              size: 15,
                              color: palette.textPrimary,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'GitHub repository',
                              style: TextStyle(
                                color: palette.textPrimary,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
