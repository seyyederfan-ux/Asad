import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../providers/seasons_provider.dart';
import '../../services/continue_watching_service.dart';
import '../../services/download_manager.dart';
import '../../services/download_task.dart';
import '../../services/favorites_service.dart';
import '../../services/toast_service.dart';
import '../widgets/badges.dart';
import '../widgets/download_mirrors_modal.dart';
import '../widgets/empty_state.dart';
import '../widgets/glass_button.dart';
import '../widgets/glass_panel.dart';
import '../widgets/section_header.dart';

/// Immersive detail page (full window, no sidebar): lead card with cover and
/// actions, quality chips for movies, season tabs + episode list for series.
class MediaDetailScreen extends StatefulWidget {
  const MediaDetailScreen({super.key, required this.item});

  final MediaItem? item;

  @override
  State<MediaDetailScreen> createState() => _MediaDetailScreenState();
}

class _MediaDetailScreenState extends State<MediaDetailScreen> {
  Source? _selectedSource;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || widget.item == null) {
        return;
      }
      context.read<ContinueWatchingService>().load();
      context.read<FavoritesService>().load();
      if (widget.item!.isSeries()) {
        context.read<SeasonsProvider>().loadSeasons(widget.item!.id);
      }
    });
  }

  void _play(
    BuildContext context,
    MediaItem item, {
    Source? source,
    Episode? episode,
  }) {
    context.push(
      '/player',
      extra: PlaybackRequest(media: item, source: source, episode: episode),
    );
  }

  void _copyLink(BuildContext context, String url) {
    Clipboard.setData(ClipboardData(text: url));
    context.read<ToastService>().success('Direct CDN link copied');
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final MediaItem? item = widget.item;

    if (item == null) {
      return Scaffold(
        body: EmptyState(
          icon: Icons.error_outline_rounded,
          title: 'Title not available',
          subtitle:
              'The requested media could not be resolved. Return to the catalog and try again.',
          ctaLabel: 'Back to Movies',
          onCta: () => context.go('/movies'),
        ),
      );
    }

    final FavoritesService favorites = context.watch<FavoritesService>();
    final bool saved = favorites.containsSync(item);
    final WatchProgress? resumeProgress = context
        .watch<ContinueWatchingService>()
        .forKey('${item.type}-${item.id}');

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AppBackground(),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(32, 24, 32, 48),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Back row
                  Row(
                    children: [
                      GlassIconButton(
                        icon: Icons.arrow_back_rounded,
                        tooltip: 'Back',
                        onPressed: () {
                          if (context.canPop()) {
                            context.pop();
                          } else {
                            context.go('/home');
                          }
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Lead card
                  _LeadCard(
                    item: item,
                    saved: saved,
                    progress: resumeProgress,
                    selectedSource: _selectedSource,
                    onSourceTap: (Source s) =>
                        setState(() => _selectedSource = s),
                    onPlay: () => _play(context, item, source: _selectedSource),
                    onLinks: () => DownloadMirrorsModal.show(
                      context,
                      title: item.title,
                      sources: item.sources,
                      onCopy: (String url) {},
                    ),
                    onBookmark: () async {
                      final bool now = await favorites.toggle(item);
                      if (context.mounted) {
                        context.read<ToastService>().show(
                          now
                              ? 'Added to your watchlist'
                              : 'Removed from watchlist',
                          type: now ? ToastType.success : ToastType.info,
                        );
                      }
                    },
                    onCopyBest: () {
                      final Source? s =
                          _selectedSource ??
                          (item.sources.isNotEmpty ? item.sources.first : null);
                      if (s != null) {
                        _copyLink(context, s.url);
                      }
                    },
                  ),
                  const SizedBox(height: 30),

                  if (item.isMovie()) ...[
                    if (item.sources.isNotEmpty) ...[
                      SectionHeader(title: 'Available Qualities'),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          for (final Source s in item.sources)
                            _QualityPill(
                              source: s,
                              selected: _selectedSource == s,
                              palette: palette,
                              onTap: () => setState(() => _selectedSource = s),
                              onDownload: () async {
                                final DownloadTask? t = await DownloadManager
                                    .instance
                                    .enqueue(
                                      url: s.url,
                                      title: item.title,
                                      quality: s.quality,
                                    );
                                if (context.mounted) {
                                  context.read<ToastService>().show(
                                    t == null
                                        ? 'Already in the download queue'
                                        : 'Download queued — ${s.quality}',
                                    type: t == null
                                        ? ToastType.info
                                        : ToastType.success,
                                  );
                                }
                              },
                            ),
                        ],
                      ),
                    ],
                  ] else ...[
                    _SeasonsSection(item: item, onPlay: _play),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LeadCard extends StatelessWidget {
  const _LeadCard({
    required this.item,
    required this.saved,
    required this.progress,
    required this.selectedSource,
    required this.onSourceTap,
    required this.onPlay,
    required this.onLinks,
    required this.onBookmark,
    required this.onCopyBest,
  });

  final MediaItem item;
  final bool saved;
  final WatchProgress? progress;
  final Source? selectedSource;
  final ValueChanged<Source> onSourceTap;
  final VoidCallback onPlay;
  final VoidCallback onLinks;
  final VoidCallback onBookmark;
  final VoidCallback onCopyBest;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final WatchProgress? progress = this.progress;
    return GlassPanel(
      radius: AppPalette.radiusCard,
      blur: 26,
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppPalette.radiusCard - 1),
        child: Column(
          children: [
            // Cover header
            SizedBox(
              height: 210,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    item.cover.isNotEmpty ? item.cover : item.image,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.medium,
                    errorBuilder: (_, __, ___) =>
                        Container(color: palette.surfaceTint),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          (palette.dark
                              ? const Color(0xE60C0E15)
                              : const Color(0xE6EDF1F6)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 22),
              child: Transform.translate(
                offset: const Offset(0, -34),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Poster thumb
                        Container(
                          width: 108,
                          height: 156,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              AppPalette.radiusCardSmall,
                            ),
                            border: Border.all(color: palette.border, width: 1),
                            boxShadow: [
                              BoxShadow(
                                color: AppPalette.glow.withValues(alpha: 0.4),
                                blurRadius: 24,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(
                              AppPalette.radiusCardSmall - 1,
                            ),
                            child: Image.network(
                              item.image.isNotEmpty ? item.image : item.cover,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: palette.surfaceTint,
                                child: Icon(
                                  Icons.movie_rounded,
                                  color: palette.textSecondary,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: palette.textPrimary,
                                  fontSize: 25,
                                  fontWeight: FontWeight.w800,
                                  height: 1.1,
                                  letterSpacing: -0.4,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: [
                                  ImdbChip(score: item.imdb),
                                  if (item.year > 0)
                                    MetaChip(label: '${item.year}'),
                                  if ((item.duration ?? '').isNotEmpty)
                                    MetaChip(
                                      label: item.duration!,
                                      icon: Icons.schedule_rounded,
                                      color: palette.textPrimary,
                                    ),
                                  ...item.genres
                                      .take(3)
                                      .map(
                                        (Genre g) => MetaChip(label: g.title),
                                      ),
                                  ...item.countries
                                      .take(1)
                                      .map(
                                        (Country c) => MetaChip(label: c.title),
                                      ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      item.description,
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textSecondary,
                        fontSize: 13,
                        height: 1.6,
                      ),
                    ),
                    if (progress != null && progress.progress > 0.01) ...[
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Icon(
                            Icons.history_rounded,
                            size: 14,
                            color: AppPalette.accentStart,
                          ),
                          const SizedBox(width: 7),
                          Text(
                            'You are ${((1 - progress.progress) * 100).round()}% away from the end',
                            style: TextStyle(
                              color: palette.textSecondary,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        PrimaryGradientButton(
                          label: progress != null && progress.progress > 0.02
                              ? 'Resume Playback'
                              : 'Stream Now',
                          icon: Icons.play_arrow_rounded,
                          onPressed: onPlay,
                        ),
                        GlassButton(
                          label: 'Download Links',
                          icon: Icons.download_rounded,
                          accent: true,
                          onPressed: onLinks,
                        ),
                        GlassButton(
                          label: saved ? 'Bookmarked' : 'Bookmark',
                          icon: saved
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          onPressed: onBookmark,
                        ),
                        GlassButton(
                          label: 'Copy Best Link',
                          icon: Icons.copy_rounded,
                          onPressed: onCopyBest,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QualityPill extends StatefulWidget {
  const _QualityPill({
    required this.source,
    required this.selected,
    required this.palette,
    required this.onTap,
    required this.onDownload,
  });

  final Source source;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;
  final VoidCallback onDownload;

  @override
  State<_QualityPill> createState() => _QualityPillState();
}

class _QualityPillState extends State<_QualityPill> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    final bool active = widget.selected || _hover;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
          decoration: BoxDecoration(
            gradient: widget.selected ? AppPalette.accentGradient : null,
            color: widget.selected ? null : palette.panel,
            borderRadius: BorderRadius.circular(AppPalette.radiusButton + 2),
            border: Border.all(
              color: active
                  ? AppPalette.accentStart.withValues(
                      alpha: widget.selected ? 0.35 : 0.6,
                    )
                  : palette.border,
              width: 1,
            ),
            boxShadow: widget.selected
                ? [
                    BoxShadow(
                      color: AppPalette.glow.withValues(alpha: 0.65),
                      blurRadius: 14,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.source.quality.isEmpty
                    ? 'Stream'
                    : widget.source.quality,
                style: TextStyle(
                  color: widget.selected ? Colors.white : palette.textPrimary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if ((widget.source.type).isNotEmpty) ...[
                const SizedBox(width: 7),
                Text(
                  widget.source.type.toUpperCase(),
                  style: TextStyle(
                    color: widget.selected
                        ? Colors.white.withValues(alpha: 0.8)
                        : palette.textSecondary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
              const SizedBox(width: 8),
              _PillMiniAction(
                icon: Icons.download_rounded,
                selected: widget.selected,
                palette: palette,
                onTap: widget.onDownload,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PillMiniAction extends StatelessWidget {
  const _PillMiniAction({
    required this.icon,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final IconData icon;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: selected
                ? Colors.white.withValues(alpha: 0.22)
                : palette.panelStrong,
            borderRadius: BorderRadius.circular(7),
          ),
          child: Icon(
            icon,
            size: 13,
            color: selected ? Colors.white : AppPalette.accentStart,
          ),
        ),
      ),
    );
  }
}

class _SeasonsSection extends StatelessWidget {
  const _SeasonsSection({required this.item, required this.onPlay});

  final MediaItem item;
  final void Function(
    BuildContext,
    MediaItem, {
    Source? source,
    Episode? episode,
  })
  onPlay;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final SeasonsProvider seasons = context.watch<SeasonsProvider>();

    if (seasons.isLoading && seasons.seasons.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(28),
          child: CircularProgressIndicator(strokeWidth: 2.4),
        ),
      );
    }
    if (seasons.seasons.isEmpty) {
      return EmptyState(
        icon: Icons.video_library_outlined,
        title: 'No seasons published yet',
        subtitle:
            'This series has no episode data available at the moment. Check back soon.',
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // .season-tabs-row — bottom hairline + 10px padding
        Container(
          padding: const EdgeInsets.only(bottom: 10),
          margin: const EdgeInsets.only(bottom: 4),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: palette.border)),
          ),
          child: SizedBox(
            height: 32,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: seasons.seasons.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (BuildContext context, int index) {
                final Season s = seasons.seasons[index];
                final bool selected = seasons.selectedSeasonIndex == index;
                return _SeasonTab(
                  label: s.title.isEmpty ? 'Season ${index + 1}' : s.title,
                  episodes: s.episodes.length,
                  selected: selected,
                  palette: palette,
                  onTap: () => seasons.selectSeason(index),
                );
              },
            ),
          ),
        ),
        const SizedBox(height: 16),

        // Episodes
        ...seasons.selectedSeason?.episodes
                .asMap()
                .entries
                .map(
                  (MapEntry<int, Episode> e) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _EpisodeRow(
                      index: e.key + 1,
                      episode: e.value,
                      palette: palette,
                      onPlay: () => onPlay(context, item, episode: e.value),
                      onLinks: () => DownloadMirrorsModal.show(
                        context,
                        title: '${item.title} — ${e.value.title}',
                        sources: e.value.sources,
                        onCopy: (String url) {},
                      ),
                      onDownloadFirst: () async {
                        if (e.value.sources.isEmpty) {
                          return;
                        }
                        final Source s = e.value.sources.first;
                        final DownloadTask? t = await DownloadManager.instance
                            .enqueue(
                              url: s.url,
                              title: '${item.title} — ${e.value.title}',
                              quality: s.quality,
                            );
                        if (context.mounted) {
                          context.read<ToastService>().show(
                            t == null
                                ? 'Episode already queued'
                                : 'Episode queued — ${s.quality}',
                            type: t == null
                                ? ToastType.info
                                : ToastType.success,
                          );
                        }
                      },
                    ),
                  ),
                )
                .toList() ??
            <Widget>[],
      ],
    );
  }
}

class _SeasonTab extends StatelessWidget {
  const _SeasonTab({
    required this.label,
    required this.episodes,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final String label;
  final int episodes;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 32,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          alignment: Alignment.center,
          // .season-tab-btn — transparent; active = card-hover + accent text
          decoration: BoxDecoration(
            color: selected ? palette.cardHover : Colors.transparent,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
              color: selected ? palette.border : Colors.transparent,
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: selected ? palette.accent : palette.textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '$episodes EP',
                style: TextStyle(
                  color: selected ? palette.accent : palette.textFaint,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EpisodeRow extends StatelessWidget {
  const _EpisodeRow({
    required this.index,
    required this.episode,
    required this.palette,
    required this.onPlay,
    required this.onLinks,
    required this.onDownloadFirst,
  });

  final int index;
  final Episode episode;
  final AppPalette palette;
  final VoidCallback onPlay;
  final VoidCallback onLinks;
  final VoidCallback onDownloadFirst;

  @override
  Widget build(BuildContext context) {
    return GlassSurface(
      radius: AppPalette.radiusCardSmall,
      padding: const EdgeInsets.all(10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          Container(
            width: 138,
            height: 78,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(9),
              color: palette.surfaceTint,
              border: Border.all(color: palette.border),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    episode.image,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.medium,
                    errorBuilder: (_, __, ___) => Center(
                      child: Icon(
                        Icons.tv_rounded,
                        size: 22,
                        color: palette.textSecondary,
                      ),
                    ),
                  ),
                  Center(
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        gradient: AppPalette.accentGradient,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: AppPalette.glow, blurRadius: 14),
                        ],
                      ),
                      child: const Icon(
                        Icons.play_arrow_rounded,
                        size: 19,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Material(
                    type: MaterialType.transparency,
                    child: InkWell(
                      onTap: onPlay,
                      child: const SizedBox.expand(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: palette.panelStrong,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: palette.border),
                      ),
                      child: Text(
                        'E$index',
                        style: TextStyle(
                          color: AppPalette.accentStart,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        episode.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textPrimary,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    if ((episode.duration ?? '').isNotEmpty)
                      Text(
                        episode.duration!,
                        style: TextStyle(
                          color: palette.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  episode.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: palette.textSecondary,
                    fontSize: 11.5,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: onPlay,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            gradient: AppPalette.accentGradient,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(
                                color: AppPalette.glow.withValues(alpha: 0.5),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: const Row(
                            children: [
                              Icon(
                                Icons.play_arrow_rounded,
                                size: 14,
                                color: Colors.white,
                              ),
                              SizedBox(width: 4),
                              Text(
                                'Play',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: onDownloadFirst,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: palette.panelStrong,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: palette.border),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.download_rounded,
                                size: 14,
                                color: palette.textPrimary,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'In-App DL',
                                style: TextStyle(
                                  color: palette.textPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: onLinks,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: palette.panelStrong,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: palette.border),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.link_rounded,
                                size: 14,
                                color: palette.textPrimary,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'Links',
                                style: TextStyle(
                                  color: palette.textPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
