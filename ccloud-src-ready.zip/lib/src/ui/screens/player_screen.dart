import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';

import '../../core/router/playback_request.dart';
import '../../core/theme/app_colors.dart';
import '../../models/media_item.dart';
import '../../models/poster.dart';
import '../../models/search_result.dart';
import '../../platform/vlc_launcher.dart';
import '../../player/subtitle_parser.dart';
import '../../repositories/search_repository.dart';
import '../../services/continue_watching_service.dart';
import '../../services/settings_service.dart';
import '../../services/toast_service.dart';
import '../player/subtitle_flyout.dart';
import '../widgets/download_mirrors_modal.dart';
import '../widgets/empty_state.dart';
import '../widgets/glass_dropdown.dart';
import '../widgets/glass_button.dart';

/// Immersive in-app player (media_kit) with the glass HUD: dual scrubber
/// (buffer + position), 10s skips, quality switcher, hybrid `Open in VLC`,
/// and the floating subtitle flyout with local-file upload + sync
/// calibration + live font sizing.
class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, this.request});

  final PlaybackRequest? request;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> with WindowListener {
  Player? _player;
  VideoController? _controller;

  List<Source> _sources = <Source>[];
  Source? _currentSource;
  String _resolveNote = '';

  bool _hudVisible = true;
  bool _loading = true;
  bool _buffering = false;
  bool _playing = false;
  bool _error = false;
  bool _fullscreen = false;
  Duration _position = Duration.zero;
  Duration _buffered = Duration.zero;
  Duration _duration = Duration.zero;
  double _volume = 100;

  Timer? _hudTimer;
  Timer? _saveTimer;

  // Subtitle state
  bool _subEnabled = true;
  bool _flyoutOpen = false;
  bool _uploadingSub = false;
  double _offset = 0;
  SubtitleSize _subSize = SubtitleSize.medium;
  SubtitleDocument? _activeDoc;
  String _activeTrackId = 'off';
  final List<SubtitleDocument> _externalDocs = <SubtitleDocument>[];
  List<String> _embeddedLines = const <String>[];

  MediaItem get _media => widget.request!.media;

  @override
  void initState() {
    super.initState();
    windowManager.addListener(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    final SettingsService settings = context.read<SettingsService>();
    if (!settings.loaded) {
      await settings.load();
    }
    setState(() {
      _subEnabled = settings.subtitlesEnabled;
      _offset = settings.subtitleOffsetSeconds;
      _subSize = settings.subtitleSize;
    });

    final PlaybackRequest? request = widget.request;
    if (request == null) {
      setState(() => _loading = false);
      return;
    }

    if (request.sources.isNotEmpty) {
      _sources = request.sources;
      final Source? best = request.bestSource(settings.preferredQuality);
      if (best != null) {
        await _start(best);
      } else {
        setState(() {
          _loading = false;
          _error = true;
        });
      }
      return;
    }

    // Continue-watching entries carry no sources — resolve them through the
    // preserved search repository by matching the persisted title/id.
    setState(() => _resolveNote = 'Resolving sources…');
    try {
      final SearchResult result = await SearchRepository().search(_media.title);
      final List<Poster> posters = result.posters;
      Poster? match;
      for (final Poster p in posters) {
        if (p.id == _media.id && p.type == _media.type) {
          match = p;
          break;
        }
      }
      match ??= posters.isNotEmpty ? posters.first : null;
      if (match != null && match.toMediaItem().sources.isNotEmpty) {
        setState(() => _sources = match!.toMediaItem().sources);
        await _start(
          request.bestSource(settings.preferredQuality) ?? _sources.first,
        );
        return;
      }
    } catch (_) {
      // fall through to empty-state
    }
    setState(() {
      _loading = false;
      _resolveNote = '';
    });
  }

  Future<void> _start(Source source) async {
    final SettingsService settings = context.read<SettingsService>();
    final Player player = Player(
      configuration: const PlayerConfiguration(bufferSize: 64 * 1024 * 1024),
    );
    final VideoController controller = VideoController(
      player,
      configuration: VideoControllerConfiguration(
        enableHardwareAcceleration: settings.gpuHardwareAcceleration,
      ),
    );
    _player = player;
    _controller = controller;
    _currentSource = source;
    _error = false;
    _loading = true;

    player.stream.position.listen((Duration d) {
      if (mounted) {
        setState(() => _position = d);
      }
    });
    player.stream.duration.listen((Duration d) {
      if (mounted) {
        setState(() => _duration = d);
      }
    });
    player.stream.buffer.listen((Duration d) {
      if (mounted) {
        setState(() => _buffered = d);
      }
    });
    player.stream.playing.listen((bool v) {
      if (mounted) {
        setState(() {
          _playing = v;
          _loading = false;
        });
      }
    });
    player.stream.buffering.listen((bool v) {
      if (mounted) {
        setState(() => _buffering = v);
      }
    });
    player.stream.completed.listen((bool v) {
      if (v && mounted) {
        _saveProgress(force: true);
      }
    });
    player.stream.error.listen((String e) {
      if (e.isNotEmpty && mounted) {
        setState(() {
          _error = true;
          _loading = false;
        });
        context.read<ToastService>().error('Playback error: $e');
      }
    });
    player.stream.tracks.listen((Tracks t) {
      if (mounted) {
        setState(() {});
      }
    });
    player.stream.subtitle.listen((List<String> lines) {
      if (mounted) {
        setState(() => _embeddedLines = lines);
      }
    });

    if (settings.gpuHardwareAcceleration) {
      try {
        final dynamic platform = player.platform;
        await platform?.setProperty('hwdec', 'auto-safe');
      } catch (_) {
        // hwdec is best-effort.
      }
    }

    await player.setVolume(_volume);
    _applySubtitleTrackState();

    await player.open(Media(source.url));

    _saveTimer?.cancel();
    _saveTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => _saveProgress(),
    );
    _wakeHud();
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _switchSource(Source source) async {
    if (_player == null || source.url == _currentSource?.url) {
      return;
    }
    final Duration resumeAt = _position;
    await _player!.open(Media(source.url));
    _currentSource = source;
    if (resumeAt > const Duration(seconds: 3)) {
      await Future<void>.delayed(const Duration(milliseconds: 450));
      await _player?.seek(resumeAt);
    }
    if (mounted) {
      context.read<ToastService>().show('Switched to ${source.quality}');
      setState(() {});
    }
  }

  void _saveProgress({bool force = false}) {
    if (!mounted || _duration.inMilliseconds <= 0) {
      return;
    }
    if (!force && _position.inMilliseconds < 3000) {
      return;
    }
    final ContinueWatchingService cw = context.read<ContinueWatchingService>();
    cw.upsert(_media, position: _position, duration: _duration);
  }

  // ------------------------------------------------------------------- HUD

  void _wakeHud() {
    _hudTimer?.cancel();
    if (mounted && !_hudVisible) {
      setState(() => _hudVisible = true);
    }
    _hudTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _playing) {
        setState(() {
          _hudVisible = false;
          _flyoutOpen = false;
        });
      }
    });
  }

  Future<void> _togglePlay() async {
    await _player?.playOrPause();
    _wakeHud();
  }

  Future<void> _seekBy(int seconds) async {
    final Duration target = _position + Duration(seconds: seconds);
    final Duration clamped = target < Duration.zero
        ? Duration.zero
        : (target > _duration && _duration > Duration.zero
              ? _duration
              : target);
    await _player?.seek(clamped);
    _wakeHud();
  }

  Future<void> _toggleFullscreen() async {
    _fullscreen = !_fullscreen;
    await windowManager.setFullScreen(_fullscreen);
    if (mounted) {
      setState(() {});
    }
  }

  // -------------------------------------------------------------- subtitles

  List<SubtitleTrackOption> _trackOptions() {
    final List<SubtitleTrackOption> options = <SubtitleTrackOption>[];
    final List<SubtitleTrack> embedded =
        _player?.state.tracks.subtitle ?? <SubtitleTrack>[];
    int i = 0;
    for (final SubtitleTrack t in embedded) {
      if (t.id == 'no' || t.id == 'auto') {
        continue;
      }
      i++;
      final String label = (t.title?.isNotEmpty ?? false)
          ? t.title!
          : (t.language?.toUpperCase() ?? 'Track $i');
      options.add(SubtitleTrackOption(id: t.id, label: label));
    }
    for (int j = 0; j < _externalDocs.length; j++) {
      options.add(
        SubtitleTrackOption(
          id: 'ext-$j',
          label: _externalDocs[j].name,
          external: true,
        ),
      );
    }
    return options;
  }

  void _applySubtitleTrackState() {
    final Player? player = _player;
    if (player == null) {
      return;
    }
    if (!_subEnabled || _activeDoc != null) {
      player.setSubtitleTrack(SubtitleTrack.no());
    }
  }

  Future<void> _selectTrack(String id) async {
    final Player? player = _player;
    if (player == null) {
      return;
    }
    if (id.startsWith('ext-')) {
      final int index = int.tryParse(id.substring(4)) ?? -1;
      if (index < 0 || index >= _externalDocs.length) {
        return;
      }
      setState(() {
        _activeDoc = _externalDocs[index];
        _activeTrackId = id;
        _subEnabled = true;
      });
      await player.setSubtitleTrack(SubtitleTrack.no());
      if (mounted) {
        context.read<ToastService>().success(
          'Subtitle: ${_externalDocs[index].name}',
        );
      }
      return;
    }
    for (final SubtitleTrack t in player.state.tracks.subtitle) {
      if (t.id == id) {
        setState(() {
          _activeDoc = null;
          _activeTrackId = id;
          _subEnabled = true;
          _embeddedLines = const <String>[];
        });
        await player.setSubtitleTrack(t);
        if (mounted) {
          context.read<ToastService>().success('Subtitle track enabled');
        }
        return;
      }
    }
  }

  Future<void> _uploadSubtitle() async {
    if (_uploadingSub) {
      return;
    }
    setState(() => _uploadingSub = true);
    try {
      final FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: <String>['srt', 'vtt', 'ass'],
      );
      final String? path = result?.files.single.path;
      if (path == null) {
        return;
      }
      final String content = await File(path).readAsString();
      final String name = result!.files.single.name;
      final SubtitleDocument doc = SubtitleParser.parse(
        name,
        content,
        filePath: path,
      );
      if (doc.isEmpty) {
        if (mounted) {
          context.read<ToastService>().warning('No cues found in $name');
        }
        return;
      }
      setState(() {
        _externalDocs.add(doc);
        _activeDoc = doc;
        _activeTrackId = 'ext-${_externalDocs.length - 1}';
        _subEnabled = true;
      });
      await _player?.setSubtitleTrack(SubtitleTrack.no());
      if (mounted) {
        context.read<ToastService>().success(
          '${doc.cues.length} cues loaded from $name',
        );
      }
    } catch (e) {
      if (mounted) {
        context.read<ToastService>().error('Failed to read subtitle: $e');
      }
    } finally {
      if (mounted) {
        setState(() => _uploadingSub = false);
      }
    }
  }

  Future<void> _toggleSubtitles(bool v) async {
    final Player? player = _player;
    setState(() {
      _subEnabled = v;
      if (!v) {
        _activeDoc = null;
        _activeTrackId = 'off';
      }
    });
    await context.read<SettingsService>().setSubtitlesEnabled(v);
    if (player != null) {
      await player.setSubtitleTrack(
        v ? SubtitleTrack.auto() : SubtitleTrack.no(),
      );
    }
    if (mounted) {
      context.read<ToastService>().show(v ? 'Subtitles on' : 'Subtitles off');
    }
  }

  Future<void> _stepOffset(double delta) async {
    final double next = (_offset + delta);
    await context.read<SettingsService>().setSubtitleOffsetSeconds(next);
    setState(() => _offset = next);
  }

  Future<void> _resetOffset() async {
    await context.read<SettingsService>().setSubtitleOffsetSeconds(0);
    setState(() => _offset = 0);
    if (mounted) {
      context.read<ToastService>().success('Subtitle sync reset');
    }
  }

  Future<void> _changeSize(SubtitleSize s) async {
    await context.read<SettingsService>().setSubtitleSize(s);
    setState(() => _subSize = s);
    if (mounted) {
      context.read<ToastService>().show(
        'Subtitle size: ${s.name.toUpperCase()}',
      );
    }
  }

  // ----------------------------------------------------------------- build

  @override
  void onWindowClose() async {
    await _saveProgressOnClose();
  }

  Future<void> _saveProgressOnClose() async {
    _saveProgress(force: true);
  }

  String _fmt(Duration d) {
    final int h = d.inHours;
    final int m = d.inMinutes % 60;
    final int s = d.inSeconds % 60;
    if (h > 0) {
      return '$h:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _hudTimer?.cancel();
    windowManager.removeListener(this);
    if (_fullscreen) {
      windowManager.setFullScreen(false);
    }
    _saveProgressOnClose();
    _player?.dispose();
    super.dispose();
  }

  double get _subFontSize {
    switch (_subSize) {
      case SubtitleSize.small:
        return 14; // .setSubtitleSize(14)
      case SubtitleSize.medium:
        return 17; // .setSubtitleSize(17)
      case SubtitleSize.large:
        return 21; // .setSubtitleSize(21)
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );

    if (widget.request == null) {
      return Scaffold(
        body: EmptyState(
          icon: Icons.play_circle_outline_rounded,
          title: 'Nothing is playing',
          subtitle:
              'Pick any movie or series and hit Stream Now — the player opens here with full subtitle support.',
          ctaLabel: 'Browse Catalog',
          onCta: () => context.go('/movies'),
        ),
      );
    }

    if (_controller == null && !_loading && (_sources.isEmpty || _error)) {
      return Scaffold(
        body: EmptyState(
          icon: Icons.cloud_off_rounded,
          title: _error ? 'Playback failed' : 'No stream sources available',
          subtitle: _resolveNote.isNotEmpty
              ? _resolveNote
              : 'This title does not expose any playable mirrors right now. Try the download links instead.',
          ctaLabel: 'Open Title Page',
          onCta: () => context.push('/detail', extra: _media),
        ),
      );
    }

    final String subtitleText = _currentSubtitleText();

    return Scaffold(
      backgroundColor: Colors.black,
      body: CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.space): _togglePlay,
          const SingleActivator(LogicalKeyboardKey.arrowLeft): () =>
              _seekBy(-10),
          const SingleActivator(LogicalKeyboardKey.arrowRight): () =>
              _seekBy(10),
          const SingleActivator(LogicalKeyboardKey.keyF): _toggleFullscreen,
          const SingleActivator(LogicalKeyboardKey.keyC): () =>
              setState(() => _flyoutOpen = !_flyoutOpen),
        },
        child: Focus(
          autofocus: true,
          child: MouseRegion(
            onHover: (_) => _wakeHud(),
            onExit: (_) => _wakeHud(),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Video layer
                if (_controller != null)
                  Video(
                    controller: _controller!,
                    controls: NoVideoControls,
                    subtitleViewConfiguration: const SubtitleViewConfiguration(
                      visible: false,
                    ),
                  )
                else
                  Container(
                    color: const Color(0xFF05060A),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(
                            strokeWidth: 2.6,
                            color: AppPalette.accentStart,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _resolveNote.isEmpty
                                ? 'Opening stream…'
                                : _resolveNote,
                            style: const TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // Loading veil over video
                if (_controller != null && _loading)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: CircularProgressIndicator(
                        strokeWidth: 2.6,
                        color: AppPalette.accentStart,
                      ),
                    ),
                  ),

                // Center big play (.player-big-play — 68px gradient orb)
                if (_controller != null &&
                    !_playing &&
                    !_buffering &&
                    !_loading)
                  Center(
                    child: MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: _togglePlay,
                        child: TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0.8, end: 1),
                          duration: const Duration(milliseconds: 180),
                          curve: Curves.easeOutBack,
                          builder: (BuildContext ctx, double s, Widget? ch) {
                            if (ch == null) {
                              return const SizedBox.shrink();
                            }
                            return Transform.scale(scale: s, child: ch);
                          },
                          child: Container(
                            width: 68,
                            height: 68,
                            decoration: BoxDecoration(
                              gradient: AppPalette.accentGradient,
                              shape: BoxShape.circle,
                              boxShadow: const [
                                BoxShadow(
                                  color: AppPalette.glow,
                                  blurRadius: 30,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.play_arrow_rounded,
                              size: 34,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                // Subtitle overlay (.player-subtitle-box)
                if (_subEnabled && subtitleText.isNotEmpty)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: _fullscreen ? 34 : 90,
                    child: IgnorePointer(
                      child: Center(
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          constraints: const BoxConstraints(maxWidth: 760),
                          margin: const EdgeInsets.symmetric(horizontal: 32),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: palette.subtitlePlate,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.4),
                                blurRadius: 14,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Text(
                            subtitleText,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: _subFontSize,
                              height: 1.4,
                              fontWeight: FontWeight.w500,
                              shadows: const [
                                Shadow(
                                  color: Color(0xE6000000),
                                  blurRadius: 3,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                // Top HUD (.player-hud-top)
                AnimatedOpacity(
                  opacity: _hudVisible ? 1 : 0,
                  duration: const Duration(milliseconds: 220),
                  child: Container(
                    height: 92,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xCC000000), Colors.transparent],
                      ),
                    ),
                    child: SafeArea(
                      bottom: false,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 18,
                        ),
                        child: Row(
                          children: [
                            // .btn-compact — Back to Library
                            MouseRegion(
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                onTap: () {
                                  if (context.canPop()) {
                                    context.pop();
                                  } else {
                                    context.go('/home');
                                  }
                                },
                                child: Container(
                                  height: 28,
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: Colors.white.withValues(
                                        alpha: 0.22,
                                      ),
                                    ),
                                  ),
                                  child: const Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.arrow_back_rounded,
                                        size: 13,
                                        color: Colors.white,
                                      ),
                                      SizedBox(width: 6),
                                      Text(
                                        'Back to Library',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            const Spacer(),
                            // .player-hud-title + accent quality pill
                            Flexible(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    _media.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Color(0xFFF8FAFC),
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  if (_currentSource != null) ...[
                                    const SizedBox(height: 4),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 7,
                                        vertical: 2,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: AppPalette.accentGradient,
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        '${_currentSource!.quality}'
                                        '${widget.request!.episode != null ? ' • ${widget.request!.episode!.title}' : ''}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            if (_buffering)
                              const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: AppPalette.accentStart,
                                ),
                              ),
                            if (!_buffering && _currentSource != null) ...[
                              const SizedBox(width: 8),
                              GlassIconButton(
                                icon: Icons.download_rounded,
                                tooltip: 'Download This Stream',
                                flat: true,
                                size: 36,
                                iconSize: 19,
                                onPressed: () {
                                  DownloadMirrorsModal.show(
                                    context,
                                    title: _media.title,
                                    sources: _currentSource != null
                                        ? <Source>[_currentSource!]
                                        : _sources,
                                    onCopy: (String url) {},
                                  );
                                },
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                // Bottom HUD
                AnimatedOpacity(
                  opacity: _hudVisible ? 1 : 0,
                  duration: const Duration(milliseconds: 220),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Color(0xEB000000), Colors.transparent],
                        ),
                      ),
                      padding: const EdgeInsets.fromLTRB(24, 26, 24, 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Text(
                                _fmt(_position),
                                style: const TextStyle(
                                  color: Color(0xFFE2E8F0),
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                  fontFeatures: <FontFeature>[
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _Scrubber(
                                  position: _position,
                                  buffered: _buffered,
                                  duration: _duration,
                                  palette: palette,
                                  onSeek: (Duration d) async {
                                    await _player?.seek(d);
                                    _wakeHud();
                                  },
                                ),
                              ),
                              const SizedBox(width: 12),
                              Text(
                                '-${_fmt(_duration - _position)}',
                                style: const TextStyle(
                                  color: Color(0xFF94A3B8),
                                  fontSize: 11.5,
                                  fontFeatures: <FontFeature>[
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              GlassIconButton(
                                icon: _playing
                                    ? Icons.pause_rounded
                                    : Icons.play_arrow_rounded,
                                size: 44,
                                iconSize: 24,
                                flat: true,
                                onPressed: _togglePlay,
                              ),
                              const SizedBox(width: 10),
                              GlassIconButton(
                                icon: Icons.replay_10_rounded,
                                size: 38,
                                iconSize: 19,
                                flat: true,
                                tooltip: '-10s',
                                onPressed: () => _seekBy(-10),
                              ),
                              const SizedBox(width: 6),
                              GlassIconButton(
                                icon: Icons.forward_10_rounded,
                                size: 38,
                                iconSize: 19,
                                flat: true,
                                tooltip: '+10s',
                                onPressed: () => _seekBy(10),
                              ),
                              const SizedBox(width: 14),

                              // Volume
                              Icon(
                                _volume <= 0
                                    ? Icons.volume_off_rounded
                                    : _volume < 55
                                    ? Icons.volume_down_rounded
                                    : Icons.volume_up_rounded,
                                size: 18,
                                color: const Color(0xFFCBD5E1),
                              ),
                              const SizedBox(width: 6),
                              SizedBox(
                                width: 110,
                                child: SliderTheme(
                                  data: SliderTheme.of(
                                    context,
                                  ).copyWith(trackHeight: 3),
                                  child: Slider(
                                    value: _volume.clamp(0, 100),
                                    max: 100,
                                    onChanged: (double v) {
                                      setState(() => _volume = v);
                                      _player?.setVolume(v);
                                    },
                                  ),
                                ),
                              ),
                              const Spacer(),

                              // Subtitles
                              _HudActionButton(
                                icon: Icons.subtitles_rounded,
                                label: 'CC',
                                active: _subEnabled,
                                palette: palette,
                                tooltip: 'Subtitles (C)',
                                onTap: () =>
                                    setState(() => _flyoutOpen = !_flyoutOpen),
                              ),
                              const SizedBox(width: 8),

                              // Quality
                              if (_sources.length > 1)
                                GlassDropdown<Source>(
                                  items: <DropdownItem<Source>>[
                                    for (final Source s in _sources)
                                      DropdownItem<Source>(
                                        value: s,
                                        label: s.quality.isEmpty
                                            ? 'Auto'
                                            : s.quality,
                                        icon: Icons.high_quality_rounded,
                                      ),
                                  ],
                                  value: _currentSource ?? _sources.first,
                                  onChanged: (Source s) => _switchSource(s),
                                  labelBuilder: (DropdownItem<Source> i) =>
                                      i.value.quality.isEmpty
                                      ? 'Auto'
                                      : i.value.quality,
                                  leadingIcon: Icons.high_quality_rounded,
                                  width: 140,
                                  height: 36,
                                ),
                              const SizedBox(width: 8),

                              GlassIconButton(
                                icon: Icons.smart_display_outlined,
                                tooltip: 'Open in VLC',
                                flat: true,
                                onPressed: () async {
                                  if (_currentSource != null) {
                                    context.read<ToastService>().info(
                                      'Opening in VLC…',
                                    );
                                    await VLCLauncher.launchInVLC(
                                      _currentSource!.url,
                                    );
                                  }
                                },
                              ),
                              const SizedBox(width: 6),
                              GlassIconButton(
                                icon: _fullscreen
                                    ? Icons.fullscreen_exit_rounded
                                    : Icons.fullscreen_rounded,
                                tooltip: 'Fullscreen (F)',
                                flat: true,
                                onPressed: _toggleFullscreen,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Subtitle flyout drawer
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutCubic,
                  right: _flyoutOpen ? 16 : -350,
                  top: _fullscreen ? 24 : 96,
                  bottom: _fullscreen ? 110 : 150,
                  width: 316,
                  child: SubtitleFlyout(
                    enabled: _subEnabled,
                    onToggleEnabled: _toggleSubtitles,
                    trackOptions: _trackOptions(),
                    selectedTrackId: _activeTrackId,
                    onSelectTrack: _selectTrack,
                    onUpload: _uploadSubtitle,
                    offset: _offset,
                    onOffsetStep: _stepOffset,
                    onResetOffset: _resetOffset,
                    size: _subSize,
                    onSizeChange: _changeSize,
                    onClose: () => setState(() => _flyoutOpen = false),
                    busy: _uploadingSub,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _currentSubtitleText() {
    if (_activeDoc != null) {
      final SubtitleCue? cue = _activeDoc!.cueAt(
        _position,
        offsetSeconds: _offset,
      );
      return cue?.text ?? '';
    }
    if (_embeddedLines.isNotEmpty) {
      return _embeddedLines.join('\n');
    }
    return '';
  }
}

class _HudActionButton extends StatefulWidget {
  const _HudActionButton({
    required this.icon,
    required this.label,
    required this.active,
    required this.palette,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool active;
  final AppPalette palette;
  final String tooltip;
  final VoidCallback onTap;

  @override
  State<_HudActionButton> createState() => _HudActionButtonState();
}

class _HudActionButtonState extends State<_HudActionButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hover = true),
        onExit: (_) => setState(() => _hover = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 130),
            height: 36,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              gradient: widget.active ? AppPalette.accentGradient : null,
              color: widget.active
                  ? null
                  : _hover
                  ? widget.palette.surfaceTint
                  : widget.palette.panel,
              borderRadius: BorderRadius.circular(AppPalette.radiusButton),
              border: Border.all(
                color: widget.active
                    ? Colors.white.withValues(alpha: 0.2)
                    : widget.palette.border,
                width: 1,
              ),
              boxShadow: widget.active
                  ? [BoxShadow(color: AppPalette.glow, blurRadius: 12)]
                  : null,
            ),
            child: Row(
              children: [
                Icon(
                  widget.icon,
                  size: 15,
                  color: widget.active ? Colors.white : const Color(0xFFCBD5E1),
                ),
                const SizedBox(width: 5),
                Text(
                  widget.label,
                  style: TextStyle(
                    color: widget.active
                        ? Colors.white
                        : const Color(0xFFCBD5E1),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Scrubber extends StatefulWidget {
  const _Scrubber({
    required this.position,
    required this.buffered,
    required this.duration,
    required this.palette,
    required this.onSeek,
  });

  final Duration position;
  final Duration buffered;
  final Duration duration;
  final AppPalette palette;
  final ValueChanged<Duration> onSeek;

  @override
  State<_Scrubber> createState() => _ScrubberState();
}

class _ScrubberState extends State<_Scrubber> {
  bool _hover = false;
  double? _dragFraction;

  double get _fraction {
    if (widget.duration <= Duration.zero) {
      return 0;
    }
    if (_dragFraction != null) {
      return _dragFraction!.clamp(0.0, 1.0);
    }
    return (widget.position.inMilliseconds / widget.duration.inMilliseconds)
        .clamp(0.0, 1.0);
  }

  double get _bufferFraction {
    if (widget.duration <= Duration.zero) {
      return 0;
    }
    return (widget.buffered.inMilliseconds / widget.duration.inMilliseconds)
        .clamp(0.0, 1.0);
  }

  void _seekTo(double fraction) {
    final Duration target = Duration(
      milliseconds: (fraction * widget.duration.inMilliseconds).round(),
    );
    widget.onSeek(target);
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) {
        setState(() {
          _hover = false;
          _dragFraction = null;
        });
      },
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (TapUpDetails d) {
          final RenderBox? box = context.findRenderObject() as RenderBox?;
          if (box == null) {
            return;
          }
          final double f = (d.localPosition.dx / box.size.width).clamp(
            0.0,
            1.0,
          );
          _seekTo(f);
        },
        onHorizontalDragStart: (DragStartDetails d) {
          setState(() => _dragFraction = _fraction);
        },
        onHorizontalDragUpdate: (DragUpdateDetails d) {
          final RenderBox? box = context.findRenderObject() as RenderBox?;
          if (box == null) {
            return;
          }
          setState(() {
            _dragFraction = (d.localPosition.dx / box.size.width).clamp(
              0.0,
              1.0,
            );
          });
        },
        onHorizontalDragEnd: (DragEndDetails d) {
          if (_dragFraction != null) {
            _seekTo(_dragFraction!);
          }
          setState(() => _dragFraction = null);
        },
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints c) {
            // .scrubber-track — 5px, grows to 8px on hover
            final double trackH = _hover || _dragFraction != null ? 8 : 5;
            return SizedBox(
              height: 22,
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  // Track
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    height: trackH,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  // Buffered (.scrubber-buffer)
                  FractionallySizedBox(
                    widthFactor: _bufferFraction,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      height: trackH,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  ),
                  // Progress (.scrubber-progress)
                  FractionallySizedBox(
                    widthFactor: _fraction,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      height: trackH,
                      decoration: BoxDecoration(
                        gradient: AppPalette.accentGradient,
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  ),
                  // Thumb
                  Positioned(
                    left: (_fraction * c.maxWidth).clamp(0.0, c.maxWidth - 12),
                    child: AnimatedOpacity(
                      opacity: _hover || _dragFraction != null ? 1 : 0,
                      duration: const Duration(milliseconds: 140),
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: Color(0x897C3AED), blurRadius: 12),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
