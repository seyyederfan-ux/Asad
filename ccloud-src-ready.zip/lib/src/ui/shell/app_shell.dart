import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:window_manager/window_manager.dart';

import '../../core/theme/app_colors.dart';
import '../widgets/glass_panel.dart';
import '../widgets/toast_overlay.dart';
import 'sidebar.dart';
import 'title_bar.dart';

/// Persistent application chrome mirroring the `.app-window` frame of the
/// prototype: an acrylic glass sheet (blur 40 + saturate 180%) floating with
/// a 14px margin, 18px radius, glass border and ambient shadow. Maximizing
/// collapses the frame edge-to-edge. Toasts render bottom-right above all.
class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    required this.location,
    required this.initialQuery,
    required this.child,
  });

  final String location;
  final String initialQuery;
  final Widget child;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WindowListener {
  bool _maximized = false;

  @override
  void initState() {
    super.initState();
    windowManager.addListener(this);
    windowManager.isMaximized().then((bool v) {
      if (mounted && v != _maximized) {
        setState(() => _maximized = v);
      }
    });
  }

  @override
  void dispose() {
    windowManager.removeListener(this);
    super.dispose();
  }

  @override
  void onWindowMaximize() => setState(() => _maximized = true);

  @override
  void onWindowUnmaximize() => setState(() => _maximized = false);

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final bool collapsed = constraints.maxWidth < 1120;
        return Scaffold(
          body: Stack(
            fit: StackFit.expand,
            children: [
              const AppBackground(),
              // ---- Acrylic window frame (.app-window) ----
              AnimatedPadding(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOut,
                padding: EdgeInsets.all(_maximized ? 0 : 14),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                      _maximized ? 0 : AppPalette.radiusWindow,
                    ),
                    boxShadow: _maximized ? null : palette.windowShadow,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                      _maximized ? 0 : AppPalette.radiusWindow,
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.compose(
                        outer: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                        inner: const ColorFilter.matrix(<double>[
                          1.8, 0, 0, 0, 0, //
                          0, 1.8, 0, 0, 0, //
                          0, 0, 1.8, 0, 0, //
                          0, 0, 0, 1, 0,
                        ]),
                      ),
                      child: Container(
                        color: palette.windowBg,
                        foregroundDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                            _maximized ? 0 : AppPalette.radiusWindow,
                          ),
                          border: Border.all(
                            color: palette.borderStrong,
                            width: 1,
                          ),
                        ),
                        child: Column(
                          children: [
                            CustomTitleBar(initialQuery: widget.initialQuery),
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  AppSidebar(
                                    location: widget.location,
                                    collapsed: collapsed,
                                  ),
                                  Expanded(
                                    child: AnimatedSwitcher(
                                      duration: const Duration(
                                        milliseconds: 220,
                                      ),
                                      switchInCurve: Curves.easeOut,
                                      switchOutCurve: Curves.easeIn,
                                      transitionBuilder:
                                          (Widget c, Animation<double> a) =>
                                              FadeTransition(
                                                opacity: a,
                                                child: c,
                                              ),
                                      child: KeyedSubtree(
                                        key: ValueKey<String>(widget.location),
                                        child: widget.child,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const ToastOverlay(),
            ],
          ),
        );
      },
    );
  }
}

/// Convenience helper used across screens to open the mirrors modal without
/// importing the widget tree of the modal directly.
Future<void> openGlassDialog(BuildContext context, WidgetBuilder builder) {
  final AppPalette palette = AppPalette(
    dark: Theme.of(context).brightness == Brightness.dark,
  );
  return showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Dialog',
    barrierColor: palette.modalScrim,
    transitionDuration: const Duration(milliseconds: 200),
    pageBuilder: (_, Animation<double> a, __) => FadeTransition(
      opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
      child: builder(context),
    ),
  );
}

/// Re-export so screens can build dialog bodies consistent with the shell.
typedef GlassDialogBody = GlassPanel;

extension RouterContextX on BuildContext {
  String get currentLocation =>
      GoRouter.of(this).routerDelegate.currentConfiguration.uri.path;
}
