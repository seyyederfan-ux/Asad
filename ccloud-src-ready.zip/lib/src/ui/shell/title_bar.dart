import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/theme_manager.dart';
import '../../services/toast_service.dart';

/// Custom frameless Windows titlebar — 1:1 with `.titlebar` (42px):
/// gradient brand mark (22×22, r6) + CCLOUD name + subtle PRO chip on the
/// left, the 28px global search centered, and a labelled theme toggle +
/// 32×26 window controls on the right. Whole bar drags; dbl-click maximizes.
class CustomTitleBar extends StatefulWidget {
  const CustomTitleBar({super.key, required this.initialQuery});

  final String initialQuery;

  @override
  State<CustomTitleBar> createState() => _CustomTitleBarState();
}

class _CustomTitleBarState extends State<CustomTitleBar> with WindowListener {
  late final TextEditingController _search;
  bool _maximized = false;

  @override
  void initState() {
    super.initState();
    _search = TextEditingController(text: widget.initialQuery);
    windowManager.addListener(this);
    windowManager.isMaximized().then((bool v) {
      if (mounted) {
        setState(() => _maximized = v);
      }
    });
  }

  @override
  void dispose() {
    windowManager.removeListener(this);
    _search.dispose();
    super.dispose();
  }

  @override
  void onWindowMaximize() => setState(() => _maximized = true);

  @override
  void onWindowUnmaximize() => setState(() => _maximized = false);

  void _submitSearch(String q) {
    final String query = q.trim();
    if (query.isEmpty) {
      return;
    }
    context.push('/search?q=${Uri.encodeComponent(query)}');
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final ThemeManager theme = context.watch<ThemeManager>();

    return Container(
      height: 42,
      color: palette.titlebarBg,
      child: DragToMoveArea(
        child: GestureDetector(
          onDoubleTap: () async {
            if (await windowManager.isMaximized()) {
              await windowManager.unmaximize();
            } else {
              await windowManager.maximize();
            }
          },
          child: Row(
            children: [
              const SizedBox(width: 16),

              // ---- Brand (.titlebar-brand) ----
              MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                  onTap: () => context.go('/home'),
                  child: Row(
                    children: [
                      Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          gradient: palette.modeAccentGradient,
                          borderRadius: BorderRadius.circular(6),
                          boxShadow: [
                            BoxShadow(
                              color: palette.glowColor,
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.asset(
                            'assets/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.play_arrow_rounded,
                              size: 13,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'CCLOUD',
                        style: TextStyle(
                          color: palette.textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(width: 6),
                      // .brand-tag — subtle chip
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: palette.cardHover,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: palette.border),
                        ),
                        child: Text(
                          'PRO',
                          style: TextStyle(
                            color: palette.accent,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(width: 24),

              // ---- Global search (.titlebar-search) ----
              Flexible(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: _GlobalSearchField(
                    controller: _search,
                    palette: palette,
                    onSubmit: _submitSearch,
                  ),
                ),
              ),

              const Spacer(),

              // ---- Theme toggle (.theme-toggle-btn) ----
              _ThemeToggleButton(theme: theme, palette: palette),
              const SizedBox(width: 8),

              // ---- Window controls (.win-action-btn 32×26 r5) ----
              _WindowButton(
                icon: Icons.minimize_rounded,
                palette: palette,
                onTap: () => windowManager.minimize(),
              ),
              _WindowButton(
                icon: _maximized
                    ? Icons.filter_none_rounded
                    : Icons.crop_square_rounded,
                iconSize: _maximized ? 12 : 13,
                palette: palette,
                onTap: () async {
                  if (await windowManager.isMaximized()) {
                    await windowManager.unmaximize();
                  } else {
                    await windowManager.maximize();
                  }
                },
              ),
              _WindowButton(
                icon: Icons.close_rounded,
                danger: true,
                palette: palette,
                onTap: () => windowManager.close(),
              ),
              const SizedBox(width: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class _GlobalSearchField extends StatefulWidget {
  const _GlobalSearchField({
    required this.controller,
    required this.palette,
    required this.onSubmit,
  });

  final TextEditingController controller;
  final AppPalette palette;
  final ValueChanged<String> onSubmit;

  @override
  State<_GlobalSearchField> createState() => _GlobalSearchFieldState();
}

class _GlobalSearchFieldState extends State<_GlobalSearchField> {
  bool _focus = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return Focus(
      onFocusChange: (bool v) => setState(() => _focus = v),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        height: 28,
        decoration: BoxDecoration(
          color: _focus ? palette.cardHover : palette.inputBg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: _focus ? palette.accent : palette.border,
            width: 1,
          ),
          boxShadow: _focus
              ? [
                  BoxShadow(
                    color: palette.glowColor.withValues(alpha: 0.9),
                    blurRadius: 0,
                    spreadRadius: 2,
                  ),
                ]
              : null,
        ),
        child: TextField(
          controller: widget.controller,
          textInputAction: TextInputAction.search,
          onSubmitted: widget.onSubmit,
          style: TextStyle(color: palette.textPrimary, fontSize: 12),
          cursorColor: palette.accent,
          decoration: InputDecoration(
            isDense: true,
            hintText: 'Search 4K movies, series, directors…',
            hintStyle: TextStyle(color: palette.textFaint, fontSize: 12),
            prefixIcon: Icon(
              Icons.search_rounded,
              size: 13,
              color: palette.textFaint,
            ),
            prefixIconConstraints: const BoxConstraints(minWidth: 34),
            suffixIcon: widget.controller.text.isEmpty
                ? null
                : GestureDetector(
                    onTap: () {
                      widget.controller.clear();
                      setState(() {});
                    },
                    child: Icon(
                      Icons.close_rounded,
                      size: 13,
                      color: palette.textFaint,
                    ),
                  ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 7),
          ),
          onChanged: (_) => setState(() {}),
        ),
      ),
    );
  }
}

class _ThemeToggleButton extends StatefulWidget {
  const _ThemeToggleButton({required this.theme, required this.palette});

  final ThemeManager theme;
  final AppPalette palette;

  @override
  State<_ThemeToggleButton> createState() => _ThemeToggleButtonState();
}

class _ThemeToggleButtonState extends State<_ThemeToggleButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    final bool dark = widget.theme.isDark;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: () async {
          await widget.theme.toggle();
          if (context.mounted) {
            context.read<ToastService>().show(
              widget.theme.isDark
                  ? 'Switched to Dark Acrylic Glass theme'
                  : 'Switched to Light Frosted Glass theme',
            );
          }
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          height: 26,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: _hover ? palette.cardHover : palette.card,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
              color: _hover ? palette.borderHover : palette.border,
            ),
          ),
          child: Row(
            children: [
              Icon(
                dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                size: 13,
                color: _hover ? palette.textPrimary : palette.textSecondary,
              ),
              const SizedBox(width: 6),
              Text(
                dark ? 'Light' : 'Dark',
                style: TextStyle(
                  color: _hover ? palette.textPrimary : palette.textSecondary,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WindowButton extends StatefulWidget {
  const _WindowButton({
    required this.icon,
    required this.palette,
    required this.onTap,
    this.danger = false,
    this.iconSize = 13,
  });

  final IconData icon;
  final AppPalette palette;
  final VoidCallback onTap;
  final bool danger;
  final double iconSize;

  @override
  State<_WindowButton> createState() => _WindowButtonState();
}

class _WindowButtonState extends State<_WindowButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 32,
          height: 26,
          decoration: BoxDecoration(
            color: widget.danger && _hover
                ? const Color(0xFFEF4444)
                : _hover
                ? palette.surfaceTint
                : Colors.transparent,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Icon(
            widget.icon,
            size: widget.iconSize,
            color: widget.danger && _hover
                ? Colors.white
                : _hover
                ? palette.textPrimary
                : palette.textSecondary,
          ),
        ),
      ),
    );
  }
}
