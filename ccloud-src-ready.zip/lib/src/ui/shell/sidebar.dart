import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../services/download_manager.dart';
import '../../services/download_task.dart';
import '../../services/favorites_service.dart';
import '../widgets/glass_panel.dart';

/// Smart navigation rail — 1:1 with `.app-sidebar` (236px, padding 18/12):
/// NAVIGATION group (Home · Movies 4K · Series · Favorites · Player) and
/// SYSTEM group (Settings · Live TV · Countries), a live download monitor
/// and the user chip. Collapses to icon-only below 1120px width.
class AppSidebar extends StatelessWidget {
  const AppSidebar({
    super.key,
    required this.location,
    required this.collapsed,
  });

  final String location;
  final bool collapsed;

  static const double expandedWidth = 236;
  static const double collapsedWidth = 76;

  void _go(BuildContext context, String route) {
    if (location != route) {
      context.go(route);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final FavoritesService favorites = context.watch<FavoritesService>();

    return Container(
      width: collapsed ? collapsedWidth : expandedWidth,
      color: palette.sidebarBg,
      child: Column(
        children: [
          const SizedBox(height: 6),

          // ---- NAVIGATION group (.nav-label) ----
          if (!collapsed)
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 8, 22, 4),
                child: Text(
                  'NAVIGATION',
                  style: TextStyle(
                    color: palette.textFaint,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.9,
                  ),
                ),
              ),
            ),
          if (collapsed) const SizedBox(height: 6),

          _NavItem(
            icon: Icons.home_rounded,
            label: 'Home',
            route: '/home',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/home'),
          ),
          _NavItem(
            icon: Icons.movie_creation_rounded,
            label: 'Movies',
            route: '/movies',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            badge: '4K',
            onTap: () => _go(context, '/movies'),
          ),
          _NavItem(
            icon: Icons.smart_display_rounded,
            label: 'Series',
            route: '/series',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/series'),
          ),
          _NavItem(
            icon: Icons.bookmark_rounded,
            label: 'Favorites',
            route: '/favorites',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            countBadge: favorites.count,
            onTap: () => _go(context, '/favorites'),
          ),
          _NavItem(
            icon: Icons.play_circle_outline_rounded,
            label: 'Player',
            route: '/player',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/player'),
          ),

          // ---- SYSTEM group (.sidebar-divider) ----
          if (!collapsed)
            Container(
              height: 1,
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              color: palette.border,
            )
          else
            const Divider(height: 14, indent: 18, endIndent: 18),
          if (!collapsed)
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 0, 22, 4),
                child: Text(
                  'SYSTEM',
                  style: TextStyle(
                    color: palette.textFaint,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.9,
                  ),
                ),
              ),
            ),
          _NavItem(
            icon: Icons.settings_rounded,
            label: 'Settings',
            route: '/settings',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/settings'),
          ),
          _NavItem(
            icon: Icons.satellite_alt_rounded,
            label: 'Live TV',
            route: '/livetv',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/livetv'),
          ),
          _NavItem(
            icon: Icons.public_rounded,
            label: 'Countries',
            route: '/countries',
            currentLocation: location,
            collapsed: collapsed,
            palette: palette,
            onTap: () => _go(context, '/countries'),
          ),

          const Spacer(),

          // Live download monitor (.mini-download-widget)
          if (!collapsed) const MiniDownloadWidget(),

          // User chip (.user-chip)
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 8),
            child: collapsed
                ? Center(
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        gradient: palette.modeAccentGradient,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: palette.glowColor, blurRadius: 10),
                        ],
                      ),
                      child: const Icon(
                        Icons.person_rounded,
                        size: 16,
                        color: Colors.white,
                      ),
                    ),
                  )
                : const _UserChip(),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatefulWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.route,
    required this.currentLocation,
    required this.collapsed,
    required this.palette,
    required this.onTap,
    this.badge,
    this.countBadge,
  });

  final IconData icon;
  final String label;
  final String route;
  final String currentLocation;
  final bool collapsed;
  final AppPalette palette;
  final VoidCallback onTap;
  final String? badge;
  final int? countBadge;

  @override
  State<_NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<_NavItem> {
  bool _hover = false;

  bool get _selected => widget.currentLocation == widget.route;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = widget.palette;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 1.5),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hover = true),
        onExit: (_) => setState(() => _hover = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOut,
            height: 36,
            padding: EdgeInsets.symmetric(
              horizontal: widget.collapsed ? 0 : 12,
            ),
            transform: Matrix4.translationValues(
              0,
              _hover && !_selected ? -1 : 0,
              0,
            ),
            decoration: BoxDecoration(
              gradient: _selected ? palette.modeAccentGradient : null,
              color: _selected
                  ? null
                  : _hover
                  ? palette.cardHover
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(9),
              boxShadow: _selected
                  ? [
                      BoxShadow(
                        color: palette.glowColor,
                        blurRadius: 16,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisAlignment: widget.collapsed
                  ? MainAxisAlignment.center
                  : MainAxisAlignment.start,
              children: [
                Icon(
                  widget.icon,
                  size: 17,
                  color: _selected
                      ? Colors.white
                      : _hover
                      ? palette.textPrimary
                      : palette.textSecondary,
                ),
                if (!widget.collapsed) ...[
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: _selected
                            ? Colors.white
                            : _hover
                            ? palette.textPrimary
                            : palette.textSecondary,
                        fontSize: 13,
                        fontWeight: _selected
                            ? FontWeight.w600
                            : FontWeight.w500,
                      ),
                    ),
                  ),
                  // .nav-badge-pill
                  if (widget.badge != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: _selected
                            ? Colors.white.withValues(alpha: 0.2)
                            : palette.card,
                        borderRadius: BorderRadius.circular(10),
                        border: _selected
                            ? null
                            : Border.all(color: palette.border),
                      ),
                      child: Text(
                        widget.badge!,
                        style: TextStyle(
                          color: _selected
                              ? Colors.white
                              : palette.textSecondary,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  if (widget.countBadge != null && widget.countBadge! > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: _selected
                            ? Colors.white.withValues(alpha: 0.2)
                            : palette.card,
                        borderRadius: BorderRadius.circular(10),
                        border: _selected
                            ? null
                            : Border.all(color: palette.border),
                      ),
                      child: Text(
                        '${widget.countBadge}',
                        style: TextStyle(
                          color: _selected
                              ? Colors.white
                              : palette.textSecondary,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Live mini monitor of the current download — 1:1 with
/// `.mini-download-widget` (r11, 4px gradient progress, size + MB/s stats).
class MiniDownloadWidget extends StatelessWidget {
  const MiniDownloadWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final DownloadManager manager = context.watch<DownloadManager>();
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    final DownloadTask? task = manager.activeTask;
    if (task == null) {
      return const SizedBox.shrink();
    }
    final bool downloading = task.status == DownloadStatus.downloading;

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 4, 10, 12),
      child: GestureDetector(
        onTap: () => context.go('/settings?tab=downloads'),
        child: MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GlassPanel(
            radius: 11,
            color: palette.card,
            blur: 12,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        task.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textPrimary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      '${(task.progress * 100).round()}%',
                      style: TextStyle(
                        color: palette.accent,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                // .widget-progress-bg — 4px
                ClipRRect(
                  borderRadius: BorderRadius.circular(2),
                  child: Stack(
                    children: [
                      Container(height: 4, color: palette.inputBg),
                      FractionallySizedBox(
                        widthFactor: task.progress.clamp(0.02, 1.0),
                        child: Container(
                          height: 4,
                          decoration: BoxDecoration(
                            gradient: palette.modeAccentGradient,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        task.totalBytes > 0
                            ? '${formatBytes(task.receivedBytes)} / ${formatBytes(task.totalBytes)}'
                            : formatBytes(task.receivedBytes),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: palette.textFaint,
                          fontSize: 10,
                        ),
                      ),
                    ),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Text(
                        downloading ? task.speedLabel : 'paused',
                        key: ValueKey<String>(
                          task.speedLabel + (downloading ? 'd' : 'p'),
                        ),
                        style: TextStyle(
                          color: downloading
                              ? AppPalette.success
                              : palette.textFaint,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// `.user-chip` — 28px gradient avatar, name (12 w600) and accent plan tag.
class _UserChip extends StatelessWidget {
  const _UserChip();

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette(
      dark: Theme.of(context).brightness == Brightness.dark,
    );
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: () => context.go('/settings?tab=about'),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  gradient: palette.modeAccentGradient,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: palette.glowColor, blurRadius: 8),
                  ],
                ),
                child: const Icon(
                  Icons.person_rounded,
                  size: 15,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Guest Viewer',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'PRO MEMBER',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: palette.accent,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
