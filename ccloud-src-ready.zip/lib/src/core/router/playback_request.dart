import '../../models/media_item.dart';

/// Payload passed to the immersive player route.
class PlaybackRequest {
  const PlaybackRequest({required this.media, this.source, this.episode});

  final MediaItem media;

  /// Pre-selected source/quality (mirrors modal / episode play).
  final Source? source;

  /// Set when playing a specific series episode.
  final Episode? episode;

  List<Source> get sources => episode?.sources ?? media.sources;

  /// Picks the first source matching [preferred] hint (e.g. '1080p'),
  /// otherwise the highest entry.
  Source? bestSource(String preferred) {
    final List<Source> list = sources;
    if (list.isEmpty) {
      return null;
    }
    if (source != null) {
      return source;
    }
    final String p = preferred.toLowerCase();
    for (final Source s in list) {
      if (s.quality.toLowerCase().contains(p)) {
        return s;
      }
    }
    for (final Source s in list) {
      if (s.quality.toLowerCase().contains('1080')) {
        return s;
      }
    }
    return list.first;
  }
}
