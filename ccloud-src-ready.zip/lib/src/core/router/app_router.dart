import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../models/media_item.dart';
import '../../ui/screens/countries_screen.dart';
import '../../ui/screens/favorites_screen.dart';
import '../../ui/screens/home_screen.dart';
import '../../ui/screens/livetv_screen.dart';
import '../../ui/screens/media_detail_screen.dart';
import '../../ui/screens/media_grid_screen.dart';
import '../../ui/screens/player_screen.dart';
import '../../ui/screens/search_screen.dart';
import '../../ui/screens/settings_screen.dart';
import '../../ui/shell/app_shell.dart';
import 'playback_request.dart';

/// App-wide navigation graph.
///
/// The persistent glass shell (titlebar + sidebar) hosts every browse screen;
/// the media detail view and the immersive player are top-level routes so
/// they take the full window.
final GoRouter appRouter = GoRouter(
  initialLocation: '/home',
  routes: <RouteBase>[
    ShellRoute(
      builder: (BuildContext context, GoRouterState state, Widget child) =>
          AppShell(
            location: state.uri.path,
            initialQuery: state.uri.queryParameters['q'] ?? '',
            child: child,
          ),
      routes: <RouteBase>[
        GoRoute(path: '/', redirect: (_, __) => '/home'),
        GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
        GoRoute(
          path: '/movies',
          builder: (_, __) => const MediaGridScreen(kind: MediaKind.movies),
        ),
        GoRoute(
          path: '/series',
          builder: (_, __) => const MediaGridScreen(kind: MediaKind.series),
        ),
        GoRoute(
          path: '/favorites',
          builder: (_, __) => const FavoritesScreen(),
        ),
        GoRoute(
          path: '/search',
          builder: (_, GoRouterState state) =>
              SearchScreen(query: state.uri.queryParameters['q'] ?? ''),
        ),
        GoRoute(path: '/livetv', builder: (_, __) => const LiveTvScreen()),
        GoRoute(
          path: '/countries',
          builder: (_, __) => const CountriesScreen(),
        ),
        GoRoute(
          path: '/settings',
          builder: (_, GoRouterState state) => SettingsScreen(
            initialTab: state.uri.queryParameters['tab'] ?? 'general',
          ),
        ),
      ],
    ),
    GoRoute(
      path: '/detail',
      builder: (BuildContext context, GoRouterState state) {
        final Object? extra = state.extra;
        if (extra is MediaItem) {
          return MediaDetailScreen(item: extra);
        }
        return const MediaDetailScreen(item: null);
      },
    ),
    GoRoute(
      path: '/player',
      builder: (BuildContext context, GoRouterState state) {
        final Object? extra = state.extra;
        if (extra is PlaybackRequest) {
          return PlayerScreen(request: extra);
        }
        return const PlayerScreen();
      },
    ),
  ],
);
