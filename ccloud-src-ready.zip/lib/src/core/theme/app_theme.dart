import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Central typography + component theming for CCloud PRO.
///
/// Latin text uses the bundled `PlusJakartaSans`; Persian glyph runs fall
/// back to the bundled `Vazirmatn` through [TextTheme] fallbacks so mixed
/// catalog titles render correctly in either direction.
class AppTheme {
  AppTheme._();

  static const String latinFamily = 'PlusJakartaSans';
  static const List<String> fallbackFamilies = ['Vazirmatn'];

  static TextTheme _buildTextTheme(Brightness brightness) {
    final Color primary = brightness == Brightness.dark
        ? AppPalette.darkTextPrimary
        : AppPalette.lightTextPrimary;
    final Color secondary = brightness == Brightness.dark
        ? AppPalette.darkTextSecondary
        : AppPalette.lightTextSecondary;

    final TextTheme base = brightness == Brightness.dark
        ? ThemeData.dark().textTheme
        : ThemeData.light().textTheme;

    return base
        .copyWith(
          displaySmall: TextStyle(
            fontSize: 34,
            height: 1.15,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
            color: primary,
          ),
          headlineMedium: TextStyle(
            fontSize: 24,
            height: 1.2,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
            color: primary,
          ),
          titleLarge: TextStyle(
            fontSize: 18,
            height: 1.25,
            fontWeight: FontWeight.w700,
            color: primary,
          ),
          titleMedium: TextStyle(
            fontSize: 15.5,
            height: 1.3,
            fontWeight: FontWeight.w600,
            color: primary,
          ),
          bodyLarge: TextStyle(
            fontSize: 14.5,
            height: 1.5,
            fontWeight: FontWeight.w400,
            color: primary,
          ),
          bodyMedium: TextStyle(
            fontSize: 13.5,
            height: 1.5,
            fontWeight: FontWeight.w400,
            color: secondary,
          ),
          bodySmall: TextStyle(
            fontSize: 12,
            height: 1.45,
            fontWeight: FontWeight.w400,
            color: secondary,
          ),
          labelLarge: TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.1,
            color: primary,
          ),
          labelMedium: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: secondary,
          ),
          labelSmall: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
            color: secondary,
          ),
        )
        .apply(fontFamily: latinFamily, fontFamilyFallback: fallbackFamilies);
  }

  static ThemeData light() => _build(Brightness.light);

  static ThemeData dark() => _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final bool dark = brightness == Brightness.dark;
    final AppPalette palette = AppPalette(dark: dark);
    final TextTheme textTheme = _buildTextTheme(brightness);

    final ColorScheme scheme = ColorScheme(
      brightness: brightness,
      primary: AppPalette.accentStart,
      onPrimary: Colors.white,
      secondary: AppPalette.accentEnd,
      onSecondary: Colors.white,
      error: AppPalette.danger,
      onError: Colors.white,
      surface: palette.panel,
      onSurface: palette.textPrimary,
      surfaceContainerHighest: palette.panelStrong,
      onSurfaceVariant: palette.textSecondary,
      outline: palette.border,
      outlineVariant: palette.hairline,
      primaryContainer: AppPalette.glow,
      onPrimaryContainer: palette.textPrimary,
      tertiary: AppPalette.bookmark,
      onTertiary: Colors.white,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      fontFamily: latinFamily,
      scaffoldBackgroundColor: Colors.transparent,
      canvasColor: Colors.transparent,
      splashFactory: NoSplash.splashFactory,
      colorScheme: scheme,
      textTheme: textTheme,
      visualDensity: VisualDensity.comfortable,
      scrollbarTheme: ScrollbarThemeData(
        thickness: WidgetStateProperty.all(6),
        radius: const Radius.circular(999),
        thumbColor: WidgetStateProperty.all(
          dark ? const Color(0x33FFFFFF) : const Color(0x33101828),
        ),
        trackBorderColor: WidgetStateProperty.all(Colors.transparent),
        trackColor: WidgetStateProperty.all(Colors.transparent),
      ),
      sliderTheme: SliderThemeData(
        trackHeight: 4,
        overlayShape: SliderComponentShape.noOverlay,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
        activeTrackColor: AppPalette.accentStart,
        inactiveTrackColor: dark
            ? const Color(0x2EFFFFFF)
            : const Color(0x2E101828),
        thumbColor: Colors.white,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: textTheme.bodyMedium,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: palette.panelStrong,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: palette.border),
        ),
        textStyle: textTheme.labelSmall?.copyWith(color: palette.textPrimary),
        waitDuration: const Duration(milliseconds: 450),
      ),
      dividerTheme: DividerThemeData(
        color: palette.hairline,
        thickness: 1,
        space: 1,
      ),
      hoverColor: dark ? const Color(0x0AFFFFFF) : const Color(0x0A101828),
      focusColor: AppPalette.glow,
      iconTheme: IconThemeData(color: palette.textPrimary, size: 20),
    );
  }
}
