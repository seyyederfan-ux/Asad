import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_colors.dart';
import 'app_theme.dart';

enum AppThemeMode { system, light, dark }

/// Persists the selected theme mode and exposes the resolved semantic
/// [AppPalette] for the glass design system.
class ThemeManager extends ChangeNotifier {
  static const String _themeKey = 'app_theme';

  AppThemeMode _mode = AppThemeMode.system;

  AppThemeMode get mode => _mode;

  ThemeManager() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _mode = _parse(prefs.getString(_themeKey) ?? '');
    notifyListeners();
  }

  AppThemeMode _parse(String value) {
    switch (value) {
      case 'light':
        return AppThemeMode.light;
      case 'dark':
        return AppThemeMode.dark;
      default:
        return AppThemeMode.system;
    }
  }

  Future<void> setMode(AppThemeMode mode) async {
    _mode = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeKey, mode.name);
    notifyListeners();
  }

  /// Toggles between explicit dark and light (titlebar switch).
  Future<void> toggle() async {
    await setMode(isDark ? AppThemeMode.light : AppThemeMode.dark);
  }

  Brightness get platformBrightness =>
      WidgetsBinding.instance.platformDispatcher.platformBrightness;

  bool get isDark {
    switch (_mode) {
      case AppThemeMode.light:
        return false;
      case AppThemeMode.dark:
        return true;
      case AppThemeMode.system:
        return platformBrightness == Brightness.dark;
    }
  }

  ThemeMode get themeMode {
    switch (_mode) {
      case AppThemeMode.light:
        return ThemeMode.light;
      case AppThemeMode.dark:
        return ThemeMode.dark;
      case AppThemeMode.system:
        return ThemeMode.system;
    }
  }

  AppPalette get palette => AppPalette(dark: isDark);

  ThemeData get themeData => isDark ? AppTheme.dark() : AppTheme.light();
}
