import 'package:flutter/material.dart';

/// Semantic palette for the CCloud PRO Fluent 2 / Acrylic design language.
///
/// Every token mirrors the reference prototype `cinemax_windows_app.html`
/// (1:1 calibration pass):
/// ```
/// :root[data-theme="dark"]  --bg #07080c   --accent #8b5cf6
///                           --accent-gradient #7c3aed -> #4f46e5
///                           --card rgba(255,255,255,.035)
///                           --glass-panel rgba(19,22,34,.6)
///                           --glass-elevated rgba(24,27,41,.82)
/// :root[data-theme="light"] --bg #edf1f6   --accent #6d28d9
///                           --accent-gradient #6d28d9 -> #4338ca
///                           --card rgba(255,255,255,.62)
///                           --glass-panel rgba(255,255,255,.68)
///                           --glass-elevated rgba(255,255,255,.92)
/// ```
class AppPalette {
  const AppPalette({required this.dark});

  final bool dark;

  // ---------------------------------------------------------------- brand
  /// `--accent` — flat accent used for links, active labels, switches.
  static const Color accentStart = Color(0xFF7C3AED);
  static const Color accentEnd = Color(0xFF4F46E5);
  static const Color accentDark = Color(0xFF8B5CF6); // dark  --accent
  static const Color accentDarkHover = Color(0xFF9F75FF);
  static const Color accentLight = Color(0xFF6D28D9); // light --accent
  static const Color accentLightHover = Color(0xFF5B21B6);

  /// Static (dark-mode) gradient kept for const call sites.
  static const Color glow = Color(0x598B5CF6); // rgba(139,92,246,0.35)
  static const Color glowLight = Color(0x406D28D9); // rgba(109,40,217,0.25)

  static const Color bookmark = Color(0xFFEF4444); // dark  --fav-active
  static const Color bookmarkLight = Color(0xFFE11D48); // light variant

  static const LinearGradient accentGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accentStart, accentEnd],
  );

  static const LinearGradient lightAccentGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accentLight, Color(0xFF4338CA)],
  );

  static const LinearGradient glowGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0x668B5CF6), Color(0x334F46E5)],
  );

  // ------------------------------------------------------- per-mode accent
  Color get accent => dark ? accentDark : accentLight;
  Color get accentHover => dark ? accentDarkHover : accentLightHover;
  Color get favActive => dark ? bookmark : bookmarkLight;
  Color get glowColor => dark ? glow : glowLight;
  LinearGradient get modeAccentGradient =>
      dark ? accentGradient : lightAccentGradient;

  // ------------------------------------------------------------ dark acrylic
  static const Color darkBackground = Color(0xFF07080C);
  static const Color darkWindowBg = Color(0xBD0C0E15); // rgba(12,14,21,0.74)
  static const Color darkTitlebarBg = Color(0x990C0E15); // rgba(12,14,21,0.6)
  static const Color darkSidebarBg = Color(0x8011131D); // rgba(17,19,29,0.5)
  static const Color darkCard = Color(0x09FFFFFF); // white @ 0.035
  static const Color darkCardHover = Color(0x13FFFFFF); // white @ 0.075
  static const Color darkGlassPanel = Color(0x99131622); // rgba(19,22,34,0.6)
  static const Color darkGlassElevated = Color(
    0xD1181B29,
  ); // rgba(24,27,41,0.82)
  static const Color darkPanel = darkWindowBg;
  static const Color darkPanelStrong = darkGlassElevated;
  static const Color darkPanelSoft = Color(0x590C0E15);

  static const Color darkBorder = Color(0x14FFFFFF); // white @ 0.08
  static const Color darkBorderHover = Color(0x38FFFFFF); // white @ 0.22
  static const Color darkBorderStrong = Color(0x26FFFFFF); // white @ 0.15
  static const Color darkTextPrimary = Color(0xFFF8FAFC); // --text-main
  static const Color darkTextSecondary = Color(0xFF94A3B8); // --text-muted
  static const Color darkTextFaint = Color(0xFF64748B); // --text-faint
  static const Color darkHairline = Color(0x0FFFFFFF);

  // ----------------------------------------------------------- light frosted
  static const Color lightBackground = Color(0xFFEDF1F6);
  static const Color lightWindowBg = Color(0xBDFFFFFF); // white @ 0.74
  static const Color lightTitlebarBg = Color(0x9EFFFFFF); // white @ 0.62
  static const Color lightSidebarBg = Color(
    0x94F5F7FC,
  ); // rgba(245,247,252,.58)
  static const Color lightCard = Color(0x9EFFFFFF); // white @ 0.62
  static const Color lightCardHover = Color(0xF5FFFFFF); // white @ 0.96
  static const Color lightGlassPanel = Color(0xADFFFFFF); // white @ 0.68
  static const Color lightGlassElevated = Color(0xE6FFFFFF); // white @ 0.92
  static const Color lightPanel = lightWindowBg;
  static const Color lightPanelStrong = lightGlassElevated;
  static const Color lightPanelSoft = Color(0x8CFFFFFF);

  static const Color lightBorder = Color(0x12000000); // black @ 0.07
  static const Color lightBorderHover = Color(0x2E000000); // black @ 0.18
  static const Color lightBorderStrong = Color(0x1F000000); // black @ 0.12
  static const Color lightTextPrimary = Color(0xFF0F172A); // --text-main
  static const Color lightTextSecondary = Color(0xFF475569); // --text-muted
  static const Color lightTextFaint = Color(0xFF94A3B8); // --text-faint
  static const Color lightHairline = Color(0x0A0F172A);

  // ------------------------------------------------------------ status hues
  static const Color success = Color(0xFF34D399);
  static const Color warning = Color(0xFFFBBF24);
  static const Color danger = Color(0xFFF87171);
  static const Color infoSky = Color(0xFF38BDF8); // card-corner-badge color

  // --------------------------------------------------------------- scrims
  /// `--modal-scrim`
  Color get modalScrim =>
      dark ? const Color(0xAD020307) : const Color(0x610F172A);

  /// `--input-bg`
  Color get inputBg => dark
      ? const Color(0x0AFFFFFF) // white @ 0.04
      : const Color(0x0A000000); // black @ 0.04

  /// `--sub-bg` — on-video subtitle plate.
  Color get subtitlePlate =>
      dark ? const Color(0xB8000000) : const Color(0xD10F172A);

  // ------------------------------------------------------------- radii scale
  static const double radiusCard = 16; // hero / lead cards / modal / panes
  static const double radiusCardSmall = 12; // media-card / continue-card
  static const double radiusButton = 9; // primary / ghost buttons
  static const double radiusWindow = 18; // .app-window
  static const double radiusPill = 999;

  // --------------------------------------------------------------- accessors
  Color get background => dark ? darkBackground : lightBackground;
  Color get windowBg => dark ? darkWindowBg : lightWindowBg;
  Color get titlebarBg => dark ? darkTitlebarBg : lightTitlebarBg;
  Color get sidebarBg => dark ? darkSidebarBg : lightSidebarBg;
  Color get card => dark ? darkCard : lightCard;
  Color get cardHover => dark ? darkCardHover : lightCardHover;
  Color get glassPanel => dark ? darkGlassPanel : lightGlassPanel;
  Color get glassElevated => dark ? darkGlassElevated : lightGlassElevated;
  Color get panel => dark ? darkPanel : lightPanel;
  Color get panelStrong => dark ? darkPanelStrong : lightPanelStrong;
  Color get panelSoft => dark ? darkPanelSoft : lightPanelSoft;
  Color get border => dark ? darkBorder : lightBorder;
  Color get borderHover => dark ? darkBorderHover : lightBorderHover;
  Color get borderStrong => dark ? darkBorderStrong : lightBorderStrong;
  Color get hairline => dark ? darkHairline : lightHairline;
  Color get textPrimary => dark ? darkTextPrimary : lightTextPrimary;
  Color get textSecondary => dark ? darkTextSecondary : lightTextSecondary;
  Color get textFaint => dark ? darkTextFaint : lightTextFaint;

  Color get scrimTop =>
      dark ? const Color(0xB3020409) : const Color(0x990B1220);
  Color get surfaceTint =>
      dark ? const Color(0x66101423) : const Color(0x66FFFFFF);

  /// Ambient backdrop — `--bg-ambient`: violet nebula top-right (85% 15%),
  /// blue nebula bottom-left (15% 85%).
  List<RadialGradient> get ambientGradients => dark
      ? const [
          RadialGradient(
            center: Alignment(0.7, -0.7), // 85% 15%
            radius: 1.35,
            colors: [Color(0x387C3AED), Color(0x007C3AED)], // 0.22 alpha
          ),
          RadialGradient(
            center: Alignment(-0.7, 0.7), // 15% 85%
            radius: 1.3,
            colors: [Color(0x263B82F6), Color(0x003B82F6)], // 0.15 alpha
          ),
        ]
      : const [
          RadialGradient(
            center: Alignment(0.7, -0.7),
            radius: 1.35,
            colors: [Color(0x47A789FA), Color(0x00A789FA)], // 0.28 alpha
          ),
          RadialGradient(
            center: Alignment(-0.7, 0.7),
            radius: 1.3,
            colors: [Color(0x5293C5FD), Color(0x0093C5FD)], // 0.32 alpha
          ),
        ];

  /// Border for glass surfaces: thin translucent hairline.
  BorderSide get glassBorder => BorderSide(color: border, width: 1);

  BoxBorder get glassBoxBorder => Border.all(color: border, width: 1);

  /// `--shadow-ambient` window drop; cards use the HTML 0 12 28 black@20%.
  List<BoxShadow> get windowShadow => dark
      ? const [
          BoxShadow(
            color: Color(0xD9000000),
            blurRadius: 75,
            offset: Offset(0, 32),
          ),
        ]
      : const [
          BoxShadow(
            color: Color(0x2E0F172A),
            blurRadius: 60,
            offset: Offset(0, 25),
          ),
        ];

  List<BoxShadow> get panelShadow => dark
      ? const [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 24,
            offset: Offset(0, 8),
          ),
        ]
      : const [
          BoxShadow(
            color: Color(0x14101828),
            blurRadius: 24,
            offset: Offset(0, 8),
          ),
        ];

  /// `.media-card:hover` shadow — 0 12px 28px rgba(0,0,0,0.2).
  List<BoxShadow> get cardHoverShadow => const [
    BoxShadow(color: Color(0x33000000), blurRadius: 28, offset: Offset(0, 12)),
  ];
}
