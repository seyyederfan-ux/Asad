import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ProxyMode { direct, system, socks5 }

enum SubtitleSize { small, medium, large }

enum PreferredPlayer { internal, vlc }

/// Persisted application settings (General, Playback, Downloads, Network).
///
/// Every mutation writes through to [SharedPreferences] and notifies the UI
/// so glass panels react live (e.g. the subtitle flyout size buttons).
class SettingsService extends ChangeNotifier {
  static const String _kDownloadDir = 'settings_download_dir';
  static const String _kMaxConnections = 'settings_max_connections';
  static const String _kAutoStart = 'settings_autostart_downloads';
  static const String _kGpuAccel = 'settings_gpu_hw_accel';
  static const String _kPreferredQuality = 'settings_preferred_quality';
  static const String _kSubtitlesEnabled = 'settings_subtitles_enabled';
  static const String _kSubtitleSize = 'settings_subtitle_size';
  static const String _kSubtitleOffset = 'settings_subtitle_offset';
  static const String _kProxyMode = 'settings_proxy_mode';
  static const String _kSocksHost = 'settings_socks_host';
  static const String _kSocksPort = 'settings_socks_port';
  static const String _kDefaultPlayer = 'settings_default_player';

  String? _downloadDir;
  int _maxConnections = 3;
  bool _autoStartDownloads = true;
  bool _gpuHardwareAcceleration = true;
  String _preferredQuality = 'auto';
  bool _subtitlesEnabled = true;
  SubtitleSize _subtitleSize = SubtitleSize.medium;
  double _subtitleOffsetSeconds = 0;
  ProxyMode _proxyMode = ProxyMode.direct;
  String _socksHost = '127.0.0.1';
  int _socksPort = 10808;
  PreferredPlayer _defaultPlayer = PreferredPlayer.internal;

  bool _loaded = false;

  String? get downloadDir => _downloadDir;
  int get maxConnections => _maxConnections;
  bool get autoStartDownloads => _autoStartDownloads;
  bool get gpuHardwareAcceleration => _gpuHardwareAcceleration;
  String get preferredQuality => _preferredQuality;
  bool get subtitlesEnabled => _subtitlesEnabled;
  SubtitleSize get subtitleSize => _subtitleSize;
  double get subtitleOffsetSeconds => _subtitleOffsetSeconds;
  ProxyMode get proxyMode => _proxyMode;
  String get socksHost => _socksHost;
  int get socksPort => _socksPort;
  PreferredPlayer get defaultPlayer => _defaultPlayer;
  bool get loaded => _loaded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _downloadDir = prefs.getString(_kDownloadDir);
    _maxConnections = prefs.getInt(_kMaxConnections) ?? 3;
    _autoStartDownloads = prefs.getBool(_kAutoStart) ?? true;
    _gpuHardwareAcceleration = prefs.getBool(_kGpuAccel) ?? true;
    _preferredQuality = prefs.getString(_kPreferredQuality) ?? 'auto';
    _subtitlesEnabled = prefs.getBool(_kSubtitlesEnabled) ?? true;
    _subtitleSize =
        SubtitleSize.values.asMap()[prefs.getInt(_kSubtitleSize) ?? 1] ??
        SubtitleSize.medium;
    _subtitleOffsetSeconds = prefs.getDouble(_kSubtitleOffset) ?? 0;
    _proxyMode =
        ProxyMode.values.asMap()[prefs.getInt(_kProxyMode) ?? 0] ??
        ProxyMode.direct;
    _socksHost = prefs.getString(_kSocksHost) ?? '127.0.0.1';
    _socksPort = prefs.getInt(_kSocksPort) ?? 10808;
    _defaultPlayer =
        PreferredPlayer.values.asMap()[prefs.getInt(_kDefaultPlayer) ?? 0] ??
        PreferredPlayer.internal;
    _loaded = true;
    notifyListeners();
  }

  Future<void> setDownloadDir(String? value) async {
    _downloadDir = value;
    final prefs = await SharedPreferences.getInstance();
    if (value == null) {
      await prefs.remove(_kDownloadDir);
    } else {
      await prefs.setString(_kDownloadDir, value);
    }
    notifyListeners();
  }

  Future<void> setMaxConnections(int value) async {
    _maxConnections = value.clamp(1, 8);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kMaxConnections, _maxConnections);
    notifyListeners();
  }

  Future<void> setAutoStartDownloads(bool value) async {
    _autoStartDownloads = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAutoStart, value);
    notifyListeners();
  }

  Future<void> setGpuHardwareAcceleration(bool value) async {
    _gpuHardwareAcceleration = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kGpuAccel, value);
    notifyListeners();
  }

  Future<void> setPreferredQuality(String value) async {
    _preferredQuality = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kPreferredQuality, value);
    notifyListeners();
  }

  Future<void> setSubtitlesEnabled(bool value) async {
    _subtitlesEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSubtitlesEnabled, value);
    notifyListeners();
  }

  Future<void> setSubtitleSize(SubtitleSize value) async {
    _subtitleSize = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kSubtitleSize, value.index);
    notifyListeners();
  }

  Future<void> setSubtitleOffsetSeconds(double value) async {
    _subtitleOffsetSeconds = value.clamp(-30, 30).toDouble();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kSubtitleOffset, _subtitleOffsetSeconds);
    notifyListeners();
  }

  Future<void> setProxyMode(ProxyMode value) async {
    _proxyMode = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kProxyMode, value.index);
    notifyListeners();
  }

  Future<void> setSocksHost(String value) async {
    _socksHost = value.trim().isEmpty ? '127.0.0.1' : value.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kSocksHost, _socksHost);
    notifyListeners();
  }

  Future<void> setSocksPort(int value) async {
    _socksPort = value.clamp(1, 65535);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kSocksPort, _socksPort);
    notifyListeners();
  }

  Future<void> setDefaultPlayer(PreferredPlayer value) async {
    _defaultPlayer = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kDefaultPlayer, value.index);
    notifyListeners();
  }
}
