import 'package:flutter/foundation.dart';

import '../models/media_item.dart';
import '../utils/storage_utils.dart';

enum FavoritesFilter { all, movies, series }

/// Reactive wrapper around the preserved file-based favorites store.
///
/// The sidebar badge, favorites grid and card bookmark buttons all listen to
/// this ChangeNotifier so a single tap updates every surface at once.
class FavoritesService extends ChangeNotifier {
  List<MediaItemWithTimestamp> _items = <MediaItemWithTimestamp>[];
  bool _loaded = false;

  List<MediaItemWithTimestamp> get items =>
      List<MediaItemWithTimestamp>.unmodifiable(_items);

  bool get loaded => _loaded;

  int get count => _items.length;

  List<MediaItemWithTimestamp> filtered(FavoritesFilter filter) {
    switch (filter) {
      case FavoritesFilter.all:
        return items;
      case FavoritesFilter.movies:
        return items
            .where((MediaItemWithTimestamp e) => e.mediaItem.isMovie())
            .toList();
      case FavoritesFilter.series:
        return items
            .where((MediaItemWithTimestamp e) => e.mediaItem.isSeries())
            .toList();
    }
  }

  Future<void> load() async {
    _items = await StorageUtils.loadFavoritesWithTimestamp();
    _loaded = true;
    notifyListeners();
  }

  Future<bool> isFavorite(MediaItem item) async {
    for (final MediaItemWithTimestamp e in _items) {
      if (e.mediaItem.id == item.id && e.mediaItem.type == item.type) {
        return true;
      }
    }
    return StorageUtils.isFavorite(item.id, item.type);
  }

  bool containsSync(MediaItem item) {
    return _items.any(
      (MediaItemWithTimestamp e) =>
          e.mediaItem.id == item.id && e.mediaItem.type == item.type,
    );
  }

  /// Adds or removes; returns the resulting favorite state.
  Future<bool> toggle(MediaItem item) async {
    final bool wasFavorite = containsSync(item);
    if (wasFavorite) {
      await StorageUtils.removeFromFavorites(item.id, item.type);
    } else {
      await StorageUtils.addToFavorites(item);
    }
    _items = await StorageUtils.loadFavoritesWithTimestamp();
    notifyListeners();
    return !wasFavorite;
  }

  Future<void> remove(MediaItem item) async {
    await StorageUtils.removeFromFavorites(item.id, item.type);
    _items = await StorageUtils.loadFavoritesWithTimestamp();
    notifyListeners();
  }

  Future<void> clearAll() async {
    await StorageUtils.clearAllFavorites();
    _items = <MediaItemWithTimestamp>[];
    notifyListeners();
  }
}
