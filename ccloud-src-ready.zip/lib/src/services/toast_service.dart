import 'dart:async';

import 'package:flutter/material.dart';

enum ToastType { success, info, warning, error }

/// A single glass toast entry shown in the bottom-right neon-bordered stack.
class ToastMessage {
  const ToastMessage({
    required this.id,
    required this.message,
    this.type = ToastType.info,
  });

  final String id;
  final String message;
  final ToastType type;
}

/// Global toast feedback bus. Every user action in the app (copy link,
/// theme switch, subtitle status, download events...) routes a short lived
/// message through [show].
class ToastService extends ChangeNotifier {
  final List<ToastMessage> _items = <ToastMessage>[];
  final Map<String, Timer> _timers = <String, Timer>{};
  int _seq = 0;

  static const Duration _defaultDuration = Duration(milliseconds: 2600);

  List<ToastMessage> get items => List<ToastMessage>.unmodifiable(_items);

  void show(String message, {ToastType type = ToastType.info}) {
    final String id =
        'toast-${DateTime.now().microsecondsSinceEpoch}-${_seq++}';
    _items.add(ToastMessage(id: id, message: message, type: type));
    while (_items.length > 4) {
      final String droppedId = _items.removeAt(0).id;
      _timers[droppedId]?.cancel();
      _timers.remove(droppedId);
    }
    _timers[id] = Timer(_defaultDuration, () => dismiss(id));
    notifyListeners();
  }

  void success(String message) => show(message, type: ToastType.success);

  void info(String message) => show(message, type: ToastType.info);

  void error(String message) => show(message, type: ToastType.error);

  void warning(String message) => show(message, type: ToastType.warning);

  void dismiss(String id) {
    _timers[id]?.cancel();
    _timers.remove(id);
    _items.removeWhere((ToastMessage t) => t.id == id);
    notifyListeners();
  }
}
