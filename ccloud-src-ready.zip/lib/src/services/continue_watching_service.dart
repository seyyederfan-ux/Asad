import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../models/media_item.dart';

/// One persisted "continue watching" entry.
class WatchProgress {
  const WatchProgress({
    required this.mediaId,
    required this.mediaType,
    required this.title,
    required this.image,
    required this.cover,
    required this.positionMs,
    required this.durationMs,
    required this.updatedAt,
  });

  final int mediaId;
  final String mediaType;
  final String title;
  final String image;
  final String cover;
  final int positionMs;
  final int durationMs;
  final int updatedAt;

  double get progress {
    if (durationMs <= 0) {
      return 0;
    }
    return (positionMs / durationMs).clamp(0.0, 1.0);
  }

  Duration get remaining {
    final int ms = durationMs - positionMs;
    return Duration(milliseconds: ms < 0 ? 0 : ms);
  }

  bool get isFinished => durationMs > 0 && positionMs >= durationMs * 0.97;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'mediaId': mediaId,
    'mediaType': mediaType,
    'title': title,
    'image': image,
    'cover': cover,
    'positionMs': positionMs,
    'durationMs': durationMs,
    'updatedAt': updatedAt,
  };

  static WatchProgress fromJson(Map<String, dynamic> json) => WatchProgress(
    mediaId: json['mediaId'] as int? ?? 0,
    mediaType: json['mediaType'] as String? ?? 'movie',
    title: json['title'] as String? ?? '',
    image: json['image'] as String? ?? '',
    cover: json['cover'] as String? ?? '',
    positionMs: json['positionMs'] as int? ?? 0,
    durationMs: json['durationMs'] as int? ?? 0,
    updatedAt: json['updatedAt'] as int? ?? 0,
  );

  String get key => '$mediaType-$mediaId';
}

/// Persists playback positions so the Home "Continue Watching" shelf can
/// resume titles exactly where the user left off.
class ContinueWatchingService extends ChangeNotifier {
  static const String _fileName = 'ccloud_watch_progress.json';

  final Map<String, WatchProgress> _entries = <String, WatchProgress>{};
  bool _loaded = false;

  bool get loaded => _loaded;

  List<WatchProgress> get entries {
    final List<WatchProgress> list = _entries.values.toList();
    list.sort(
      (WatchProgress a, WatchProgress b) => b.updatedAt.compareTo(a.updatedAt),
    );
    return list;
  }

  WatchProgress? forKey(String key) => _entries[key];

  String keyFor(MediaItem item) => '${item.type}-${item.id}';

  Future<File> _file() async {
    final Directory dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<void> load() async {
    try {
      final File f = await _file();
      if (await f.exists()) {
        final dynamic decoded = jsonDecode(await f.readAsString());
        if (decoded is List) {
          for (final dynamic e in decoded) {
            if (e is Map<String, dynamic>) {
              final WatchProgress p = WatchProgress.fromJson(e);
              _entries[p.key] = p;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('ContinueWatchingService.load error: $e');
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    try {
      final File f = await _file();
      await f.writeAsString(
        jsonEncode(
          _entries.values.map((WatchProgress e) => e.toJson()).toList(),
        ),
      );
    } catch (e) {
      debugPrint('ContinueWatchingService.persist error: $e');
    }
  }

  Future<void> upsert(
    MediaItem media, {
    required Duration position,
    required Duration duration,
  }) async {
    if (duration.inMilliseconds <= 0) {
      return;
    }
    _entries[keyFor(media)] = WatchProgress(
      mediaId: media.id,
      mediaType: media.type,
      title: media.title,
      image: media.image,
      cover: media.cover,
      positionMs: position.inMilliseconds,
      durationMs: duration.inMilliseconds,
      updatedAt: DateTime.now().millisecondsSinceEpoch,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> remove(String key) async {
    _entries.remove(key);
    await _persist();
    notifyListeners();
  }

  Future<void> clear() async {
    _entries.clear();
    await _persist();
    notifyListeners();
  }
}
