import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'download_task.dart';

class _Probe {
  const _Probe(this.totalBytes, this.acceptRanges);
  final int totalBytes;
  final bool acceptRanges;
}

class _PausedSignal {}

class _CancelledSignal {}

/// Real in-app download engine.
///
/// * Probes the CDN with HEAD (falls back to a 1-byte range GET) to learn the
///   total size and whether byte ranges are supported.
/// * Downloads in up to N parallel byte-range chunks (N = user setting), each
///   chunk streamed to its own `*.part` file inside `<save>.ccloudpart/`.
/// * Pausing cancels the network subscriptions while keeping partial chunks;
///   resuming re-requests only the missing byte ranges.
/// * A 500 ms ticker aggregates chunk counters into smooth per-task speed and
///   pushes a single [notifyListeners] per tick (no per-packet UI churn).
class DownloadManager extends ChangeNotifier {
  DownloadManager._();

  static final DownloadManager instance = DownloadManager._();

  final List<DownloadTask> _tasks = <DownloadTask>[];
  final Map<String, List<int>> _chunkCounters = <String, List<int>>{};
  final Map<String, bool> _pauseFlags = <String, bool>{};
  final Map<String, bool> _cancelFlags = <String, bool>{};

  int _maxConcurrent = 3;
  int _chunkConnections = 3;
  String? _downloadDir;
  Timer? _ticker;
  bool _restored = false;

  /// Optional UI hook (wired by the shell to surface toasts).
  void Function(DownloadTask task, String event)? onEvent;

  List<DownloadTask> get tasks => List<DownloadTask>.unmodifiable(_tasks);

  DownloadTask? get activeTask {
    for (final DownloadTask t in _tasks) {
      if (t.status == DownloadStatus.downloading) {
        return t;
      }
    }
    return null;
  }

  int get activeCount => _tasks
      .where((DownloadTask t) => t.status == DownloadStatus.downloading)
      .length;

  int get queuedCount => _tasks
      .where((DownloadTask t) => t.status == DownloadStatus.queued)
      .length;

  DownloadTask? taskByUrl(String url) {
    for (final DownloadTask t in _tasks) {
      if (t.url == url) {
        return t;
      }
    }
    return null;
  }

  DownloadTask? taskById(String id) {
    for (final DownloadTask t in _tasks) {
      if (t.id == id) {
        return t;
      }
    }
    return null;
  }

  Future<String> resolveDirectory() async {
    if (_downloadDir != null && _downloadDir!.isNotEmpty) {
      return _downloadDir!;
    }
    final Directory docs = await getApplicationDocumentsDirectory();
    final Directory dir = Directory(
      '${docs.path}${Platform.pathSeparator}CCloud Downloads',
    );
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    _downloadDir = dir.path;
    return dir.path;
  }

  void configure({int? maxConcurrent, String? downloadDir}) {
    if (maxConcurrent != null) {
      _maxConcurrent = maxConcurrent.clamp(1, 8);
      _chunkConnections = _maxConcurrent;
    }
    if (downloadDir != null && downloadDir.isNotEmpty) {
      _downloadDir = downloadDir;
    }
  }

  // -------------------------------------------------------------- lifecycle

  Future<void> restore() async {
    if (_restored) {
      return;
    }
    _restored = true;
    try {
      final File f = await _metaFile();
      if (await f.exists()) {
        final dynamic decoded = jsonDecode(await f.readAsString());
        if (decoded is List) {
          for (final dynamic e in decoded) {
            if (e is! Map<String, dynamic>) {
              continue;
            }
            final DownloadTask task = _taskFromJson(e);
            final File finalFile = File(task.savePath);
            if (task.status == DownloadStatus.completed ||
                (task.totalBytes > 0 &&
                    await finalFile.exists() &&
                    await finalFile.length() == task.totalBytes)) {
              task
                ..status = DownloadStatus.completed
                ..receivedBytes = task.totalBytes;
            } else {
              task.status = DownloadStatus.paused;
            }
            _tasks.add(task);
          }
        }
      }
    } catch (e) {
      debugPrint('DownloadManager.restore error: $e');
    }
    notifyListeners();
  }

  Future<File> _metaFile() async {
    final Directory docs = await getApplicationDocumentsDirectory();
    return File('${docs.path}/ccloud_downloads.json');
  }

  Future<void> _persist() async {
    try {
      final File f = await _metaFile();
      await f.writeAsString(jsonEncode(_tasks.map(_taskToJson).toList()));
    } catch (e) {
      debugPrint('DownloadManager.persist error: $e');
    }
  }

  Map<String, dynamic> _taskToJson(DownloadTask t) => <String, dynamic>{
    'id': t.id,
    'url': t.url,
    'filename': t.filename,
    'savePath': t.savePath,
    'tempDir': t.tempDir,
    'title': t.title,
    'quality': t.quality,
    'createdAt': t.createdAt,
    'totalBytes': t.totalBytes,
    'status': t.status.name,
  };

  DownloadTask _taskFromJson(Map<String, dynamic> j) => DownloadTask(
    id: j['id'] as String? ?? '',
    url: j['url'] as String? ?? '',
    filename: j['filename'] as String? ?? 'download.bin',
    savePath: j['savePath'] as String? ?? '',
    tempDir: j['tempDir'] as String? ?? '',
    title: j['title'] as String? ?? '',
    quality: j['quality'] as String? ?? '',
    createdAt: j['createdAt'] as int? ?? 0,
  )..totalBytes = j['totalBytes'] as int? ?? 0;

  // ----------------------------------------------------------------- queue

  Future<DownloadTask?> enqueue({
    required String url,
    required String title,
    required String quality,
  }) async {
    if (taskByUrl(url) != null) {
      return null; // already queued / running / done
    }
    final String dir = await resolveDirectory();
    final String filename = _uniqueFilename(dir, _filenameFromUrl(url));
    final String savePath = '$dir${Platform.pathSeparator}$filename';
    final DownloadTask task = DownloadTask(
      id: 'dl-${DateTime.now().microsecondsSinceEpoch}',
      url: url,
      filename: filename,
      savePath: savePath,
      tempDir: '$savePath.ccloudpart',
      title: title,
      quality: quality,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    )..connections = _chunkConnections;
    _tasks.add(task);
    await _persist();
    notifyListeners();
    _pump();
    return task;
  }

  String _filenameFromUrl(String url) {
    String name = 'download_${DateTime.now().millisecondsSinceEpoch}.bin';
    try {
      final Uri uri = Uri.parse(url);
      final String last = uri.pathSegments.isNotEmpty
          ? uri.pathSegments.last
          : '';
      final String decoded = Uri.decodeComponent(last);
      if (decoded.isNotEmpty) {
        name = decoded;
      }
    } catch (_) {}
    name = name.replaceAll(RegExp(r'[^A-Za-z0-9._ ()-]'), '_');
    if (!name.contains('.')) {
      name = '$name.bin';
    }
    return name;
  }

  String _uniqueFilename(String dir, String original) {
    String candidate = original;
    final String base = original.contains('.')
        ? original.substring(0, original.lastIndexOf('.'))
        : original;
    final String ext = original.contains('.')
        ? original.substring(original.lastIndexOf('.'))
        : '';
    int n = 1;
    while (File('$dir${Platform.pathSeparator}$candidate').existsSync()) {
      candidate = '$base ($n)$ext';
      n++;
    }
    return candidate;
  }

  Future<void> pause(String id) async {
    final DownloadTask? task = taskById(id);
    if (task == null || task.status != DownloadStatus.downloading) {
      return;
    }
    _pauseFlags[id] = true;
  }

  Future<void> resume(String id) async {
    final DownloadTask? task = taskById(id);
    if (task == null) {
      return;
    }
    if (task.status == DownloadStatus.completed) {
      return;
    }
    task
      ..status = DownloadStatus.queued
      ..error = null
      ..speedBps = 0;
    await _persist();
    notifyListeners();
    _pump();
  }

  Future<void> cancel(String id) async {
    final DownloadTask? task = taskById(id);
    if (task == null) {
      return;
    }
    if (task.status == DownloadStatus.downloading) {
      _cancelFlags[id] = true;
      // Give the chunk loops a moment to observe the flag and clean up.
      await Future<void>.delayed(const Duration(milliseconds: 250));
    }
    _tasks.remove(task);
    _chunkCounters.remove(id);
    _pauseFlags.remove(id);
    _cancelFlags.remove(id);
    try {
      final Directory temp = Directory(task.tempDir);
      if (await temp.exists()) {
        await temp.delete(recursive: true);
      }
    } catch (_) {}
    await _persist();
    notifyListeners();
    _pump();
  }

  Future<void> remove(String id) async {
    final DownloadTask? task = taskById(id);
    if (task == null) {
      return;
    }
    if (task.status == DownloadStatus.downloading) {
      await pause(id);
    }
    _tasks.remove(task);
    _chunkCounters.remove(id);
    _pauseFlags.remove(id);
    _cancelFlags.remove(id);
    await _persist();
    notifyListeners();
    _pump();
  }

  Future<void> clearCompleted() async {
    _tasks.removeWhere(
      (DownloadTask t) => t.status == DownloadStatus.completed,
    );
    await _persist();
    notifyListeners();
  }

  // --------------------------------------------------------------- engine

  void _pump() {
    while (activeCount < _maxConcurrent) {
      DownloadTask? next;
      for (final DownloadTask t in _tasks) {
        if (t.status == DownloadStatus.queued) {
          next = t;
          break;
        }
      }
      if (next == null) {
        break;
      }
      next.status = DownloadStatus.downloading;
      unawaited(_runTask(next));
    }
    _ensureTicker();
    notifyListeners();
  }

  Future<void> _runTask(DownloadTask task) async {
    _pauseFlags[task.id] = false;
    _cancelFlags[task.id] = false;
    _chunkCounters[task.id] = <int>[];
    task
      ..status = DownloadStatus.downloading
      ..error = null
      ..speedBps = 0;
    notifyListeners();
    onEvent?.call(task, 'started');

    try {
      final _Probe probe = await _probe(task.url);
      if (_cancelFlags[task.id] ?? false) {
        throw _CancelledSignal();
      }
      if (_pauseFlags[task.id] ?? false) {
        task.status = DownloadStatus.paused;
        await _persist();
        notifyListeners();
        _pump();
        return;
      }

      task.totalBytes = probe.totalBytes;
      final bool useChunks =
          probe.acceptRanges && probe.totalBytes > 4 * 1024 * 1024;
      final int chunkCount = useChunks ? task.connections.clamp(1, 8) : 1;

      final Directory temp = Directory(task.tempDir);
      if (!await temp.exists()) {
        await temp.create(recursive: true);
      }

      final List<int> counters = _chunkCounters[task.id]!;
      while (counters.length < chunkCount) {
        counters.add(0);
      }

      final List<Future<void>> chunkFutures = <Future<void>>[];
      for (int i = 0; i < chunkCount; i++) {
        final (int start, int end) = _chunkRange(
          probe.totalBytes,
          chunkCount,
          i,
        );
        chunkFutures.add(_downloadChunk(task, i, start, end));
      }
      await Future.wait(chunkFutures);

      if (_cancelFlags[task.id] ?? false) {
        throw _CancelledSignal();
      }
      if (_pauseFlags[task.id] ?? false) {
        task.status = DownloadStatus.paused;
        await _persist();
        notifyListeners();
        _pump();
        return;
      }

      await _assemble(task, chunkCount);
      task
        ..status = DownloadStatus.completed
        ..receivedBytes = probe.totalBytes
        ..speedBps = 0;
      _chunkCounters.remove(task.id);
      try {
        final Directory tempDir = Directory(task.tempDir);
        if (await tempDir.exists()) {
          await tempDir.delete(recursive: true);
        }
      } catch (_) {}
      await _persist();
      notifyListeners();
      onEvent?.call(task, 'completed');
      _pump();
    } on _PausedSignal {
      task.status = DownloadStatus.paused;
      await _persist();
      notifyListeners();
      _pump();
    } on _CancelledSignal {
      // Cleanup handled by [cancel].
    } catch (e) {
      task
        ..status = DownloadStatus.failed
        ..error = e.toString()
        ..speedBps = 0;
      _chunkCounters.remove(task.id);
      await _persist();
      notifyListeners();
      onEvent?.call(task, 'failed');
      _pump();
    }
  }

  (int, int) _chunkRange(int total, int chunks, int index) {
    final int per = (total / chunks).floor();
    final int start = index * per;
    final int end = index == chunks - 1 ? total - 1 : start + per - 1;
    return (start, end);
  }

  Future<_Probe> _probe(String url) async {
    final Uri uri = Uri.parse(url);
    final http.Client client = http.Client();
    try {
      try {
        final http.StreamedResponse head = await client
            .send(http.Request('HEAD', uri))
            .timeout(const Duration(seconds: 20));
        if (head.statusCode >= 200 && head.statusCode < 400) {
          final int? len = int.tryParse(head.headers['content-length'] ?? '');
          final bool ranges = (head.headers['accept-ranges'] ?? '').contains(
            'bytes',
          );
          return _Probe(len ?? 0, ranges);
        }
      } catch (_) {
        // fall through to range probe
      }

      final http.Request rangeReq = http.Request('GET', uri)
        ..headers['range'] = 'bytes=0-0';
      final http.StreamedResponse res = await client
          .send(rangeReq)
          .timeout(const Duration(seconds: 20));
      if (res.statusCode == 206) {
        final String contentRange = res.headers['content-range'] ?? '';
        final int total = int.tryParse(contentRange.split('/').last) ?? 0;
        return _Probe(total, true);
      }
      return _Probe(
        int.tryParse(res.headers['content-length'] ?? '') ?? 0,
        false,
      );
    } finally {
      client.close();
    }
  }

  Future<void> _downloadChunk(
    DownloadTask task,
    int partIndex,
    int start,
    int end,
  ) async {
    final File partFile = File(
      '${task.tempDir}${Platform.pathSeparator}part_$partIndex',
    );
    int done = 0;
    if (await partFile.exists()) {
      done = await partFile.length();
    }
    final int chunkTotal = end - start + 1;
    if (done >= chunkTotal) {
      _chunkCounters[task.id]![partIndex] = chunkTotal;
      return;
    }

    final List<int> counters = _chunkCounters[task.id]!;
    counters[partIndex] = done;

    final http.Request request = http.Request('GET', Uri.parse(task.url))
      ..headers['range'] = 'bytes=${start + done}-$end'
      ..followRedirects = true;
    final http.Client client = http.Client();
    IOSink? sink;
    try {
      final http.StreamedResponse res = await client
          .send(request)
          .timeout(const Duration(seconds: 30));
      if (res.statusCode >= 400) {
        throw HttpException(
          'HTTP ${res.statusCode} for chunk $partIndex of ${task.filename}',
        );
      }
      sink = partFile.openWrite(mode: FileMode.append);
      await res.stream
          .takeWhile((_) {
            if (_cancelFlags[task.id] ?? false) {
              return false;
            }
            if (_pauseFlags[task.id] ?? false) {
              return false;
            }
            return true;
          })
          .forEach((List<int> chunk) async {
            sink!.add(chunk);
            counters[partIndex] += chunk.length;
          });
      await sink.flush();
      await sink.close();
      sink = null;

      if (_cancelFlags[task.id] ?? false) {
        throw _CancelledSignal();
      }
      if (_pauseFlags[task.id] ?? false) {
        throw _PausedSignal();
      }
      if (task.totalBytes > 0 &&
          (await partFile.exists()) &&
          await partFile.length() < chunkTotal) {
        throw HttpException(
          'Chunk $partIndex ended early for ${task.filename}',
        );
      }
    } finally {
      await sink?.close();
      client.close();
    }
  }

  Future<void> _assemble(DownloadTask task, int chunkCount) async {
    final File finalFile = File(task.savePath);
    final IOSink out = finalFile.openWrite();
    try {
      for (int i = 0; i < chunkCount; i++) {
        final File part = File(
          '${task.tempDir}${Platform.pathSeparator}part_$i',
        );
        if (await part.exists()) {
          await out.addStream(part.openRead());
        }
      }
      await out.flush();
    } finally {
      await out.close();
    }
  }

  // ---------------------------------------------------------------- ticker

  void _ensureTicker() {
    _ticker ??= Timer.periodic(
      const Duration(milliseconds: 500),
      (_) => _tick(),
    );
  }

  final Map<String, int> _lastBytes = <String, int>{};
  final Map<String, DateTime> _lastTime = <String, DateTime>{};

  void _tick() {
    bool anyActive = false;
    for (final DownloadTask t in _tasks) {
      if (t.status != DownloadStatus.downloading) {
        continue;
      }
      anyActive = true;
      final List<int>? counters = _chunkCounters[t.id];
      final int nowBytes = counters == null
          ? 0
          : counters.fold<int>(0, (int a, int b) => a + b);
      t.receivedBytes = nowBytes;

      final DateTime now = DateTime.now();
      final DateTime prev = _lastTime[t.id] ?? now;
      final double dt = now.difference(prev).inMilliseconds / 1000.0;
      final int prevBytes = _lastBytes[t.id] ?? nowBytes;
      if (dt > 0.2) {
        final double instant = (nowBytes - prevBytes) / dt;
        t.speedBps = t.speedBps <= 0
            ? instant
            : t.speedBps * 0.6 + instant * 0.4;
        _lastBytes[t.id] = nowBytes;
        _lastTime[t.id] = now;
      }
    }
    if (anyActive) {
      notifyListeners();
    } else {
      _lastBytes.clear();
      _lastTime.clear();
      _ticker?.cancel();
      _ticker = null;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
