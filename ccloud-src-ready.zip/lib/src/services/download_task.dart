import 'dart:math' as math;

/// Status of a single in-app download task.
enum DownloadStatus { queued, downloading, paused, completed, failed }

/// Live record of one download managed by the [DownloadManager].
class DownloadTask {
  DownloadTask({
    required this.id,
    required this.url,
    required this.filename,
    required this.savePath,
    required this.tempDir,
    required this.title,
    required this.quality,
    required this.createdAt,
  });

  final String id;
  final String url;
  final String filename;
  final String savePath;
  final String tempDir;
  final String title;
  final String quality;
  final int createdAt;

  int totalBytes = 0;
  int receivedBytes = 0;
  double speedBps = 0;
  DownloadStatus status = DownloadStatus.queued;
  String? error;

  /// Planned number of parallel byte-range chunks for this task.
  int connections = 1;

  bool get isActive =>
      status == DownloadStatus.downloading || status == DownloadStatus.queued;

  double get progress {
    if (totalBytes <= 0) {
      return 0;
    }
    return (receivedBytes / totalBytes).clamp(0.0, 1.0);
  }

  String get speedLabel {
    if (speedBps <= 0) {
      return '0 B/s';
    }
    return '${formatBytes(speedBps, decimals: 1)}/s';
  }
}

/// Human readable byte size, e.g. `1.42 GB` or `812 KB`.
String formatBytes(num bytes, {int decimals = 2}) {
  if (bytes <= 0) {
    return '0 B';
  }
  const List<String> units = <String>['B', 'KB', 'MB', 'GB', 'TB'];
  final int unitIndex = (math.log(bytes) / math.log(1024)).floor().clamp(
    0,
    units.length - 1,
  );
  final double value = bytes / math.pow(1024, unitIndex);
  final String text = value.toStringAsFixed(unitIndex == 0 ? 0 : decimals);
  return '$text ${units[unitIndex]}';
}
