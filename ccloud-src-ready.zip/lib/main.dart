import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_acrylic/flutter_acrylic.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';

import 'src/core/router/app_router.dart';
import 'src/core/theme/theme_manager.dart';
import 'src/providers/countries_provider.dart';
import 'src/providers/genre_provider.dart';
import 'src/providers/movie_provider.dart';
import 'src/providers/search_provider.dart';
import 'src/providers/seasons_provider.dart';
import 'src/providers/series_provider.dart';
import 'src/providers/tv_provider.dart';
import 'src/services/continue_watching_service.dart';
import 'src/services/download_manager.dart';
import 'src/services/favorites_service.dart';
import 'src/services/settings_service.dart';
import 'src/services/toast_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // High-performance libmpv backend for the in-app player.
  MediaKit.ensureInitialized();

  // Frameless Fluent-2 window with custom glass titlebar.
  await windowManager.ensureInitialized();
  const WindowOptions windowOptions = WindowOptions(
    size: Size(1440, 900),
    minimumSize: Size(1024, 680),
    center: true,
    backgroundColor: Colors.transparent,
    skipTaskbar: false,
    titleBarStyle: TitleBarStyle.hidden,
    windowButtonVisibility: false,
  );
  unawaited(
    windowManager.waitUntilReadyToShow(windowOptions, () async {
      await windowManager.show();
      await windowManager.focus();
    }),
  );

  // True acrylic backdrop behind the window (graceful fallback: the app
  // paints its own ambient gradient regardless).
  try {
    await Window.initialize();
    await Window.setEffect(effect: WindowEffect.acrylic, dark: true);
  } catch (_) {
    // Effect is cosmetic; ignore failures on unsupported setups.
  }

  runApp(const CCloudBootstrap());
}

class CCloudBootstrap extends StatelessWidget {
  const CCloudBootstrap({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // --- Preserved logic layer ---
        ChangeNotifierProvider<MovieProvider>(create: (_) => MovieProvider()),
        ChangeNotifierProvider<SeriesProvider>(create: (_) => SeriesProvider()),
        ChangeNotifierProvider<GenreProvider>(create: (_) => GenreProvider()),
        ChangeNotifierProvider<SeasonsProvider>(
          create: (_) => SeasonsProvider(),
        ),
        ChangeNotifierProvider<SearchProvider>(create: (_) => SearchProvider()),
        ChangeNotifierProvider<CountriesProvider>(
          create: (_) => CountriesProvider(),
        ),
        ChangeNotifierProvider<CountryMediaProvider>(
          create: (_) => CountryMediaProvider(),
        ),
        ChangeNotifierProvider<TvProvider>(create: (_) => TvProvider()),

        // --- New PRO services ---
        ChangeNotifierProvider<ThemeManager>(create: (_) => ThemeManager()),
        ChangeNotifierProvider<SettingsService>(
          create: (_) => SettingsService()..load(),
        ),
        ChangeNotifierProvider<FavoritesService>(
          create: (_) => FavoritesService()..load(),
        ),
        ChangeNotifierProvider<ContinueWatchingService>(
          create: (_) => ContinueWatchingService()..load(),
        ),
        ChangeNotifierProvider<DownloadManager>.value(
          value: DownloadManager.instance,
        ),
        ChangeNotifierProvider<ToastService>(create: (_) => ToastService()),
      ],
      child: const CCloudApp(),
    );
  }
}

class CCloudApp extends StatefulWidget {
  const CCloudApp({super.key});

  @override
  State<CCloudApp> createState() => _CCloudAppState();
}

class _CCloudAppState extends State<CCloudApp> {
  bool? _lastDark;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      context.read<FavoritesService>().load();
      context.read<ContinueWatchingService>().load();
      context.read<DownloadManager>().restore();
    });
  }

  void _syncAcrylic(bool dark) {
    if (_lastDark == dark) {
      return;
    }
    _lastDark = dark;
    scheduleMicrotask(() async {
      try {
        await Window.setEffect(effect: WindowEffect.acrylic, dark: dark);
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    final ThemeManager theme = context.watch<ThemeManager>();
    _syncAcrylic(theme.isDark);

    return MaterialApp.router(
      title: 'CCloud PRO',
      debugShowCheckedModeBanner: false,
      theme: theme.themeData,
      themeMode: theme.themeMode,
      routerConfig: appRouter,
    );
  }
}
