; ============================================================================
;  CCloud PRO 2.0.0 — Inno Setup script
;  Builds a standalone Setup.exe bundling the complete Flutter Windows
;  release (exe + data\ + all DLLs). No external runtime is required on
;  the target machine — Windows 10 / 11 x64.
;
;  Build:  iscc installer\CCloudPro.iss      (from the project root)
;  Output: dist\CCloudPro-2.0.0-Setup.exe
; ============================================================================

#define MyAppName "CCloud PRO"
#define MyAppVersion "2.0.0"
#define MyAppPublisher "code3-dev"
#define MyAppURL "https://github.com/code3-dev/CCloud-GUI"
#define MyAppExeName "ccloud_gui.exe"

[Setup]
AppId={{7E1C2F9A-54B3-4C1D-9A2E-3C6B10D2F0AA}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=dist
OutputBaseFilename=CCloudPro-{#MyAppVersion}-Setup
SetupIconFile=windows\runner\resources\app_icon.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; \
    GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "build\windows\x64\runner\Release\*"; \
    DestDir: "{app}"; \
    Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; \
    Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; \
    Description: "{cm:LaunchProgram,{#MyAppName}}"; \
    Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{userdocs}\ccloud_watch_progress.json"
Type: filesandordirs; Name: "{userdocs}\ccloud_downloads.json"
